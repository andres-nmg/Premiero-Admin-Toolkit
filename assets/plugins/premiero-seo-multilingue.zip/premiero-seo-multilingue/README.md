# Premiero SEO Multilingüe

Complemento de WordPress desarrollado por **[Premiero](https://www.premiero.es)** para resolver el SEO multilingüe del sitio de Euroforum manteniendo **un único post por contenido** (sin duplicar entradas por idioma).

Aporta tres cosas que ni TranslatePress gratuito ni qTranslate-XT ofrecen de serie con Yoast SEO:

1. **Título SEO y meta description por idioma** en Yoast (se respeta el resto de la lógica de Yoast).
2. **Slugs traducidos** (en TranslatePress los gestiona este plugin; en qTranslate-XT los gestiona su módulo *Slugs translation*).
3. **Sitemap propio con hreflang** en `/premiero-sitemap.xml`, con las URLs de ambos idiomas y sus `alternate` + `x-default`.

## Motores soportados (detección automática)

El plugin detecta el motor multilingüe activo en tiempo de ejecución (`PTP::engine()`):

| Motor | Detección | Qué hace el plugin |
|-------|-----------|--------------------|
| **TranslatePress** (`tp`) | Clase/constante de TranslatePress o `trp_settings` | Reescribe la petición para resolver slugs traducidos, filtra enlaces/canonical, gestiona slugs y sitemap. |
| **qTranslate-XT** (`qtx`) | `QTRANSLATE_FILE` / `qtranxf_getLanguage()` | **Solo** título/meta de Yoast por idioma y sitemap con hreflang. Las URLs y los slugs los gestiona qTranslate-XT (módulo *Slugs translation*). |
| **Los dos activos** | Se detectan ambos | Gana **qTranslate-XT** por defecto. Se puede forzar el otro con `define( 'PTP_ENGINE', 'tp' )` en `wp-config.php` (o con el filtro `ptp_engine`). La pantalla de ajustes muestra un aviso indicando el modo en uso. |
| Ninguno (`none`) | — | El plugin no interfiere. |

> No requiere configuración: si el sitio migra de un motor al otro, el plugin se adapta sin tocar código.
>
> **No se recomienda tener TranslatePress y qTranslate-XT activos a la vez** (ambos intentan gestionar las URLs). Si ocurre, el plugin funciona en modo qTranslate-XT y muestra un aviso en su pantalla de ajustes.

## Requisitos

- PHP 7.4 o superior.
- WordPress con enlaces permanentes amigables (no “Simple”).
- **Yoast SEO** para el título/meta por idioma.
- **TranslatePress** (gratuito) **o** **qTranslate-XT** con un idioma secundario activo.
  - En TranslatePress, si el *SEO Pack* de pago está activo, el plugin se desactiva solo (no hace falta).

## Instalación

1. Copia la carpeta del plugin a `wp-content/plugins/`.
2. Actívalo en **Plugins**.
3. Ve a **Ajustes → SEO Multilingüe** (slug de URL `premiero-seo-multilingue`).

## Uso

### Editor de contenido

- **TranslatePress:** metabox *“URL y SEO en EN”* con slug traducido, título SEO, meta description y casilla para incluir en el sitemap.
- **qTranslate-XT:** metabox *“SEO en EN”* con título SEO, meta description y casilla para incluir en el sitemap. El **slug en inglés se edita en qTranslate-XT → Slugs translation**.

Deja un campo vacío para mantener el valor de Yoast/original.

### Pantalla de administración

- **TranslatePress:** tabla con URL original, slug traducido, título/meta y estado de sitemap; además de segmentos globales (`original = traducido`) y el botón de reconstruir el mapa de URLs.
- **qTranslate-XT:** tabla simplificada solo con título SEO, meta description y control de sitemap por contenido.

### Sitemap

- URL: `/premiero-sitemap.xml` (se añade automáticamente a `robots.txt`).
- Emite dos `<url>` por contenido (idioma por defecto e idioma secundario) con enlaces `xhtml:link` `alternate` para cada `hreflang` y `x-default`.
- En **qTranslate-XT** el sitemap se sirve en el hook `parse_request` (cuando qTranslate ya cargó su configuración) y usa sus slugs traducidos. Se cancela cualquier redirección de qTranslate sobre la URL del sitemap.
- Solo se incluyen contenidos marcados para el sitemap. En qTranslate-XT se incluyen por defecto salvo que se desmarque la casilla (se guarda `_ptp_ready = 0`).

## Cómo funciona (resumen técnico)

- `PTP::engine()` detecta el motor; `PTP::cfg()` deriva idioma por defecto, idioma secundario y sus prefijos (lee `trp_settings` o las opciones `qtranslate_default_language` / `qtranslate_enabled_languages`).
- `PTP::lang()` devuelve el idioma actual (`$TRP_LANGUAGE` o `qtranxf_getLanguage()`).
- `PTP::seo()` se engancha a los filtros `wpseo_*` (título, Open Graph y Twitter) y sustituye el valor por `_ptp_seo_title` / `_ptp_seo_desc` cuando el idioma actual es el secundario.
- En TranslatePress, `PTP::early()` reescribe `REQUEST_URI` para resolver el slug traducido y el resto de filtros de enlaces mantienen la coherencia.
- Los hooks dependientes del motor se registran **siempre** y cada callback decide en tiempo de ejecución; así no depende del orden de carga de plugins.

### Datos que guarda

| Clave | Tipo | Uso |
|-------|------|-----|
| `_ptp_seo_title` | post meta | Título SEO del idioma secundario. |
| `_ptp_seo_desc` | post meta | Meta description del idioma secundario. |
| `_ptp_slug` | post meta | Slug traducido (solo TranslatePress). |
| `_ptp_ready` | post meta | `1` incluir / `0` excluir del sitemap (qTranslate-XT usa `0` como exclusión explícita). |
| `ptp_map` | option | Mapa de URLs (solo TranslatePress). |
| `ptp_segments` | option | Segmentos globales de URL (solo TranslatePress). |

## Pruebas recomendadas en staging

1. **Sitemap:** abrir `/premiero-sitemap.xml` (HTTP 200, XML) y comprobar que cada contenido aparece en ES y EN con slugs traducidos y `x-default`.
2. **Yoast por idioma:** en una página, rellenar *Título SEO EN* y *Meta descripción EN*; verificar que la URL `/en/...` muestra esos valores y que la URL en español **no** cambia.
3. **Slugs (qTranslate-XT):** editar el slug EN en *Slugs translation* y comprobar que el sitemap y la URL `/en/...` reflejan el nuevo slug.
4. **TranslatePress:** repetir 1–2 y verificar que los enlaces del menú y el canonical no se alteran.
5. **robots.txt:** confirmar que incluye `Sitemap: https://dominio/premiero-sitemap.xml`.


## Historial de cambios

### 1.1.2
- Renombrado a **Premiero SEO Multilingüe**: nombre del plugin, menú de Ajustes, `<h1>` de la pantalla, README y **archivo principal** (`premiero-seo-multilingue.php`).
- Renombradas también la carpeta (`premiero-seo-multilingue`) y el slug de la página de ajustes (`?page=premiero-seo-multilingue`).

### 1.1.1
- Mensaje de aviso cuando no hay motor activo: ahora menciona TranslatePress **y** qTranslate-XT.
- Detección explícita de TranslatePress / qTranslate-XT (`tp_active()`, `qtx_active()`, `both_active()`).
- Si ambos plugins están activos se usa qTranslate-XT y la pantalla de ajustes lo indica; se puede forzar el motor con la constante `PTP_ENGINE` o el filtro `ptp_engine`.
- La pantalla de ajustes muestra el motor en uso.

### 1.1.0
- Soporte dual **TranslatePress** y **qTranslate-XT** con detección automática de motor.
- Título y meta description de Yoast por idioma en ambos motores.
- Sitemap con hreflang adaptado a qTranslate-XT (slugs traducidos vía módulo *Slugs translation*).
- Pantalla de administración y metabox adaptados a qTranslate-XT (sin edición de slug propia).
- Registro de hooks independiente del orden de carga de plugins.

### 1.0.0
- Versión inicial para TranslatePress gratuito: slugs traducidos, SEO de Yoast y sitemap con hreflang.

## Autor

**Premiero** — <https://www.premiero.es>
Licencia GPL-2.0-or-later.

