<?php
/**
 * Plugin Name:       Premiero SEO Multilingüe
 * Description:       Complemento de Premiero: título y meta description SEO por idioma con Yoast SEO, slugs traducidos y sitemap con hreflang para el idioma secundario. Compatible con TranslatePress (gratuito) y qTranslate-XT (detección automática).
 * Version:           2.1.2
 * Author:            Premiero
 * Author URI:        https://www.premiero.es
 * Requires PHP:      7.4
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       premiero-ml-seo
 *
 * Propiedad de Premiero — https://www.premiero.es
 *
 * Cómo funciona (motor detectado automáticamente):
 *
 * TranslatePress (TP):
 * - TP gratuito resuelve /en/ con el filtro home_url; el resto de la ruta la resuelve WordPress.
 *   Aquí se reescribe REQUEST_URI en plugins_loaded (prioridad 2) cambiando el slug traducido por el original.
 * - Enlaces salientes: trp_get_url_for_language y los filtros de permalinks de WordPress (menús, canonical)
 *   convierten la ruta en ambos sentidos.
 * - Sitemap propio en /premiero-sitemap.xml con hreflang. Meta SEO de Yoast mediante sus filtros.
 *
 * qTranslate-XT (qtx):
 * - Los slugs y su traducción los gestiona el módulo "Slugs translation" de qTranslate-XT; este plugin no
 *   toca las URLs.
 * - Meta SEO de Yoast por idioma mediante sus filtros (título y description).
 * - Sitemap propio en /premiero-sitemap.xml con hreflang (qTranslate-XT no genera sitemap y el de Yoast solo lista
 *   la URL del idioma por defecto).
 */

defined( 'ABSPATH' ) || exit;

final class PTP {

	const OPT_MAP = 'ptp_map';
	const OPT_SEG = 'ptp_segments';
	const M_SLUG  = '_ptp_slug';
	const M_TITLE = '_ptp_seo_title';
	const M_DESC  = '_ptp_seo_desc';
	const M_READY = '_ptp_ready';
	const SITEMAP = 'premiero-sitemap.xml';

	private static $cfg      = false;
	private static $map      = false;
	private static $dirty    = false;
	private static $building = false;
	private static $engine   = null;

	/* ------------------------------------------------------------------ */
	/* Arranque                                                            */
	/* ------------------------------------------------------------------ */

	public static function init() {
		if ( did_action( 'plugins_loaded' ) ) {
			self::early(); // cargado tarde (mu-plugin o gestor de snippets): la reescritura aún llega antes de parse_request.
		} else {
			add_action( 'plugins_loaded', array( __CLASS__, 'early' ), 2 );
		}
		add_filter( 'robots_txt', array( __CLASS__, 'robots' ), 20 );

		// Hooks de TranslatePress. Se registran siempre; si TP no es el motor no se disparan
		// (o devuelven la URL intacta porque $TRP_LANGUAGE no existe). Esto evita depender del
		// orden de carga de plugins al detectar el motor.
		add_filter( 'trp_get_url_for_language', array( __CLASS__, 'filter_url' ), 20, 4 );
		add_filter( 'redirect_canonical', array( __CLASS__, 'canonical' ), 20, 2 );
		add_filter( 'trp_href_from_translated_page', array( __CLASS__, 'link_filter' ), 20 );
		foreach ( array( 'post_link', 'page_link', 'post_type_link', 'term_link', 'post_type_archive_link' ) as $h ) {
			add_filter( $h, array( __CLASS__, 'link_filter' ), 20 );
		}
		add_action( 'save_post', array( __CLASS__, 'dirty_post' ), 20, 1 );
		add_action( 'deleted_post', array( __CLASS__, 'dirty_post' ) );
		add_action( 'trashed_post', array( __CLASS__, 'dirty_post' ) );
		add_action( 'untrashed_post', array( __CLASS__, 'dirty_post' ) );
		add_action( 'update_option_permalink_structure', array( __CLASS__, 'mark_dirty' ) );
		add_action( 'update_option_page_on_front', array( __CLASS__, 'mark_dirty' ) );
		add_action( 'update_option_trp_settings', array( __CLASS__, 'mark_dirty' ) );

		// Hooks de qTranslate-XT. También siempre registrados; los callbacks comprueban el motor.
		add_action( 'parse_request', array( __CLASS__, 'serve_qtx_sitemap' ), 0 );
		add_filter( 'qtranslate_language_detect_redirect', array( __CLASS__, 'qtx_keep_sitemap_url' ), 10, 3 );

		add_action( 'add_meta_boxes', array( __CLASS__, 'add_box' ) );
		add_action( 'save_post', array( __CLASS__, 'save_box' ), 10, 1 );

		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_post' ) );

		$yoast = array(
			'wpseo_title'               => 'title',
			'wpseo_opengraph_title'     => 'title',
			'wpseo_twitter_title'       => 'title',
			'wpseo_metadesc'            => 'desc',
			'wpseo_opengraph_desc'      => 'desc',
			'wpseo_twitter_description' => 'desc',
		);
		foreach ( $yoast as $hook => $key ) {
			add_filter( $hook, function ( $value ) use ( $key ) {
				return PTP::seo( $value, $key );
			}, 20 );
		}
	}

	/**
	 * Motor multilingüe activo: 'tp' (TranslatePress), 'qtx' (qTranslate-XT) o 'none'.
	 * Si están los dos activos gana qTranslate-XT (es el que resuelve URLs y slugs en el sitio).
	 * Se puede forzar con la constante PTP_ENGINE ('tp'|'qtx'|'none') o con el filtro `ptp_engine`.
	 */
	public static function engine() {
		if ( null !== self::$engine ) {
			return self::$engine;
		}
		if ( self::qtx_active() ) {
			$engine = 'qtx';
		} elseif ( self::tp_active() ) {
			$engine = 'tp';
		} else {
			$engine = 'none';
		}
		if ( defined( 'PTP_ENGINE' ) ) {
			$forced = strtolower( trim( (string) PTP_ENGINE ) );
			if ( in_array( $forced, array( 'tp', 'qtx', 'none' ), true ) ) {
				$engine = $forced;
			}
		}
		$engine       = strtolower( trim( (string) apply_filters( 'ptp_engine', $engine ) ) );
		self::$engine = in_array( $engine, array( 'tp', 'qtx', 'none' ), true ) ? $engine : 'none';
		return self::$engine;
	}

	/** TranslatePress cargado (o configurado alguna vez). */
	public static function tp_active() {
		return ( class_exists( 'TRP_Translate_Press' ) || defined( 'TRP_PLUGIN_VERSION' ) || (bool) get_option( 'trp_settings' ) );
	}

	/** qTranslate-XT cargado. */
	public static function qtx_active() {
		return ( defined( 'QTRANSLATE_FILE' ) || function_exists( 'qtranxf_getLanguage' ) );
	}

	/** Los dos motores están activos a la vez. */
	public static function both_active() {
		$tp = ( class_exists( 'TRP_Translate_Press' ) || defined( 'TRP_PLUGIN_VERSION' ) );
		return ( $tp && self::qtx_active() );
	}

	/** Idioma de la petición actual, según el motor. */
	public static function lang() {
		if ( 'tp' === self::engine() ) {
			global $TRP_LANGUAGE;
			return (string) $TRP_LANGUAGE;
		}
		if ( 'qtx' === self::engine() && function_exists( 'qtranxf_getLanguage' ) ) {
			return (string) qtranxf_getLanguage();
		}
		return '';
	}

	/**
	 * Ajustes del motor: idioma por defecto, primer idioma secundario y sus prefijos de URL.
	 * TP lee `trp_settings`; qTranslate-XT lee sus opciones (no depende de $q_config, que puede
	 * no estar cargado cuando se llama en plugins_loaded prioridad 2).
	 */
	public static function cfg() {
		if ( false !== self::$cfg ) {
			return self::$cfg;
		}
		self::$cfg = null;
		$engine    = self::engine();

		if ( 'tp' === $engine ) {
			if ( defined( 'TRP_IN_SP_PLUGIN_VERSION' ) || class_exists( 'TRP_IN_Seo_Pack', false ) ) {
				return null; // SEO Pack de pago activo: no hace falta este plugin.
			}
			$s = get_option( 'trp_settings' );
			if ( ! is_array( $s ) || empty( $s['default-language'] ) || empty( $s['translation-languages'] ) ) {
				return null;
			}
			$def = $s['default-language'];
			$sec = '';
			foreach ( (array) $s['translation-languages'] as $l ) {
				if ( $l !== $def ) {
					$sec = $l;
					break;
				}
			}
			if ( '' === $sec ) {
				return null;
			}
			$slugs     = isset( $s['url-slugs'] ) ? (array) $s['url-slugs'] : array();
			self::$cfg = array(
				'def'      => $def,
				'sec'      => $sec,
				'def_slug' => isset( $slugs[ $def ] ) ? strtolower( $slugs[ $def ] ) : strtolower( $def ),
				'sec_slug' => isset( $slugs[ $sec ] ) ? strtolower( $slugs[ $sec ] ) : strtolower( $sec ),
				'def_dir'  => isset( $s['add-subdirectory-to-default-language'] ) && 'yes' === $s['add-subdirectory-to-default-language'],
			);
			return self::$cfg;
		}

		if ( 'qtx' === $engine ) {
			$def     = (string) get_option( 'qtranslate_default_language', '' );
			$enabled = get_option( 'qtranslate_enabled_languages' );
			if ( ( '' === $def || ! is_array( $enabled ) || ! $enabled ) ) {
				// Respaldo: $q_config si ya está cargado.
				global $q_config;
				if ( isset( $q_config['default_language'], $q_config['enabled_languages'] ) && is_array( $q_config['enabled_languages'] ) ) {
					$def     = (string) $q_config['default_language'];
					$enabled = $q_config['enabled_languages'];
				}
			}
			if ( '' === $def || ! is_array( $enabled ) || ! $enabled ) {
				return null;
			}
			$sec = '';
			foreach ( $enabled as $l ) {
				if ( $l !== $def ) {
					$sec = $l;
					break;
				}
			}
			if ( '' === $sec ) {
				return null;
			}
			self::$cfg = array(
				'def'      => $def,
				'sec'      => $sec,
				'def_slug' => strtolower( $def ),
				'sec_slug' => strtolower( $sec ),
				'def_dir'  => false,
			);
			return self::$cfg;
		}

		return null;
	}

	public static function map() {
		if ( false === self::$map ) {
			$m         = get_option( self::OPT_MAP );
			self::$map = ( is_array( $m ) && isset( $m['pairs'], $m['rev'], $m['seg'], $m['segrev'] ) ) ? $m : null;
		}
		return self::$map;
	}

	private static function home_path() {
		return rtrim( (string) wp_parse_url( get_option( 'home' ), PHP_URL_PATH ), '/' );
	}

	private static function label() {
		$c = self::cfg();
		return $c ? strtoupper( $c['sec_slug'] ) : '';
	}

	private static function types() {
		$t = get_post_types( array( 'public' => true ) );
		unset( $t['attachment'] );
		return array_values( apply_filters( 'ptp_post_types', $t ) );
	}

	/* ------------------------------------------------------------------ */
	/* Utilidades de ruta (sin dependencias de WordPress)                  */
	/* ------------------------------------------------------------------ */

	/** Separa el prefijo de idioma. Devuelve array( 'def'|'sec', resto sin barras ). */
	public static function split( $path, $cfg ) {
		$path  = trim( $path, '/' );
		$first = strtok( $path, '/' );
		$rest  = ( false !== $first ) ? ltrim( substr( $path, strlen( $first ) ), '/' ) : '';
		$low   = ( false !== $first ) ? strtolower( $first ) : '';
		if ( '' !== $low && $low === $cfg['sec_slug'] ) {
			return array( 'sec', $rest );
		}
		if ( '' !== $low && $cfg['def_dir'] && $low === $cfg['def_slug'] ) {
			return array( 'def', $rest );
		}
		return array( 'def', $path );
	}

	public static function join_path( $lang, $conv, $cfg, $trail ) {
		$seg = array();
		if ( 'sec' === $lang ) {
			$seg[] = $cfg['sec_slug'];
		} elseif ( $cfg['def_dir'] ) {
			$seg[] = $cfg['def_slug'];
		}
		if ( '' !== $conv ) {
			$seg[] = $conv;
		}
		$p = '/' . implode( '/', $seg );
		return ( $trail && '/' !== $p ) ? $p . '/' : $p;
	}

	/** Convierte una ruta con el mapa de prefijos más largo y, al resto, la tabla de segmentos. */
	public static function convert( $path, $pairs, $seg ) {
		$path = trim( $path, '/' );
		if ( '' === $path ) {
			return '';
		}
		$parts = explode( '/', $path );
		for ( $n = count( $parts ); $n >= 1; $n-- ) {
			$k = strtolower( implode( '/', array_slice( $parts, 0, $n ) ) );
			if ( isset( $pairs[ $k ] ) ) {
				$rest = self::seg_map( array_slice( $parts, $n ), $seg );
				return trim( $pairs[ $k ] . '/' . implode( '/', $rest ), '/' );
			}
		}
		return implode( '/', self::seg_map( $parts, $seg ) );
	}

	private static function seg_map( $parts, $seg ) {
		foreach ( $parts as $i => $p ) {
			$l = strtolower( $p );
			if ( isset( $seg[ $l ] ) ) {
				$parts[ $i ] = $seg[ $l ];
			}
		}
		return $parts;
	}

	private static function replace_path( $p, $newpath ) {
		$out  = isset( $p['scheme'] ) ? $p['scheme'] . '://' : ( isset( $p['host'] ) ? '//' : '' );
		$out .= isset( $p['host'] ) ? $p['host'] : '';
		$out .= isset( $p['port'] ) ? ':' . $p['port'] : '';
		$out .= $newpath;
		$out .= isset( $p['query'] ) ? '?' . $p['query'] : '';
		$out .= isset( $p['fragment'] ) ? '#' . $p['fragment'] : '';
		return $out;
	}

	private static function is_system_path( $rest ) {
		return (bool) preg_match( '#^(wp-|xmlrpc|index\.php)#i', $rest );
	}

	/* ------------------------------------------------------------------ */
	/* Petición entrante                                                   */
	/* ------------------------------------------------------------------ */

	public static function early() {
		if ( empty( $_SERVER['REQUEST_URI'] ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}
		$cfg = self::cfg();
		if ( ! $cfg ) {
			return;
		}
		if ( 'tp' !== self::engine() ) {
			return; // qTranslate-XT gestiona las URLs; su sitemap se sirve en parse_request.
		}
		if ( false === get_option( self::OPT_MAP, false ) ) {
			self::mark_dirty(); // primera carga: construye el mapa al terminar la petición.
		}
		$uri  = wp_unslash( $_SERVER['REQUEST_URI'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$qs   = (string) wp_parse_url( $uri, PHP_URL_QUERY );
		$hp   = self::home_path();
		if ( '' !== $hp ) {
			if ( 0 !== strpos( $path . '/', $hp . '/' ) ) {
				return;
			}
			$path = substr( $path, strlen( $hp ) );
		}

		if ( self::SITEMAP === trim( $path, '/' ) ) {
			self::serve_sitemap();
		}

		$map = self::map();
		if ( ! $map ) {
			return;
		}
		list( $lang, $rest ) = self::split( $path, $cfg );
		if ( 'sec' !== $lang || '' === $rest || self::is_system_path( $rest ) ) {
			return;
		}
		$trail = '/' === substr( $path, -1 );

		// Slug traducido -> original: WordPress resuelve la página real.
		$es = self::convert( $rest, $map['rev'], $map['segrev'] );
		if ( strtolower( $es ) !== strtolower( trim( $rest, '/' ) ) ) {
			$new                         = self::join_path( 'sec', $es, $cfg, $trail );
			$GLOBALS['ptp_original_uri'] = $uri;
			$_SERVER['REQUEST_URI']      = $hp . $new . ( '' !== $qs ? '?' . $qs : '' );
			if ( ! empty( $_SERVER['PATH_INFO'] ) ) {
				$_SERVER['PATH_INFO'] = $new; // WordPress da prioridad a PATH_INFO cuando el servidor lo define.
			}
			return;
		}

		// Slug original dentro de /en/: 301 a la URL traducida.
		$en     = self::convert( $rest, $map['pairs'], $map['seg'] );
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET'; // phpcs:ignore
		if ( strtolower( $en ) !== strtolower( trim( $rest, '/' ) ) && in_array( $method, array( 'GET', 'HEAD' ), true ) && false === strpos( $qs, 'trp-' ) ) {
			$trail = $trail || '/' === substr( (string) get_option( 'permalink_structure' ), -1 );
			$to    = rtrim( get_option( 'home' ), '/' ) . self::join_path( 'sec', $en, $cfg, $trail ) . ( '' !== $qs ? '?' . $qs : '' );
			$to    = str_replace( array( "\r", "\n" ), '', $to );
			header( 'X-Redirect-By: Premiero TP Slugs' );
			header( 'Location: ' . $to, true, 301 );
			exit;
		}
	}

	/* ------------------------------------------------------------------ */
	/* Enlaces salientes                                                   */
	/* ------------------------------------------------------------------ */

	public static function filter_url( $new_url, $url = '', $language = '', $abs_home = '' ) {
		$cfg = self::cfg();
		if ( ! $cfg || ! is_string( $new_url ) || '' === $new_url ) {
			return $new_url;
		}
		if ( empty( $language ) ) {
			global $TRP_LANGUAGE;
			$language = $TRP_LANGUAGE;
		}
		if ( $language !== $cfg['sec'] && $language !== $cfg['def'] ) {
			return $new_url;
		}
		return self::map_url( $new_url, $language === $cfg['sec'] ? 'sec' : 'def', $language !== $cfg['sec'], $abs_home );
	}

	/** Enlaces generados por WordPress (get_permalink, menús, canonical): ya llevan /en/ pero con el slug original. */
	public static function link_filter( $url ) {
		global $TRP_LANGUAGE;
		$cfg = self::cfg();
		if ( self::$building || ! $cfg || ! is_string( $url ) || empty( $TRP_LANGUAGE ) || $TRP_LANGUAGE !== $cfg['sec'] ) {
			return $url;
		}
		return self::map_url( $url, 'sec', false );
	}

	/**
	 * Convierte la ruta de una URL. $lang_expected: prefijo que debe llevar la URL ('sec'|'def').
	 * $use_rev: false = original -> traducido; true = traducido -> original.
	 */
	private static function map_url( $new_url, $lang_expected, $use_rev, $abs_home = '' ) {
		$cfg = self::cfg();
		$map = self::map();
		if ( ! $cfg || ! $map ) {
			return $new_url;
		}
		$p = wp_parse_url( $new_url );
		if ( empty( $p['path'] ) ) {
			return $new_url;
		}
		$path = $p['path'];
		$hp   = rtrim( (string) wp_parse_url( $abs_home ? $abs_home : get_option( 'home' ), PHP_URL_PATH ), '/' );
		if ( '' !== $hp && 0 === strpos( $path, $hp . '/' ) ) {
			$path = substr( $path, strlen( $hp ) );
		} else {
			$hp = '';
		}
		list( $lang, $rest ) = self::split( $path, $cfg );
		if ( $lang !== $lang_expected || '' === $rest || self::is_system_path( $rest ) ) {
			return $new_url;
		}
		$conv = $use_rev
			? self::convert( $rest, $map['rev'], $map['segrev'] )
			: self::convert( $rest, $map['pairs'], $map['seg'] );
		if ( strtolower( $conv ) === strtolower( trim( $rest, '/' ) ) ) {
			return $new_url;
		}
		return self::replace_path( $p, $hp . self::join_path( $lang, $conv, $cfg, '/' === substr( $path, -1 ) ) );
	}

	/**
	 * WordPress ve la URL reescrita (slug original). Si la URL canónica, devuelta al slug original,
	 * coincide con lo pedido, no hay que redirigir; si no (p. ej. falta la barra final), va a la URL traducida.
	 */
	public static function canonical( $redirect, $requested = '' ) {
		if ( empty( $GLOBALS['ptp_original_uri'] ) || ! is_string( $redirect ) || ! self::cfg() ) {
			return $redirect;
		}
		$en   = self::map_url( $redirect, 'sec', false ); // siempre con el slug traducido.
		$back = self::map_url( $en, 'sec', true );
		$a    = wp_parse_url( $back );
		$b    = wp_parse_url( (string) $requested );
		if ( isset( $a['path'], $b['path'] ) && $a['path'] === $b['path'] && ( isset( $a['query'] ) ? $a['query'] : '' ) === ( isset( $b['query'] ) ? $b['query'] : '' ) ) {
			return false;
		}
		return $en;
	}

	/* ------------------------------------------------------------------ */
	/* Mapa de slugs                                                       */
	/* ------------------------------------------------------------------ */

	public static function mark_dirty() {
		if ( 'tp' !== self::engine() || self::$dirty ) {
			return;
		}
		self::$dirty = true;
		add_action( 'shutdown', array( __CLASS__, 'rebuild' ) );
	}

	public static function dirty_post( $id ) {
		if ( 'tp' !== self::engine() ) {
			return;
		}
		$p = get_post( $id );
		if ( ! $p || wp_is_post_revision( $p ) || ! in_array( $p->post_type, self::types(), true ) ) {
			return;
		}
		self::mark_dirty();
	}

	/** Ruta en el idioma por defecto y en el secundario (sin barras, sin prefijo de idioma). */
	public static function paths( $p, $seg ) {
		$cfg            = self::cfg();
		self::$building = true;
		$link           = get_permalink( $p );
		self::$building = false;
		$path           = (string) wp_parse_url( $link, PHP_URL_PATH );
		$hp             = self::home_path();
		if ( '' !== $hp && 0 === strpos( $path, $hp . '/' ) ) {
			$path = substr( $path, strlen( $hp ) );
		}
		list( , $es ) = self::split( $path, $cfg );
		$parts        = '' === $es ? array() : explode( '/', $es );
		$en           = $parts;
		$fixed        = array();
		$n            = count( $parts );
		if ( $n ) {
			if ( is_post_type_hierarchical( $p->post_type ) ) {
				$chain = array_merge( array_reverse( get_post_ancestors( $p ) ), array( $p->ID ) );
				$off   = $n - count( $chain );
				if ( $off >= 0 ) {
					foreach ( $chain as $i => $cid ) {
						$s = (string) get_post_meta( $cid, self::M_SLUG, true );
						if ( '' !== $s && 0 === strcasecmp( $parts[ $off + $i ], (string) get_post_field( 'post_name', $cid ) ) ) {
							$en[ $off + $i ]    = $s;
							$fixed[ $off + $i ] = true;
						}
					}
				}
			} else {
				$s = (string) get_post_meta( $p->ID, self::M_SLUG, true );
				if ( '' !== $s && 0 === strcasecmp( $parts[ $n - 1 ], $p->post_name ) ) {
					$en[ $n - 1 ]    = $s;
					$fixed[ $n - 1 ] = true;
				}
			}
			foreach ( $en as $i => $name ) {
				$k = strtolower( $name );
				if ( empty( $fixed[ $i ] ) && isset( $seg[ $k ] ) ) {
					$en[ $i ] = $seg[ $k ];
				}
			}
		}
		return array( $es, implode( '/', $en ) );
	}

	public static function is_ready( $id ) {
		$r = (string) get_post_meta( $id, self::M_READY, true );
		if ( 'tp' === self::engine() ) {
			return '1' === $r || ( '' === $r && '' !== (string) get_post_meta( $id, self::M_SLUG, true ) );
		}
		return '0' !== $r; // qTranslate-XT: incluido salvo exclusión explícita.
	}

	public static function parse_seg( $text ) {
		$seg = $rev = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
			if ( false === strpos( $line, '=' ) ) {
				continue;
			}
			list( $a, $b ) = array_map( 'trim', explode( '=', $line, 2 ) );
			$a             = strtolower( sanitize_title( $a ) );
			$b             = strtolower( sanitize_title( $b ) );
			if ( '' === $a || '' === $b || $a === $b ) {
				continue;
			}
			$seg[ $a ] = $b;
			$rev[ $b ] = $a;
		}
		return array( $seg, $rev );
	}

	public static function rebuild() {
		self::$map = false;
		if ( 'tp' !== self::engine() || ! self::cfg() ) {
			delete_option( self::OPT_MAP );
			return;
		}
		list( $seg, $segrev ) = self::parse_seg( get_option( self::OPT_SEG, '' ) );
		$posts                = get_posts( array(
			'post_type'        => self::types(),
			'post_status'      => 'publish',
			'posts_per_page'   => -1,
			'orderby'          => 'ID',
			'order'            => 'ASC',
			'no_found_rows'    => true,
			'suppress_filters' => true,
		) );
		if ( $posts ) {
			update_meta_cache( 'post', wp_list_pluck( $posts, 'ID' ) );
		}
		$items = $pairs = $rev = $by_en = $es_set = $conf = array();
		foreach ( $posts as $p ) {
			list( $es, $en ) = self::paths( $p, $seg );
			if ( '' === $es ) {
				continue; // portada: no tiene slug.
			}
			$items[]                            = array(
				'id' => $p->ID,
				'es' => $es,
				'en' => $en,
				'rd' => (int) self::is_ready( $p->ID ),
				'lm' => $p->post_modified_gmt,
			);
			$by_en[ strtolower( $en ) ][]       = $p->ID;
			$es_set[ strtolower( $es ) ]        = $p->ID;
		}
		foreach ( $items as $it ) {
			$kes = strtolower( $it['es'] );
			$ken = strtolower( $it['en'] );
			if ( $kes === $ken ) {
				continue;
			}
			if ( count( $by_en[ $ken ] ) > 1 || ( isset( $es_set[ $ken ] ) && $es_set[ $ken ] !== $it['id'] ) ) {
				$conf[] = $it['id'];
				continue;
			}
			$pairs[ $kes ] = $it['en'];
			$rev[ $ken ]   = $it['es'];
		}
		update_option( self::OPT_MAP, array(
			'v'      => 1,
			'time'   => time(),
			'items'  => $items,
			'pairs'  => $pairs,
			'rev'    => $rev,
			'seg'    => $seg,
			'segrev' => $segrev,
			'conf'   => $conf,
		), true );
	}

	/* ------------------------------------------------------------------ */
	/* Sitemap y robots                                                    */
	/* ------------------------------------------------------------------ */

	private static function sitemap_url() {
		return rtrim( get_option( 'home' ), '/' ) . '/' . self::SITEMAP;
	}

	public static function robots( $out ) {
		$cfg = self::cfg();
		if ( ! $cfg ) {
			return $out;
		}
		if ( 'tp' === self::engine() && ! self::map() ) {
			return $out;
		}
		$out .= "\nSitemap: " . self::sitemap_url() . "\n";
		return $out;
	}

	private static function serve_sitemap() {
		$cfg = self::cfg();
		$map = self::map();
		if ( ! $cfg || ! $map ) {
			return;
		}
		$home = rtrim( get_option( 'home' ), '/' );
		$ts   = '/' === substr( (string) get_option( 'permalink_structure' ), -1 );
		$url  = function ( $lang, $path ) use ( $home, $ts, $cfg ) {
			$seg = array();
			if ( 'sec' === $lang ) {
				$seg[] = $cfg['sec_slug'];
			} elseif ( $cfg['def_dir'] ) {
				$seg[] = $cfg['def_slug'];
			}
			if ( '' !== $path ) {
				$seg[] = $path;
			}
			$u = $home . ( $seg ? '/' . implode( '/', $seg ) : '' );
			return ( $ts || ! $seg ) ? $u . '/' : $u;
		};
		$codes = function ( $locale ) {
			$p   = explode( '_', $locale );
			$out = array( implode( '-', array_slice( $p, 0, 2 ) ) );
			if ( $p[0] !== $out[0] ) {
				$out[] = $p[0];
			}
			return $out;
		};
		$esc   = function ( $s ) {
			return htmlspecialchars( $s, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
		};
		$items = array( array( 'es' => '', 'en' => '', 'rd' => 1, 'lm' => '' ) );
		foreach ( $map['items'] as $it ) {
			if ( ! empty( $it['rd'] ) ) {
				$items[] = $it;
			}
		}

		nocache_headers();
		header( 'Content-Type: application/xml; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex' );
		echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
		echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";
		foreach ( $items as $it ) {
			$alts = '';
			foreach ( array( 'def' => 'es', 'sec' => 'en' ) as $l => $k ) {
				$href = $esc( $url( $l, $it[ $k ] ) );
				foreach ( $codes( 'def' === $l ? $cfg['def'] : $cfg['sec'] ) as $c ) {
					$alts .= '<xhtml:link rel="alternate" hreflang="' . $esc( $c ) . '" href="' . $href . '"/>';
				}
			}
			$alts .= '<xhtml:link rel="alternate" hreflang="x-default" href="' . $esc( $url( 'def', $it['es'] ) ) . '"/>';
			$mod   = ( ! empty( $it['lm'] ) && '0000-00-00 00:00:00' !== $it['lm'] ) ? '<lastmod>' . gmdate( 'c', strtotime( $it['lm'] . ' UTC' ) ) . '</lastmod>' : '';
			foreach ( array( 'def' => 'es', 'sec' => 'en' ) as $l => $k ) {
				echo '<url><loc>' . $esc( $url( $l, $it[ $k ] ) ) . '</loc>' . $mod . $alts . '</url>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
			}
		}
		echo '</urlset>';
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Sitemap para qTranslate-XT                                          */
	/* ------------------------------------------------------------------ */

	/** Evita que qTranslate-XT redirija la URL del sitemap a su forma canónica con prefijo. */
	public static function qtx_keep_sitemap_url( $target, $url_orig = '', $url_info = array() ) {
		$path = (string) wp_parse_url( (string) $url_orig, PHP_URL_PATH );
		if ( self::SITEMAP === basename( $path ) ) {
			return false;
		}
		return $target;
	}

	/**
	 * URL de un contenido en un idioma concreto, con el slug traducido.
	 * El módulo Slugs de qTranslate-XT traduce según $q_config['language'], así que se cambia
	 * temporalmente esa clave y se restaura al terminar.
	 */
	private static function qtx_permalink( $id, $lang ) {
		global $q_config;
		$orig = isset( $q_config['language'] ) ? $q_config['language'] : '';
		if ( isset( $q_config['language'] ) ) {
			$q_config['language'] = $lang;
		}
		$url = get_permalink( $id );
		if ( isset( $q_config['language'] ) ) {
			$q_config['language'] = $orig;
		}
		return is_string( $url ) ? $url : '';
	}

	/** Sirve /premiero-sitemap.xml en qTranslate-XT (parse_request: $q_config y los slugs ya están cargados). */
	public static function serve_qtx_sitemap() {
		if ( 'qtx' !== self::engine() || is_admin() || empty( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$cfg = self::cfg();
		if ( ! $cfg ) {
			return;
		}
		$uri  = wp_unslash( $_SERVER['REQUEST_URI'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$hp   = self::home_path();
		if ( '' !== $hp && 0 === strpos( $path, $hp . '/' ) ) {
			$path = substr( $path, strlen( $hp ) );
		}
		$trim = trim( $path, '/' );
		if ( self::SITEMAP !== basename( $trim ) ) {
			return;
		}
		// Acepta /premiero-sitemap.xml y, si el idioma por defecto lleva prefijo, /{def}/premiero-sitemap.xml.
		if ( self::SITEMAP !== $trim && strtolower( $cfg['def_slug'] ) !== strtolower( dirname( $trim ) ) ) {
			return;
		}
		self::output_qtx_sitemap( $cfg );
	}

	/** Construye el XML con las URLs en ambos idiomas y sus alternates hreflang. */
	private static function output_qtx_sitemap( $cfg ) {
		global $q_config;
		$home  = rtrim( get_option( 'home' ), '/' );
		$sec   = $cfg['sec'];
		$posts = get_posts( array(
			'post_type'        => self::types(),
			'post_status'      => 'publish',
			'posts_per_page'   => -1,
			'orderby'          => 'ID',
			'order'            => 'ASC',
			'no_found_rows'    => true,
			'suppress_filters' => true,
		) );

		$esc   = function ( $s ) {
			return htmlspecialchars( (string) $s, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
		};
		$codes = function ( $lang ) use ( $q_config ) {
			if ( isset( $q_config['locale_html'][ $lang ] ) && '' !== $q_config['locale_html'][ $lang ] ) {
				return array( $q_config['locale_html'][ $lang ] );
			}
			$p   = explode( '_', (string) $lang );
			$out = array( implode( '-', array_slice( $p, 0, 2 ) ) );
			if ( (string) $p[0] !== $out[0] ) {
				$out[] = $p[0];
			}
			return $out;
		};

		$entries = array();
		$seen    = array();
		$add     = function ( $es, $en, $lm ) use ( &$entries, &$seen ) {
			if ( '' === $es || isset( $seen[ $es ] ) ) {
				return;
			}
			$seen[ $es ] = true;
			$entries[]   = array( 'es' => $es, 'en' => ( '' !== $en ? $en : $es ), 'lm' => $lm );
		};

		// Portada (por si es un blog/archivo y no una página incluida en $posts).
		$home_en = $home . '/';
		if ( function_exists( 'qtranxf_convertURL' ) ) {
			$conv = qtranxf_convertURL( $home . '/', $sec, false, true );
			if ( '' !== $conv ) {
				$home_en = $conv;
			}
		}
		$add( $home . '/', $home_en, '' );

		foreach ( $posts as $p ) {
			if ( '0' === (string) get_post_meta( $p->ID, self::M_READY, true ) ) {
				continue; // excluida explícitamente del sitemap.
			}
			$es = self::qtx_permalink( $p->ID, $cfg['def'] );
			if ( '' === $es ) {
				continue;
			}
			$en = self::qtx_permalink( $p->ID, $sec );
			$add( $es, $en, $p->post_modified_gmt );
		}

		nocache_headers();
		header( 'Content-Type: application/xml; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex' );
		echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
		echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";
		foreach ( $entries as $it ) {
			$alts = '';
			foreach ( array( 'def' => 'es', 'sec' => 'en' ) as $l => $k ) {
				$href = $esc( $it[ $k ] );
				foreach ( $codes( 'def' === $l ? $cfg['def'] : $cfg['sec'] ) as $c ) {
					$alts .= '<xhtml:link rel="alternate" hreflang="' . $esc( $c ) . '" href="' . $href . '"/>';
				}
			}
			$alts .= '<xhtml:link rel="alternate" hreflang="x-default" href="' . $esc( $it['es'] ) . '"/>';
			$mod   = ( ! empty( $it['lm'] ) && '0000-00-00 00:00:00' !== $it['lm'] ) ? '<lastmod>' . gmdate( 'c', strtotime( $it['lm'] . ' UTC' ) ) . '</lastmod>' : '';
			foreach ( array( 'def' => 'es', 'sec' => 'en' ) as $l => $k ) {
				echo '<url><loc>' . $esc( $it[ $k ] ) . '</loc>' . $mod . $alts . '</url>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
			}
		}
		echo '</urlset>';
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* SEO (Yoast)                                                         */
	/* ------------------------------------------------------------------ */

	public static function seo( $value, $key ) {
		$cfg  = self::cfg();
		$lang = self::lang();
		if ( ! $cfg || '' === $lang || $lang !== $cfg['sec'] || ! is_singular() ) {
			return $value;
		}
		$id = get_queried_object_id();
		if ( ! $id ) {
			return $value;
		}
		$v = (string) get_post_meta( $id, 'title' === $key ? self::M_TITLE : self::M_DESC, true );
		return '' !== $v ? $v : $value;
	}

	/* ------------------------------------------------------------------ */
	/* Campos (metabox y pantalla de administración)                       */
	/* ------------------------------------------------------------------ */

	private static function save_fields( $id, $d ) {
		$title = isset( $d['title'] ) ? sanitize_text_field( $d['title'] ) : '';
		$desc  = isset( $d['desc'] ) ? sanitize_textarea_field( $d['desc'] ) : '';
		self::set_meta( $id, self::M_TITLE, $title );
		self::set_meta( $id, self::M_DESC, $desc );
		if ( 'tp' === self::engine() ) {
			$slug = isset( $d['slug'] ) ? sanitize_title( $d['slug'] ) : '';
			self::set_meta( $id, self::M_SLUG, $slug );
			if ( ! empty( $d['ready'] ) ) {
				update_post_meta( $id, self::M_READY, '1' );
			} elseif ( '' !== $slug ) {
				update_post_meta( $id, self::M_READY, '0' );
			} else {
				delete_post_meta( $id, self::M_READY );
			}
		} else {
			// qTranslate-XT: el slug lo gestiona su módulo. Aquí solo se guarda incluir/excluir del sitemap.
			if ( ! empty( $d['ready'] ) ) {
				delete_post_meta( $id, self::M_READY ); // vacío = incluir (por defecto).
			} else {
				update_post_meta( $id, self::M_READY, '0' ); // exclusión explícita.
			}
		}
	}

	private static function set_meta( $id, $key, $val ) {
		if ( '' === $val ) {
			delete_post_meta( $id, $key );
		} else {
			update_post_meta( $id, $key, $val );
		}
	}

	private static function inputs( $id ) {
		$n     = 'ptp[' . (int) $id . ']';
		$title = (string) get_post_meta( $id, self::M_TITLE, true );
		$desc  = (string) get_post_meta( $id, self::M_DESC, true );
		$tp    = ( 'tp' === self::engine() );
		$slug  = $tp ? (string) get_post_meta( $id, self::M_SLUG, true ) : '';
		return array(
			'slug'  => $tp ? '<input type="text" class="widefat" name="' . esc_attr( $n ) . '[slug]" value="' . esc_attr( $slug ) . '" placeholder="slug-en-ingles">' : '',
			'title' => '<input type="text" class="widefat" name="' . esc_attr( $n ) . '[title]" value="' . esc_attr( $title ) . '">',
			'desc'  => '<textarea class="widefat" rows="2" name="' . esc_attr( $n ) . '[desc]">' . esc_textarea( $desc ) . '</textarea>',
			'ready' => '<input type="checkbox" name="' . esc_attr( $n ) . '[ready]" value="1"' . checked( self::is_ready( $id ), true, false ) . '>',
		);
	}

	public static function add_box() {
		if ( ! self::cfg() ) {
			return;
		}
		$title = ( 'tp' === self::engine() ) ? 'URL y SEO en ' . self::label() : 'SEO en ' . self::label();
		foreach ( self::types() as $t ) {
			add_meta_box( 'ptp_box', $title, array( __CLASS__, 'box' ), $t, 'normal', 'default' );
		}
	}

	public static function box( $post ) {
		wp_nonce_field( 'ptp_box', 'ptp_box_nonce' );
		$f = self::inputs( $post->ID );
		if ( 'tp' === self::engine() ) {
			echo '<p><label><strong>Slug (' . esc_html( self::label() ) . ')</strong></label>' . $f['slug'] . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '<p><label><strong>Título SEO (' . esc_html( self::label() ) . ')</strong></label>' . $f['title'] . '</p>'; // phpcs:ignore
		echo '<p><label><strong>Meta descripción (' . esc_html( self::label() ) . ')</strong></label>' . $f['desc'] . '</p>'; // phpcs:ignore
		echo '<p><label>' . $f['ready'] . ' Incluir en el sitemap ' . ( 'qtx' === self::engine() ? 'en inglés' : 'del idioma secundario' ) . '</label></p>'; // phpcs:ignore
		if ( 'tp' === self::engine() ) {
			echo '<p class="description">Vacío = se mantiene el valor original. El texto visible de la página se traduce con TranslatePress; aquí solo URL y SEO. Escribe el título SEO completo, tal como debe salir.</p>';
			$map = self::map();
			if ( $map && in_array( $post->ID, $map['conf'], true ) ) {
				echo '<p style="color:#b32d2e"><strong>Conflicto:</strong> este slug coincide con otra página. Cámbialo.</p>';
			}
		} else {
			echo '<p class="description">Vacío = se mantiene el título y la descripción de Yoast. El slug en inglés se edita en qTranslate-XT → Slugs translation. El texto visible se traduce con qTranslate-XT; aquí solo el SEO de Yoast.</p>';
		}
	}

	public static function save_box( $id ) {
		if ( empty( $_POST['ptp_box_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ptp_box_nonce'] ) ), 'ptp_box' ) ) {
			return;
		}
		if ( wp_is_post_revision( $id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $id ) ) {
			return;
		}
		if ( empty( $_POST['ptp'][ $id ] ) || ! is_array( $_POST['ptp'][ $id ] ) ) {
			return;
		}
		self::save_fields( $id, wp_unslash( $_POST['ptp'][ $id ] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	}

	public static function menu() {
		add_options_page( 'Premiero SEO Multilingüe', 'SEO Multilingüe', 'manage_options', 'premiero-seo-multilingue', array( __CLASS__, 'page' ) );
	}

	public static function handle_post() {
		if ( empty( $_POST['ptp_action'] ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		check_admin_referer( 'ptp_admin' );
		$a = sanitize_key( wp_unslash( $_POST['ptp_action'] ) );
		if ( 'save' === $a && ! empty( $_POST['ptp'] ) && is_array( $_POST['ptp'] ) ) {
			foreach ( wp_unslash( $_POST['ptp'] ) as $id => $d ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				$id = (int) $id;
				if ( $id && is_array( $d ) && current_user_can( 'edit_post', $id ) ) {
					self::save_fields( $id, $d );
				}
			}
		} elseif ( 'segments' === $a ) {
			update_option( self::OPT_SEG, sanitize_textarea_field( wp_unslash( isset( $_POST['ptp_segments'] ) ? $_POST['ptp_segments'] : '' ) ), false ); // phpcs:ignore
		}
		self::rebuild();
		$back = wp_get_referer();
		wp_safe_redirect( add_query_arg( 'ptp_done', 1, $back ? $back : admin_url( 'options-general.php?page=premiero-seo-multilingue' ) ) );
		exit;
	}

	/** Pantalla de administración para qTranslate-XT: SEO del idioma secundario y control del sitemap. */
	private static function page_qtx() {
		$types = self::types();
		$cur   = isset( $_GET['ptp_type'] ) ? sanitize_key( wp_unslash( $_GET['ptp_type'] ) ) : 'page'; // phpcs:ignore
		if ( ! in_array( $cur, $types, true ) ) {
			$cur = reset( $types );
		}
		$paged = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore
		$base  = admin_url( 'options-general.php?page=premiero-seo-multilingue' );

		echo '<p>Idioma secundario: <strong>' . esc_html( self::label() ) . '</strong> · Motor: <strong>qTranslate-XT</strong> · Sitemap: <a href="' . esc_url( self::sitemap_url() ) . '" target="_blank" rel="noopener">' . esc_html( self::sitemap_url() ) . '</a></p>';
		echo '<p class="description">El slug en inglés se edita en <strong>qTranslate-XT → Slugs translation</strong>. Aquí se define el título y la meta descripción de Yoast para el idioma ' . esc_html( self::label() ) . ' y si la página aparece en el sitemap.</p>';

		echo '<h2 class="nav-tab-wrapper">';
		foreach ( $types as $t ) {
			$o = get_post_type_object( $t );
			echo '<a class="nav-tab' . ( $t === $cur ? ' nav-tab-active' : '' ) . '" href="' . esc_url( add_query_arg( 'ptp_type', $t, $base ) ) . '">' . esc_html( $o ? $o->labels->name : $t ) . '</a>';
		}
		echo '</h2>';

		$q = new WP_Query( array(
			'post_type'      => $cur,
			'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
			'posts_per_page' => 40,
			'paged'          => $paged,
			'orderby'        => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
		) );

		echo '<form method="post">';
		wp_nonce_field( 'ptp_admin' );
		echo '<input type="hidden" name="ptp_action" value="save">';
		echo '<table class="widefat striped" style="margin-top:12px"><thead><tr><th style="width:40%">Título</th><th style="width:30%">Título SEO ' . esc_html( self::label() ) . '</th><th>Meta descripción ' . esc_html( self::label() ) . '</th><th style="width:60px">Sitemap</th></tr></thead><tbody>';
		foreach ( $q->posts as $p ) {
			$f = self::inputs( $p->ID );
			echo '<tr><td><strong><a href="' . esc_url( get_edit_post_link( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a></strong><br><small>' . esc_html( $p->post_status ) . '</small></td>';
			echo '<td>' . $f['title'] . '</td><td>' . $f['desc'] . '</td><td style="text-align:center">' . $f['ready'] . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( ! $q->posts ) {
			echo '<tr><td colspan="4">No hay contenido de este tipo.</td></tr>';
		}
		echo '</tbody></table>';
		submit_button( 'Guardar cambios' );
		echo '</form>';
		for ( $i = 1; $i <= (int) $q->max_num_pages; $i++ ) {
			echo ( $i === $paged ? '<strong>' . $i . '</strong> ' : '<a href="' . esc_url( add_query_arg( array( 'ptp_type' => $cur, 'paged' => $i ), $base ) ) . '">' . $i . '</a> ' ); // phpcs:ignore
		}
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		echo '<div class="wrap"><h1>Premiero SEO Multilingüe</h1>';
		if ( self::both_active() ) {
			$names = array( 'tp' => 'TranslatePress', 'qtx' => 'qTranslate-XT', 'none' => 'ninguno' );
			echo '<div class="notice notice-warning"><p>Detectados <strong>TranslatePress</strong> y <strong>qTranslate-XT</strong> activos a la vez: este plugin está funcionando en modo <strong>' . esc_html( $names[ self::engine() ] ) . '</strong>.';
			if ( ! defined( 'PTP_ENGINE' ) ) {
				echo ' Para usar el otro motor, desactiva uno de los dos o añade en <code>wp-config.php</code>: <code>define( \'PTP_ENGINE\', \'tp\' );</code> (o <code>\'qtx\'</code>).';
			}
			echo '</p></div>';
		}
		$cfg = self::cfg();
		if ( ! $cfg ) {
			if ( 'qtx' === self::engine() ) {
				$msg = 'qTranslate-XT está activo pero no detectamos un idioma secundario. Añade al menos otro idioma en <strong>Ajustes → Idiomas (qTranslate-XT)</strong>.';
			} elseif ( 'tp' === self::engine() ) {
				$msg = 'TranslatePress está activo pero no detectamos un idioma secundario, o el <strong>SEO Pack</strong> de pago está activo (en ese caso este plugin no es necesario).';
			} else {
				$msg = 'Necesitas un plugin multilingüe activo con un idioma secundario: <strong>TranslatePress</strong> (gratuito, sin el SEO Pack de pago) o <strong>qTranslate-XT</strong>.';
			}
			echo '<div class="notice notice-error"><p>' . wp_kses_post( $msg ) . '</p></div></div>';
			return;
		}
		if ( ! get_option( 'permalink_structure' ) ) {
			echo '<div class="notice notice-warning"><p>Los enlaces permanentes están en "Simple": este plugin necesita URLs amigables.</p></div>';
		}
		if ( isset( $_GET['ptp_done'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success is-dismissible"><p>Guardado.</p></div>';
		}
		if ( 'qtx' === self::engine() ) {
			self::page_qtx();
			echo '</div>';
			return;
		}
		$map = self::map();
		if ( ! $map ) {
			self::rebuild();
			$map = self::map();
		}
		$conf  = $map ? $map['conf'] : array();
		$ready = 0;
		if ( $map ) {
			foreach ( $map['items'] as $it ) {
				$ready += (int) $it['rd'];
			}
		}
		echo '<p>Idioma secundario: <strong>' . esc_html( self::label() ) . '</strong> · Motor: <strong>TranslatePress</strong> · Sitemap: <a href="' . esc_url( self::sitemap_url() ) . '" target="_blank" rel="noopener">' . esc_html( self::sitemap_url() ) . '</a> · Páginas en el sitemap: <strong>' . (int) $ready . '</strong> · Conflictos: <strong>' . count( $conf ) . '</strong></p>';

		$types = self::types();
		$cur   = isset( $_GET['ptp_type'] ) ? sanitize_key( wp_unslash( $_GET['ptp_type'] ) ) : 'page'; // phpcs:ignore
		if ( ! in_array( $cur, $types, true ) ) {
			$cur = reset( $types );
		}
		$paged = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore
		$base  = admin_url( 'options-general.php?page=premiero-seo-multilingue' );
		echo '<h2 class="nav-tab-wrapper">';
		foreach ( $types as $t ) {
			$o = get_post_type_object( $t );
			echo '<a class="nav-tab' . ( $t === $cur ? ' nav-tab-active' : '' ) . '" href="' . esc_url( add_query_arg( 'ptp_type', $t, $base ) ) . '">' . esc_html( $o ? $o->labels->name : $t ) . '</a>';
		}
		echo '</h2>';

		$q = new WP_Query( array(
			'post_type'      => $cur,
			'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
			'posts_per_page' => 40,
			'paged'          => $paged,
			'orderby'        => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
		) );
		list( $seg ) = self::parse_seg( get_option( self::OPT_SEG, '' ) );

		echo '<form method="post">';
		wp_nonce_field( 'ptp_admin' );
		echo '<input type="hidden" name="ptp_action" value="save">';
		echo '<table class="widefat striped" style="margin-top:12px"><thead><tr><th style="width:18%">Título</th><th style="width:16%">URL original</th><th style="width:16%">Slug ' . esc_html( self::label() ) . '</th><th style="width:20%">Título SEO ' . esc_html( self::label() ) . '</th><th>Meta descripción ' . esc_html( self::label() ) . '</th><th style="width:60px">Sitemap</th></tr></thead><tbody>';
		foreach ( $q->posts as $p ) {
			list( $es, $en ) = ( 'publish' === $p->post_status ) ? self::paths( $p, $seg ) : array( '', '' );
			$f               = self::inputs( $p->ID );
			$bad             = in_array( $p->ID, $conf, true );
			echo '<tr><td><strong><a href="' . esc_url( get_edit_post_link( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a></strong><br><small>' . esc_html( $p->post_status ) . '</small></td>';
			echo '<td>' . ( '' !== $es ? '<code>/' . esc_html( $es ) . '/</code>' : '—' ) . ( '' !== $en && $en !== $es ? '<br><small>→ <code>/' . esc_html( $cfg['sec_slug'] . '/' . $en ) . '/</code></small>' : '' ) . ( $bad ? '<br><strong style="color:#b32d2e">Conflicto de slug</strong>' : '' ) . '</td>';
			echo '<td>' . $f['slug'] . '</td><td>' . $f['title'] . '</td><td>' . $f['desc'] . '</td><td style="text-align:center">' . $f['ready'] . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( ! $q->posts ) {
			echo '<tr><td colspan="6">No hay contenido de este tipo.</td></tr>';
		}
		echo '</tbody></table>';
		submit_button( 'Guardar cambios' );
		echo '</form>';
		for ( $i = 1; $i <= (int) $q->max_num_pages; $i++ ) {
			echo ( $i === $paged ? '<strong>' . $i . '</strong> ' : '<a href="' . esc_url( add_query_arg( array( 'ptp_type' => $cur, 'paged' => $i ), $base ) ) . '">' . $i . '</a> ' ); // phpcs:ignore
		}

		echo '<hr><h2>Segmentos globales</h2><p>Para bases de CPT, categorías o cualquier segmento de URL que se repite. Una línea por regla, formato <code>original = traducido</code> (por ejemplo <code>noticias = news</code>).</p>';
		echo '<form method="post">';
		wp_nonce_field( 'ptp_admin' );
		echo '<input type="hidden" name="ptp_action" value="segments"><textarea name="ptp_segments" rows="6" class="large-text code">' . esc_textarea( (string) get_option( self::OPT_SEG, '' ) ) . '</textarea>';
		submit_button( 'Guardar segmentos' );
		echo '</form>';

		echo '<form method="post">';
		wp_nonce_field( 'ptp_admin' );
		echo '<input type="hidden" name="ptp_action" value="rebuild">';
		submit_button( 'Reconstruir mapa de URLs', 'secondary' );
		echo '</form></div>';
	}
}

register_activation_hook( __FILE__, array( 'PTP', 'rebuild' ) );
PTP::init();
