<?php
/**
 * WooCommerce Products Tools
 * Handles products, variations, categories, tags, and reviews
 */

if (!defined('ABSPATH')) {
    exit;
}

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedClassFound -- StifliFlexMcp is the plugin prefix
class StifliFlexMcp_WC_Products {
    
    /**
     * Get tool definitions for products
     */
    public static function getTools() {
        return array(
            // Products
            'wc_get_products' => array(
                'name' => 'wc_get_products',
                'description' => 'List WooCommerce products with filters (status, category, tag, search, limit, offset, paged, orderby, order). Optional enrichments: images, categories, attributes, variation counts, and pagination metadata.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'status'   => array('type' => 'string'),
                        'category' => array('type' => 'string'),
                        'tag'      => array('type' => 'string'),
                        'search'   => array('type' => 'string'),
                        'limit'    => array('type' => 'integer'),
                        'offset'   => array('type' => 'integer'),
                        'paged'    => array('type' => 'integer'),
                        'orderby'  => array('type' => 'string'),
                        'order'    => array('type' => 'string'),
                        'type'     => array('type' => 'string'),
                        'compact'  => array('type' => 'boolean'),
                        'include_images' => array('type' => 'boolean'),
                        'include_categories' => array('type' => 'boolean'),
                        'include_attributes' => array('type' => 'boolean'),
                        'include_variation_count' => array('type' => 'boolean'),
                        'include_pagination' => array('type' => 'boolean'),
                    ),
                    'required' => array(),
                ),
            ),
            'wc_create_product' => array(
                'name' => 'wc_create_product',
                'description' => 'Create a WooCommerce product (name, type, regular_price, description, short_description, categories, tags, images, stock_quantity, etc).',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'name'              => array('type' => 'string'),
                        'type'              => array('type' => 'string'),
                        'regular_price'     => array('type' => 'string'),
                        'sale_price'        => array('type' => 'string'),
                        'description'       => array('type' => 'string'),
                        'short_description' => array('type' => 'string'),
                        'sku'               => array('type' => 'string'),
                        'manage_stock'      => array('type' => 'boolean'),
                        'stock_quantity'    => array('type' => 'integer'),
                        'stock_status'      => array('type' => 'string'),
                        'categories'        => array('type' => 'array', 'items' => array('type' => 'integer')),
                        'tags'              => array('type' => 'array', 'items' => array('type' => 'integer')),
                        'images'            => array(
                            'type'  => 'array',
                            'items' => array(
                                'type'       => 'object',
                                'properties' => array(
                                    'id'       => array('type' => 'integer'),
                                    'src'      => array('type' => 'string'),
                                    'position' => array('type' => 'integer'),
                                    'alt'      => array('type' => 'string'),
                                ),
                                'required' => array(),
                            ),
                        ),
                        'status'            => array('type' => 'string'),
                    ),
                    'required' => array('name'),
                ),
            ),
            'wc_update_product' => array(
                'name' => 'wc_update_product',
                'description' => 'Update a WooCommerce product by ID.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id'        => array('type' => 'integer'),
                        'name'              => array('type' => 'string'),
                        'regular_price'     => array('type' => 'string'),
                        'sale_price'        => array('type' => 'string'),
                        'description'       => array('type' => 'string'),
                        'short_description' => array('type' => 'string'),
                        'sku'               => array('type' => 'string'),
                        'manage_stock'      => array('type' => 'boolean'),
                        'stock_quantity'    => array('type' => 'integer'),
                        'stock_status'      => array('type' => 'string'),
                        'categories'        => array('type' => 'array', 'items' => array('type' => 'integer')),
                        'tags'              => array('type' => 'array', 'items' => array('type' => 'integer')),
                        'status'            => array('type' => 'string'),
                    ),
                    'required' => array('product_id'),
                ),
            ),
            'wc_delete_product' => array(
                'name' => 'wc_delete_product',
                'description' => 'Delete a WooCommerce product by ID. Pass force=true to delete permanently.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id' => array('type' => 'integer'),
                        'force'      => array('type' => 'boolean'),
                    ),
                    'required' => array('product_id'),
                ),
            ),
            'wc_batch_update_products' => array(
                'name' => 'wc_batch_update_products',
                'description' => 'Batch mutate products in one request. Supports create[], update[], and delete[] arrays. Legacy updates[] is still accepted as alias of update[]. For update items, both product_id and id are accepted.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'create' => array('type' => 'array', 'items' => array('type' => 'object')),
                        'update' => array('type' => 'array', 'items' => array('type' => 'object')),
                        'delete' => array('type' => 'array', 'items' => array('type' => 'integer')),
                        'updates' => array('type' => 'array', 'items' => array('type' => 'object'), 'description' => 'Legacy alias for update[]'),
                        'force' => array('type' => 'boolean', 'description' => 'When true, permanently delete product IDs passed in delete[]'),
                    ),
                    'required' => array(),
                ),
            ),
            'wc_bulk_assign_product_categories' => array(
                'name' => 'wc_bulk_assign_product_categories',
                'description' => 'Assign categories to multiple products in one call. Set append=true to keep existing categories.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_ids' => array('type' => 'array', 'items' => array('type' => 'integer')),
                        'category_ids' => array('type' => 'array', 'items' => array('type' => 'integer')),
                        'append' => array('type' => 'boolean'),
                    ),
                    'required' => array('product_ids', 'category_ids'),
                ),
            ),
            'wc_bulk_delete_products' => array(
                'name' => 'wc_bulk_delete_products',
                'description' => 'Delete multiple WooCommerce products by ID in one call. Pass force=true to delete permanently.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_ids' => array('type' => 'array', 'items' => array('type' => 'integer')),
                        'force' => array('type' => 'boolean'),
                    ),
                    'required' => array('product_ids'),
                ),
            ),
            
            // Product Variations
            'wc_get_product_variations' => array(
                'name' => 'wc_get_product_variations',
                'description' => 'Get variations of a variable product by product_id.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id' => array('type' => 'integer'),
                    ),
                    'required' => array('product_id'),
                ),
            ),
            'wc_create_product_variation' => array(
                'name' => 'wc_create_product_variation',
                'description' => 'Create a product variation for a variable product.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id'    => array('type' => 'integer'),
                        'regular_price' => array('type' => 'string'),
                        'attributes'    => array('type' => 'object'),
                        'sku'           => array('type' => 'string'),
                        'stock_quantity'=> array('type' => 'integer'),
                    ),
                    'required' => array('product_id'),
                ),
            ),
            'wc_update_product_variation' => array(
                'name' => 'wc_update_product_variation',
                'description' => 'Update a product variation.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id'    => array('type' => 'integer'),
                        'variation_id'  => array('type' => 'integer'),
                        'regular_price' => array('type' => 'string'),
                        'attributes'    => array('type' => 'object'),
                        'stock_quantity'=> array('type' => 'integer'),
                    ),
                    'required' => array('product_id', 'variation_id'),
                ),
            ),
            'wc_delete_product_variation' => array(
                'name' => 'wc_delete_product_variation',
                'description' => 'Delete a product variation.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id'   => array('type' => 'integer'),
                        'variation_id' => array('type' => 'integer'),
                        'force'        => array('type' => 'boolean'),
                    ),
                    'required' => array('product_id', 'variation_id'),
                ),
            ),
            'wc_get_variation' => array(
                'name' => 'wc_get_variation',
                'description' => 'Get one variation by product_id and variation_id with ownership validation.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id' => array('type' => 'integer'),
                        'variation_id' => array('type' => 'integer'),
                    ),
                    'required' => array('product_id', 'variation_id'),
                ),
            ),
            'wc_batch_update_variations' => array(
                'name' => 'wc_batch_update_variations',
                'description' => 'Batch update multiple variations of a variable product.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id' => array('type' => 'integer'),
                        'updates' => array('type' => 'array', 'items' => array('type' => 'object')),
                    ),
                    'required' => array('product_id', 'updates'),
                ),
            ),
            'wc_get_product_attributes' => array(
                'name' => 'wc_get_product_attributes',
                'description' => 'List global WooCommerce product attributes (taxonomy attributes).',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => (object) array(),
                    'required' => array(),
                ),
            ),
            'wc_get_attribute_terms' => array(
                'name' => 'wc_get_attribute_terms',
                'description' => 'List terms for a WooCommerce product attribute taxonomy by attribute_id or attribute_slug.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'attribute_id' => array('type' => 'integer'),
                        'attribute_slug' => array('type' => 'string'),
                        'limit' => array('type' => 'integer'),
                        'offset' => array('type' => 'integer'),
                        'search' => array('type' => 'string'),
                    ),
                    'required' => array(),
                ),
            ),
            'wc_create_product_attribute' => array(
                'name' => 'wc_create_product_attribute',
                'description' => 'Create a global WooCommerce product attribute taxonomy.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'name' => array('type' => 'string'),
                        'slug' => array('type' => 'string'),
                        'type' => array('type' => 'string'),
                        'order_by' => array('type' => 'string'),
                        'has_archives' => array('type' => 'boolean'),
                    ),
                    'required' => array('name'),
                ),
            ),
            'wc_set_product_attributes' => array(
                'name' => 'wc_set_product_attributes',
                'description' => 'Set product attributes on a product (global taxonomy attributes or custom/local attributes).',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id' => array('type' => 'integer'),
                        'attributes' => array('type' => 'array', 'items' => array('type' => 'object')),
                    ),
                    'required' => array('product_id', 'attributes'),
                ),
            ),
            
            // Product Categories
            'wc_get_product_categories' => array(
                'name' => 'wc_get_product_categories',
                'description' => 'List WooCommerce product categories.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'hide_empty' => array('type' => 'boolean'),
                        'limit'      => array('type' => 'integer'),
                        'search'     => array('type' => 'string'),
                    ),
                    'required' => array(),
                ),
            ),
            'wc_create_product_category' => array(
                'name' => 'wc_create_product_category',
                'description' => 'Create a product category.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'name'        => array('type' => 'string'),
                        'slug'        => array('type' => 'string'),
                        'parent'      => array('type' => 'integer'),
                        'description' => array('type' => 'string'),
                    ),
                    'required' => array('name'),
                ),
            ),
            'wc_update_product_category' => array(
                'name' => 'wc_update_product_category',
                'description' => 'Update a product category.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'category_id' => array('type' => 'integer'),
                        'name'        => array('type' => 'string'),
                        'slug'        => array('type' => 'string'),
                        'description' => array('type' => 'string'),
                    ),
                    'required' => array('category_id'),
                ),
            ),
            'wc_delete_product_category' => array(
                'name' => 'wc_delete_product_category',
                'description' => 'Delete a product category by ID.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'category_id' => array('type' => 'integer'),
                        'force'       => array('type' => 'boolean'),
                    ),
                    'required' => array('category_id'),
                ),
            ),
            
            // Product Tags
            'wc_get_product_tags' => array(
                'name' => 'wc_get_product_tags',
                'description' => 'List WooCommerce product tags.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'hide_empty' => array('type' => 'boolean'),
                        'limit'      => array('type' => 'integer'),
                        'search'     => array('type' => 'string'),
                    ),
                    'required' => array(),
                ),
            ),
            'wc_create_product_tag' => array(
                'name' => 'wc_create_product_tag',
                'description' => 'Create a product tag.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'name'        => array('type' => 'string'),
                        'slug'        => array('type' => 'string'),
                        'description' => array('type' => 'string'),
                    ),
                    'required' => array('name'),
                ),
            ),
            'wc_update_product_tag' => array(
                'name' => 'wc_update_product_tag',
                'description' => 'Update a product tag.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'tag_id'      => array('type' => 'integer'),
                        'name'        => array('type' => 'string'),
                        'slug'        => array('type' => 'string'),
                        'description' => array('type' => 'string'),
                    ),
                    'required' => array('tag_id'),
                ),
            ),
            'wc_delete_product_tag' => array(
                'name' => 'wc_delete_product_tag',
                'description' => 'Delete a product tag by ID.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'tag_id' => array('type' => 'integer'),
                        'force'  => array('type' => 'boolean'),
                    ),
                    'required' => array('tag_id'),
                ),
            ),
            
            // Product Reviews
            'wc_get_product_reviews' => array(
                'name' => 'wc_get_product_reviews',
                'description' => 'List product reviews. Optionally filter by product_id.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id' => array('type' => 'integer'),
                        'status'     => array('type' => 'string'),
                        'limit'      => array('type' => 'integer'),
                    ),
                    'required' => array(),
                ),
            ),
            'wc_create_product_review' => array(
                'name' => 'wc_create_product_review',
                'description' => 'Create a product review.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id' => array('type' => 'integer'),
                        'content'    => array('type' => 'string'),
                        'author'     => array('type' => 'string'),
                        'email'      => array('type' => 'string'),
                        'rating'     => array('type' => 'integer'),
                    ),
                    'required' => array('product_id', 'content'),
                ),
            ),
            'wc_update_product_review' => array(
                'name' => 'wc_update_product_review',
                'description' => 'Update a product review.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'review_id' => array('type' => 'integer'),
                        'content'   => array('type' => 'string'),
                        'status'    => array('type' => 'string'),
                        'rating'    => array('type' => 'integer'),
                    ),
                    'required' => array('review_id'),
                ),
            ),
            'wc_delete_product_review' => array(
                'name' => 'wc_delete_product_review',
                'description' => 'Delete a product review.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'review_id' => array('type' => 'integer'),
                        'force'     => array('type' => 'boolean'),
                    ),
                    'required' => array('review_id'),
                ),
            ),
            
            // Stock Management
            'wc_update_stock' => array(
                'name' => 'wc_update_stock',
                'description' => 'Update stock quantity for a product.',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id' => array('type' => 'integer'),
                        'quantity'   => array('type' => 'integer'),
                        'operation'  => array('type' => 'string'), // 'set', 'increase', 'decrease'
                    ),
                    'required' => array('product_id', 'quantity'),
                ),
            ),
            'wc_get_low_stock_products' => array(
                'name' => 'wc_get_low_stock_products',
                'description' => 'Get products with low stock (below threshold).',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'threshold' => array('type' => 'integer'),
                        'limit'     => array('type' => 'integer'),
                    ),
                    'required' => array(),
                ),
            ),
            'wc_set_stock_status' => array(
                'name' => 'wc_set_stock_status',
                'description' => 'Set stock status for a product (instock, outofstock, onbackorder).',
                'inputSchema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'product_id' => array('type' => 'integer'),
                        'status'     => array('type' => 'string'),
                    ),
                    'required' => array('product_id', 'status'),
                ),
            ),
        );
    }
    
    /**
     * Get capability mappings for product tools
     */
    public static function getCapabilities() {
        return array(
            'wc_get_products' => 'edit_products',
            'wc_create_product' => 'edit_products',
            'wc_update_product' => 'edit_products',
            'wc_delete_product' => 'delete_products',
            'wc_batch_update_products' => 'edit_products',
            'wc_bulk_assign_product_categories' => 'manage_product_terms',
            'wc_bulk_delete_products' => 'delete_products',
            'wc_create_product_variation' => 'edit_products',
            'wc_get_product_variations' => 'edit_products',
            'wc_get_variation' => 'edit_products',
            'wc_update_product_variation' => 'edit_products',
            'wc_delete_product_variation' => 'delete_products',
            'wc_batch_update_variations' => 'edit_products',
            'wc_create_product_attribute' => 'manage_product_terms',
            'wc_set_product_attributes' => 'edit_products',
            'wc_create_product_category' => 'manage_product_terms',
            'wc_update_product_category' => 'manage_product_terms',
            'wc_delete_product_category' => 'manage_product_terms',
            'wc_create_product_tag' => 'manage_product_terms',
            'wc_update_product_tag' => 'manage_product_terms',
            'wc_delete_product_tag' => 'manage_product_terms',
            'wc_get_product_reviews' => 'moderate_comments',
            'wc_create_product_review' => 'moderate_comments',
            'wc_update_product_review' => 'moderate_comments',
            'wc_delete_product_review' => 'moderate_comments',
            'wc_update_stock' => 'edit_products',
            'wc_get_low_stock_products' => 'edit_products',
            'wc_set_stock_status' => 'edit_products',
        );
    }
    
    /**
     * Dispatch product tool execution
     */
    public static function dispatch($tool, $args, &$r, $addResultText, $utils) {
        if (!class_exists('WooCommerce')) {
            $r['error'] = array('code' => -50000, 'message' => 'WooCommerce is not active');
            return true;
        }

        $isTruthy = function($value) {
            if (is_bool($value)) {
                return $value;
            }
            if (is_int($value)) {
                return 1 === $value;
            }
            if (is_string($value)) {
                return in_array(strtolower(trim($value)), array('1', 'true', 'yes', 'on'), true);
            }
            return !empty($value);
        };
        $buildPaginationMeta = function($totalItems, $limit, $offset = 0, $paged = 1) {
            $limit = max(1, (int) $limit);
            $offset = max(0, (int) $offset);
            $paged = max(1, (int) $paged);
            $currentPage = $offset > 0 ? (int) floor($offset / $limit) + 1 : $paged;
            return array(
                'total_items' => (int) $totalItems,
                'per_page' => $limit,
                'offset' => $offset,
                'current_page' => $currentPage,
                'total_pages' => (int) ceil(max(0, (int) $totalItems) / $limit),
                'has_more' => ($offset + $limit) < (int) $totalItems,
            );
        };
        $formatDatePair = function($date) {
            if (!$date || !is_object($date) || !method_exists($date, 'getTimestamp')) {
                return array('local' => null, 'gmt' => null);
            }
            $timestamp = $date->getTimestamp();
            return array(
                'local' => method_exists($date, 'date') ? $date->date('c') : gmdate('c', $timestamp),
                'gmt' => gmdate('c', $timestamp),
            );
        };
        $buildProductRow = function($product, $compact, $includeImages, $includeCategories, $includeAttributes, $includeVariationCount) use ($formatDatePair) {
            $row = array(
                'id' => $product->get_id(),
                'name' => $product->get_name(),
                'slug' => $product->get_slug(),
                'type' => $product->get_type(),
                'status' => $product->get_status(),
                'price' => $product->get_price(),
                'stock_status' => $product->get_stock_status(),
                'permalink' => $product->get_permalink(),
            );

            if (!$compact) {
                $created = $formatDatePair($product->get_date_created());
                $modified = $formatDatePair($product->get_date_modified());
                $saleFrom = $formatDatePair($product->get_date_on_sale_from());
                $saleTo = $formatDatePair($product->get_date_on_sale_to());
                $row['regular_price'] = $product->get_regular_price();
                $row['sale_price'] = $product->get_sale_price();
                $row['sku'] = $product->get_sku();
                $row['stock_quantity'] = $product->get_stock_quantity();
                $row['catalog_visibility'] = $product->get_catalog_visibility();
                $row['featured'] = $product->get_featured();
                $row['virtual'] = $product->get_virtual();
                $row['downloadable'] = $product->get_downloadable();
                $row['purchasable'] = $product->is_purchasable();
                $row['tax_status'] = $product->get_tax_status();
                $row['tax_class'] = $product->get_tax_class();
                $row['total_sales'] = $product->get_total_sales();
                $row['date_created'] = $created['local'];
                $row['date_created_gmt'] = $created['gmt'];
                $row['date_modified'] = $modified['local'];
                $row['date_modified_gmt'] = $modified['gmt'];
                $row['date_on_sale_from'] = $saleFrom['local'];
                $row['date_on_sale_from_gmt'] = $saleFrom['gmt'];
                $row['date_on_sale_to'] = $saleTo['local'];
                $row['date_on_sale_to_gmt'] = $saleTo['gmt'];

                $subscriptionGetters = array(
                    'billing_period' => 'get_billing_period',
                    'billing_interval' => 'get_billing_interval',
                    'trial_period' => 'get_trial_period',
                    'trial_length' => 'get_trial_length',
                    'sign_up_fee' => 'get_sign_up_fee',
                );
                $subscription = array();
                foreach ($subscriptionGetters as $field => $getter) {
                    if (method_exists($product, $getter)) {
                        $subscription[$field] = $product->{$getter}();
                    }
                }
                if (!empty($subscription)) {
                    $row['subscription'] = $subscription;
                }
            }

            if ($includeImages) {
                $imageId = $product->get_image_id();
                $row['image'] = $imageId ? array(
                    'id' => $imageId,
                    'url' => wp_get_attachment_url($imageId),
                ) : null;
            }

            if ($includeCategories) {
                $categories = get_the_terms($product->get_id(), 'product_cat');
                $row['categories'] = array();
                if (!is_wp_error($categories) && !empty($categories)) {
                    foreach ($categories as $category) {
                        $row['categories'][] = array(
                            'term_id' => $category->term_id,
                            'name' => $category->name,
                            'slug' => $category->slug,
                        );
                    }
                }
            }

            if ($includeAttributes) {
                $row['attributes'] = array();
                foreach ($product->get_attributes() as $attribute) {
                    $attributeName = method_exists($attribute, 'get_name') ? $attribute->get_name() : '';
                    if ('' === $attributeName) {
                        continue;
                    }
                    if (method_exists($attribute, 'is_taxonomy') && $attribute->is_taxonomy()) {
                        $row['attributes'][$attributeName] = wp_get_post_terms($product->get_id(), $attributeName, array('fields' => 'names'));
                    } else {
                        $row['attributes'][$attributeName] = method_exists($attribute, 'get_options') ? $attribute->get_options() : array();
                    }
                }
            }

            if ($includeVariationCount) {
                $row['variation_count'] = $product->is_type('variable') ? count($product->get_children()) : 0;
            }

            return $row;
        };

        $buildVariationRow = function($variation) use ($formatDatePair) {
            $created = $formatDatePair($variation->get_date_created());
            $modified = $formatDatePair($variation->get_date_modified());
            $saleFrom = $formatDatePair($variation->get_date_on_sale_from());
            $saleTo = $formatDatePair($variation->get_date_on_sale_to());
            $row = array(
                'id' => $variation->get_id(),
                'product_id' => (int) $variation->get_parent_id(),
                'sku' => $variation->get_sku(),
                'price' => $variation->get_price(),
                'regular_price' => $variation->get_regular_price(),
                'sale_price' => $variation->get_sale_price(),
                'stock_quantity' => $variation->get_stock_quantity(),
                'stock_status' => $variation->get_stock_status(),
                'attributes' => $variation->get_attributes(),
                'virtual' => $variation->get_virtual(),
                'downloadable' => $variation->get_downloadable(),
                'purchasable' => $variation->is_purchasable(),
                'tax_status' => $variation->get_tax_status(),
                'tax_class' => $variation->get_tax_class(),
                'date_created' => $created['local'],
                'date_created_gmt' => $created['gmt'],
                'date_modified' => $modified['local'],
                'date_modified_gmt' => $modified['gmt'],
                'date_on_sale_from' => $saleFrom['local'],
                'date_on_sale_from_gmt' => $saleFrom['gmt'],
                'date_on_sale_to' => $saleTo['local'],
                'date_on_sale_to_gmt' => $saleTo['gmt'],
            );

            $subscriptionGetters = array(
                'billing_period' => 'get_billing_period',
                'billing_interval' => 'get_billing_interval',
                'trial_period' => 'get_trial_period',
                'trial_length' => 'get_trial_length',
                'sign_up_fee' => 'get_sign_up_fee',
            );
            $subscription = array();
            foreach ($subscriptionGetters as $field => $getter) {
                if (method_exists($variation, $getter)) {
                    $subscription[$field] = $variation->{$getter}();
                }
            }
            if (!empty($subscription)) {
                $row['subscription'] = $subscription;
            }

            return $row;
        };

        $syncVariableParent = function($productId) {
            $productId = (int) $productId;
            if ($productId <= 0) {
                return;
            }
            if (class_exists('WC_Product_Variable')) {
                WC_Product_Variable::sync($productId);
            }
            if (function_exists('wc_delete_product_transients')) {
                call_user_func('wc_delete_product_transients', $productId);
            }
        };
        
        switch ($tool) {
            case 'wc_get_products':
                $limit = intval($utils::getArrayValue($args, 'limit', 10));
                $limit = $limit > 0 ? $limit : 10;
                $paged = max(1, intval($utils::getArrayValue($args, 'paged', 1, 1)));
                $offset = isset($args['offset']) ? max(0, intval($args['offset'])) : (($paged - 1) * $limit);
                $compact = $isTruthy($utils::getArrayValue($args, 'compact', false));
                $includeImages = $isTruthy($utils::getArrayValue($args, 'include_images', false));
                $includeCategories = $isTruthy($utils::getArrayValue($args, 'include_categories', false));
                $includeAttributes = $isTruthy($utils::getArrayValue($args, 'include_attributes', false));
                $includeVariationCount = $isTruthy($utils::getArrayValue($args, 'include_variation_count', false));
                $includePagination = $isTruthy($utils::getArrayValue($args, 'include_pagination', false));
                $query_args = array(
                    'limit' => $limit,
                    'offset' => $offset,
                    'status' => sanitize_text_field($utils::getArrayValue($args, 'status', 'any')),
                    'orderby' => sanitize_key($utils::getArrayValue($args, 'orderby', 'date')),
                    'order' => sanitize_key($utils::getArrayValue($args, 'order', 'DESC')),
                );
                if ($includePagination) {
                    $query_args['paginate'] = true;
                }
                
                if (!empty($args['type'])) {
                    $query_args['type'] = sanitize_text_field($args['type']);
                }
                if (!empty($args['category'])) {
                    $query_args['category'] = array(sanitize_text_field($args['category']));
                }
                if (!empty($args['tag'])) {
                    $query_args['tag'] = array(sanitize_text_field($args['tag']));
                }
                if (!empty($args['search'])) {
                    $query_args['s'] = sanitize_text_field($args['search']);
                }
                
                $productsResponse = wc_get_products($query_args);
                $products = $productsResponse;
                $totalProducts = null;

                if ($includePagination && is_object($productsResponse) && isset($productsResponse->products)) {
                    $products = $productsResponse->products;
                    $totalProducts = isset($productsResponse->total) ? (int) $productsResponse->total : null;
                }
                if (!is_array($products)) {
                    $products = array();
                }

                $result = array();
                foreach ($products as $product) {
                    $result[] = $buildProductRow($product, $compact, $includeImages, $includeCategories, $includeAttributes, $includeVariationCount);
                }

                $payload = $result;
                if ($includePagination) {
                    if (null === $totalProducts) {
                        $totalProducts = count($result);
                    }
                    $payload = array(
                        'items' => $result,
                        'pagination' => $buildPaginationMeta($totalProducts, $limit, $offset, $paged),
                    );
                }
                $addResultText($r, 'Found ' . count($result) . ' products: ' . wp_json_encode($payload, JSON_PRETTY_PRINT));
                return true;
                
            case 'wc_create_product':
                $product_type = sanitize_key($utils::getArrayValue($args, 'type', 'simple'));
                
                // Create product based on type
                switch ($product_type) {
                    case 'variable':
                        $product = new WC_Product_Variable();
                        break;
                    case 'grouped':
                        $product = new WC_Product_Grouped();
                        break;
                    case 'external':
                        $product = new WC_Product_External();
                        break;
                    default:
                        $product = new WC_Product_Simple();
                }
                
                $product->set_name(sanitize_text_field($utils::getArrayValue($args, 'name', '')));
                
                if (!empty($args['description'])) {
                    $product->set_description(wp_kses_post($args['description']));
                }
                if (!empty($args['short_description'])) {
                    $product->set_short_description(wp_kses_post($args['short_description']));
                }
                if (!empty($args['sku'])) {
                    $product->set_sku(sanitize_text_field($args['sku']));
                }
                if (isset($args['regular_price'])) {
                    $product->set_regular_price(sanitize_text_field($args['regular_price']));
                }
                if (isset($args['sale_price'])) {
                    $product->set_sale_price(sanitize_text_field($args['sale_price']));
                }
                if (!empty($args['status'])) {
                    $product->set_status(sanitize_key($args['status']));
                }
                if (isset($args['stock_quantity'])) {
                    $product->set_stock_quantity(intval($args['stock_quantity']));
                    $product->set_manage_stock(true);
                }
                if (!empty($args['categories'])) {
                    $cat_ids = array_map('intval', (array) $args['categories']);
                    $product->set_category_ids($cat_ids);
                }
                if (!empty($args['tags'])) {
                    $tag_ids = array_map('intval', (array) $args['tags']);
                    $product->set_tag_ids($tag_ids);
                }
                
                // Handle attributes for variable products
                if (!empty($args['attributes']) && is_array($args['attributes'])) {
                    $attributes = array();
                    $position = 0;
                    
                    foreach ($args['attributes'] as $attr_data) {
                        $attr_name = sanitize_text_field($attr_data['name'] ?? '');
                        if (empty($attr_name)) {
                            continue;
                        }
                        
                        $attribute = new WC_Product_Attribute();
                        $attribute->set_name($attr_name);
                        $attribute->set_options(isset($attr_data['options']) ? (array) $attr_data['options'] : array());
                        $attribute->set_visible(isset($attr_data['visible']) ? (bool) $attr_data['visible'] : true);
                        $attribute->set_variation(isset($attr_data['variation']) ? (bool) $attr_data['variation'] : false);
                        $attribute->set_position($position++);
                        
                        $attributes[] = $attribute;
                    }
                    
                    if (!empty($attributes)) {
                        $product->set_attributes($attributes);
                    }
                }
                
                $product_id = $product->save();
                $addResultText($r, 'Product created with ID: ' . $product_id . ' (type: ' . $product_type . ')');
                return true;
                
            case 'wc_update_product':
                $product_id = intval($utils::getArrayValue($args, 'product_id', 0));
                if (empty($product_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_id is required');
                    return true;
                }
                
                $product = wc_get_product($product_id);
                if (!$product) {
                    $r['error'] = array('code' => -50002, 'message' => 'Product not found');
                    return true;
                }
                
                if (!empty($args['name'])) {
                    $product->set_name(sanitize_text_field($args['name']));
                }
                if (isset($args['description'])) {
                    $product->set_description(wp_kses_post($args['description']));
                }
                if (isset($args['short_description'])) {
                    $product->set_short_description(wp_kses_post($args['short_description']));
                }
                if (isset($args['regular_price'])) {
                    $product->set_regular_price(sanitize_text_field($args['regular_price']));
                }
                if (isset($args['sale_price'])) {
                    $product->set_sale_price(sanitize_text_field($args['sale_price']));
                }
                if (!empty($args['sku'])) {
                    $product->set_sku(sanitize_text_field($args['sku']));
                }
                if (!empty($args['status'])) {
                    $product->set_status(sanitize_key($args['status']));
                }
                if (isset($args['stock_quantity'])) {
                    $product->set_stock_quantity(intval($args['stock_quantity']));
                    $product->set_manage_stock(true);
                }
                if (isset($args['categories'])) {
                    $cat_ids = array_map('intval', (array) $args['categories']);
                    $product->set_category_ids($cat_ids);
                }
                if (isset($args['tags'])) {
                    $tag_ids = array_map('intval', (array) $args['tags']);
                    $product->set_tag_ids($tag_ids);
                }

                $product->save();
                $saved_product = wc_get_product($product_id);
                if (!$saved_product) {
                    $r['error'] = array('code' => -50003, 'message' => 'Product updated but could not be reloaded');
                    return true;
                }

                $saved_product_data = $buildProductRow($saved_product, false, true, true, true, true);
                $r['result'] = array(
                    'content' => array(
                        array('type' => 'text', 'text' => 'Product updated and verified: ' . wp_json_encode($saved_product_data, JSON_PRETTY_PRINT)),
                    ),
                    'structuredContent' => array(
                        'success' => true,
                        'product' => $saved_product_data,
                    ),
                );
                return true;
                
            case 'wc_delete_product':
                $product_id = intval($utils::getArrayValue($args, 'product_id', 0));
                if (empty($product_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_id is required');
                    return true;
                }
                
                $force = (bool) $utils::getArrayValue($args, 'force', false);
                $result = wp_delete_post($product_id, $force);
                
                if ($result) {
                    $addResultText($r, 'Product deleted: ' . $product_id);
                } else {
                    $r['error'] = array('code' => -50003, 'message' => 'Failed to delete product');
                }
                return true;
                
            case 'wc_batch_update_products':
                $createItems = $utils::getArrayValue($args, 'create', array());
                $updateItems = $utils::getArrayValue($args, 'update', array());
                $deleteItems = $utils::getArrayValue($args, 'delete', array());
                $legacyUpdates = $utils::getArrayValue($args, 'updates', array());
                if (!empty($legacyUpdates) && is_array($legacyUpdates) && (empty($updateItems) || !is_array($updateItems))) {
                    $updateItems = $legacyUpdates;
                }

                $hasCreate = is_array($createItems) && !empty($createItems);
                $hasUpdate = is_array($updateItems) && !empty($updateItems);
                $hasDelete = is_array($deleteItems) && !empty($deleteItems);
                if (!$hasCreate && !$hasUpdate && !$hasDelete) {
                    $r['error'] = array('code' => -50001, 'message' => 'Provide at least one of create[], update[] (or updates[]), or delete[]');
                    return true;
                }

                $forceDelete = (bool) $utils::getArrayValue($args, 'force', false);
                $resultPayload = array(
                    'created' => array(),
                    'updated' => array(),
                    'deleted' => array(),
                    'skipped' => array(),
                );

                if ($hasCreate) {
                    foreach ($createItems as $index => $createItem) {
                        if (!is_array($createItem)) {
                            $resultPayload['skipped'][] = array('operation' => 'create', 'index' => $index, 'reason' => 'Invalid create payload');
                            continue;
                        }
                        $name = sanitize_text_field((string) $utils::getArrayValue($createItem, 'name', ''));
                        if ('' === $name) {
                            $resultPayload['skipped'][] = array('operation' => 'create', 'index' => $index, 'reason' => 'name is required');
                            continue;
                        }

                        $product_type = sanitize_key((string) $utils::getArrayValue($createItem, 'type', 'simple'));
                        $supported_types = array('simple', 'variable', 'grouped', 'external');
                        if (!in_array($product_type, $supported_types, true)) {
                            $product_type = 'simple';
                        }

                        if (class_exists('WC_Product_Factory')) {
                            $factory = new WC_Product_Factory();
                            $product = $factory->get_product_classname(0, $product_type);
                            $product = class_exists($product) ? new $product() : new WC_Product_Simple();
                        } else {
                            $product = new WC_Product_Simple();
                        }

                        $product->set_name($name);
                        if (isset($createItem['description'])) {
                            $product->set_description(wp_kses_post($createItem['description']));
                        }
                        if (isset($createItem['short_description'])) {
                            $product->set_short_description(wp_kses_post($createItem['short_description']));
                        }
                        if (isset($createItem['regular_price'])) {
                            $product->set_regular_price(sanitize_text_field($createItem['regular_price']));
                        }
                        if (isset($createItem['sale_price'])) {
                            $product->set_sale_price(sanitize_text_field($createItem['sale_price']));
                        }
                        if (isset($createItem['status'])) {
                            $product->set_status(sanitize_key($createItem['status']));
                        }
                        if (isset($createItem['stock_quantity'])) {
                            $product->set_stock_quantity(intval($createItem['stock_quantity']));
                            $product->set_manage_stock(true);
                        }
                        if (isset($createItem['categories'])) {
                            $product->set_category_ids(array_map('intval', (array) $createItem['categories']));
                        }

                        $newProductId = $product->save();
                        if ($newProductId) {
                            $resultPayload['created'][] = (int) $newProductId;
                        } else {
                            $resultPayload['skipped'][] = array('operation' => 'create', 'index' => $index, 'reason' => 'Failed to create product');
                        }
                    }
                }

                if ($hasUpdate) {
                    foreach ($updateItems as $index => $update) {
                        $updateProductId = is_array($update)
                            ? intval(isset($update['product_id']) ? $update['product_id'] : (isset($update['id']) ? $update['id'] : 0))
                            : 0;

                        if (!is_array($update) || $updateProductId <= 0) {
                            $resultPayload['skipped'][] = array('operation' => 'update', 'index' => $index, 'reason' => 'product_id is required');
                            continue;
                        }

                        $productId = $updateProductId;
                        $product = wc_get_product($productId);
                        if (!$product) {
                            $resultPayload['skipped'][] = array('operation' => 'update', 'product_id' => $productId, 'reason' => 'Product not found');
                            continue;
                        }

                        if (!empty($update['name'])) {
                            $product->set_name(sanitize_text_field($update['name']));
                        }
                        if (isset($update['description'])) {
                            $product->set_description(wp_kses_post($update['description']));
                        }
                        if (isset($update['short_description'])) {
                            $product->set_short_description(wp_kses_post($update['short_description']));
                        }
                        if (isset($update['regular_price'])) {
                            $product->set_regular_price(sanitize_text_field($update['regular_price']));
                        }
                        if (isset($update['sale_price'])) {
                            $product->set_sale_price(sanitize_text_field($update['sale_price']));
                        }
                        if (isset($update['stock_quantity'])) {
                            $product->set_stock_quantity(intval($update['stock_quantity']));
                            $product->set_manage_stock(true);
                        }
                        if (isset($update['status'])) {
                            $product->set_status(sanitize_key($update['status']));
                        }
                        if (isset($update['categories'])) {
                            $product->set_category_ids(array_map('intval', (array) $update['categories']));
                        }
                        if (isset($update['tags'])) {
                            $product->set_tag_ids(array_map('intval', (array) $update['tags']));
                        }

                        $product->save();
                        $resultPayload['updated'][] = $productId;
                    }
                }

                if ($hasDelete) {
                    foreach ($deleteItems as $deleteProductIdRaw) {
                        $deleteProductId = intval($deleteProductIdRaw);
                        if ($deleteProductId <= 0) {
                            $resultPayload['skipped'][] = array('operation' => 'delete', 'product_id' => 0, 'reason' => 'Invalid product ID');
                            continue;
                        }

                        $deleted = wp_delete_post($deleteProductId, $forceDelete);
                        if ($deleted) {
                            $resultPayload['deleted'][] = $deleteProductId;
                        } else {
                            $resultPayload['skipped'][] = array('operation' => 'delete', 'product_id' => $deleteProductId, 'reason' => 'Failed to delete product');
                        }
                    }
                }

                $addResultText($r, 'Batch product mutation result: ' . wp_json_encode($resultPayload, JSON_PRETTY_PRINT));
                $r['result']['structuredContent'] = $resultPayload;
                return true;

            case 'wc_bulk_assign_product_categories':
                $product_ids = array_values(array_filter(array_map('intval', (array) $utils::getArrayValue($args, 'product_ids', array()))));
                $category_ids = array_values(array_filter(array_map('intval', (array) $utils::getArrayValue($args, 'category_ids', array()))));
                $append = (bool) $utils::getArrayValue($args, 'append', false);
                if (empty($product_ids) || empty($category_ids)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_ids and category_ids are required');
                    return true;
                }

                $assigned = array();
                $skipped = array();
                foreach ($product_ids as $product_id) {
                    $product = wc_get_product($product_id);
                    if (!$product) {
                        $skipped[] = array('product_id' => $product_id, 'reason' => 'Product not found');
                        continue;
                    }

                    $next_categories = $category_ids;
                    if ($append) {
                        $next_categories = array_values(array_unique(array_merge($product->get_category_ids(), $category_ids)));
                    }
                    $product->set_category_ids(array_map('intval', $next_categories));
                    $product->save();
                    $assigned[] = $product_id;
                }

                $payload = array(
                    'assigned' => $assigned,
                    'skipped' => $skipped,
                    'category_ids' => $category_ids,
                    'append' => $append,
                );
                $addResultText($r, 'Bulk category assignment result: ' . wp_json_encode($payload, JSON_PRETTY_PRINT));
                $r['result']['structuredContent'] = $payload;
                return true;

            case 'wc_bulk_delete_products':
                $product_ids = array_values(array_filter(array_map('intval', (array) $utils::getArrayValue($args, 'product_ids', array()))));
                $force = (bool) $utils::getArrayValue($args, 'force', false);
                if (empty($product_ids)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_ids is required');
                    return true;
                }

                $deleted = array();
                $skipped = array();
                foreach ($product_ids as $delete_product_id) {
                    $product = wc_get_product($delete_product_id);
                    if (!$product) {
                        $skipped[] = array('product_id' => $delete_product_id, 'reason' => 'Product not found');
                        continue;
                    }

                    $result = wp_delete_post($delete_product_id, $force);
                    if ($result) {
                        $deleted[] = $delete_product_id;
                    } else {
                        $skipped[] = array('product_id' => $delete_product_id, 'reason' => 'Delete failed');
                    }
                }

                $payload = array(
                    'deleted' => $deleted,
                    'skipped' => $skipped,
                    'force' => $force,
                );
                $addResultText($r, 'Bulk delete products result: ' . wp_json_encode($payload, JSON_PRETTY_PRINT));
                $r['result']['structuredContent'] = $payload;
                return true;
                
            case 'wc_get_product_variations':
                $product_id = intval($utils::getArrayValue($args, 'product_id', 0));
                if (empty($product_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_id is required');
                    return true;
                }
                
                $product = wc_get_product($product_id);
                if (!$product || !$product->is_type('variable')) {
                    $r['error'] = array('code' => -50002, 'message' => 'Product is not a variable product');
                    return true;
                }

                $variationIds = $product->get_children();
                $result = array();
                foreach ($variationIds as $variationId) {
                    $variation = wc_get_product((int) $variationId);
                    if ($variation && $variation->is_type('variation')) {
                        $result[] = $buildVariationRow($variation);
                    }
                }
                
                $addResultText($r, 'Found ' . count($result) . ' variations: ' . wp_json_encode($result, JSON_PRETTY_PRINT));
                return true;

            case 'wc_get_variation':
                $product_id = intval($utils::getArrayValue($args, 'product_id', 0));
                $variation_id = intval($utils::getArrayValue($args, 'variation_id', 0));
                if (empty($product_id) || empty($variation_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_id and variation_id are required');
                    return true;
                }

                $product = wc_get_product($product_id);
                if (!$product || !$product->is_type('variable')) {
                    $r['error'] = array('code' => -50002, 'message' => 'Product is not a variable product');
                    return true;
                }

                $variation = wc_get_product($variation_id);
                if (!$variation || !$variation->is_type('variation')) {
                    $r['error'] = array('code' => -50002, 'message' => 'Variation not found');
                    return true;
                }

                if ((int) $variation->get_parent_id() !== $product_id) {
                    $r['error'] = array('code' => -50008, 'message' => 'Variation does not belong to the provided product_id');
                    return true;
                }

                $addResultText($r, 'Variation: ' . wp_json_encode($buildVariationRow($variation), JSON_PRETTY_PRINT));
                return true;
                
            case 'wc_create_product_variation':
                $product_id = intval($utils::getArrayValue($args, 'product_id', 0));
                if (empty($product_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_id is required');
                    return true;
                }
                
                $product = wc_get_product($product_id);
                if (!$product || !$product->is_type('variable')) {
                    $r['error'] = array('code' => -50002, 'message' => 'Product is not a variable product');
                    return true;
                }
                
                $variation = new WC_Product_Variation();
                $variation->set_parent_id($product_id);
                
                if (!empty($args['attributes']) && is_array($args['attributes'])) {
                    $variation->set_attributes($args['attributes']);
                }
                if (isset($args['regular_price'])) {
                    $variation->set_regular_price(sanitize_text_field($args['regular_price']));
                }
                if (isset($args['sale_price'])) {
                    $variation->set_sale_price(sanitize_text_field($args['sale_price']));
                }
                if (!empty($args['sku'])) {
                    $variation->set_sku(sanitize_text_field($args['sku']));
                }
                if (isset($args['stock_quantity'])) {
                    $variation->set_stock_quantity(intval($args['stock_quantity']));
                    $variation->set_manage_stock(true);
                }
                
                $variation_id = $variation->save();
                if (!$variation_id) {
                    $r['error'] = array('code' => -50003, 'message' => 'Failed to create variation');
                    return true;
                }
                $syncVariableParent($product_id);
                $addResultText($r, 'Variation created with ID: ' . $variation_id);
                return true;
                
            case 'wc_update_product_variation':
                $product_id = intval($utils::getArrayValue($args, 'product_id', 0));
                $variation_id = intval($utils::getArrayValue($args, 'variation_id', 0));
                if (empty($product_id) || empty($variation_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_id and variation_id are required');
                    return true;
                }
                
                $variation = wc_get_product($variation_id);
                if (!$variation || !$variation->is_type('variation')) {
                    $r['error'] = array('code' => -50002, 'message' => 'Variation not found');
                    return true;
                }

                if ((int) $variation->get_parent_id() !== $product_id) {
                    $r['error'] = array('code' => -50008, 'message' => 'Variation does not belong to the provided product_id');
                    return true;
                }
                
                if (isset($args['regular_price'])) {
                    $variation->set_regular_price(sanitize_text_field($args['regular_price']));
                }
                if (isset($args['sale_price'])) {
                    $variation->set_sale_price(sanitize_text_field($args['sale_price']));
                }
                if (isset($args['sku'])) {
                    $variation->set_sku(sanitize_text_field($args['sku']));
                }
                if (isset($args['stock_quantity'])) {
                    $variation->set_stock_quantity(intval($args['stock_quantity']));
                }
                if (isset($args['attributes']) && is_array($args['attributes'])) {
                    $variation->set_attributes($args['attributes']);
                }
                
                $variation->save();
                $syncVariableParent($product_id);
                $addResultText($r, 'Variation updated: ' . $variation_id);
                return true;

            case 'wc_batch_update_variations':
                $product_id = intval($utils::getArrayValue($args, 'product_id', 0));
                $updates = $utils::getArrayValue($args, 'updates', array());
                if (empty($product_id) || empty($updates) || !is_array($updates)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_id and updates array are required');
                    return true;
                }

                $product = wc_get_product($product_id);
                if (!$product || !$product->is_type('variable')) {
                    $r['error'] = array('code' => -50002, 'message' => 'Product is not a variable product');
                    return true;
                }

                $updated = array();
                $skipped = array();
                foreach ($updates as $update) {
                    $variation_id = isset($update['variation_id']) ? intval($update['variation_id']) : 0;
                    if ($variation_id <= 0) {
                        $skipped[] = array('variation_id' => 0, 'reason' => 'variation_id is required');
                        continue;
                    }

                    $variation = wc_get_product($variation_id);
                    if (!$variation || !$variation->is_type('variation')) {
                        $skipped[] = array('variation_id' => $variation_id, 'reason' => 'Variation not found');
                        continue;
                    }

                    if ((int) $variation->get_parent_id() !== $product_id) {
                        $skipped[] = array('variation_id' => $variation_id, 'reason' => 'Variation does not belong to product_id');
                        continue;
                    }

                    if (isset($update['regular_price'])) {
                        $variation->set_regular_price(sanitize_text_field($update['regular_price']));
                    }
                    if (isset($update['sale_price'])) {
                        $variation->set_sale_price(sanitize_text_field($update['sale_price']));
                    }
                    if (isset($update['sku'])) {
                        $variation->set_sku(sanitize_text_field($update['sku']));
                    }
                    if (isset($update['stock_quantity'])) {
                        $variation->set_stock_quantity(intval($update['stock_quantity']));
                        $variation->set_manage_stock(true);
                    }
                    if (isset($update['attributes']) && is_array($update['attributes'])) {
                        $variation->set_attributes($update['attributes']);
                    }

                    $variation->save();
                    $updated[] = $variation_id;
                }

                if (!empty($updated)) {
                    $syncVariableParent($product_id);
                }

                $payload = array(
                    'product_id' => $product_id,
                    'updated' => $updated,
                    'skipped' => $skipped,
                );
                $addResultText($r, 'Batch variation update result: ' . wp_json_encode($payload, JSON_PRETTY_PRINT));
                return true;
                
            case 'wc_delete_product_variation':
                $product_id = intval($utils::getArrayValue($args, 'product_id', 0));
                $variation_id = intval($utils::getArrayValue($args, 'variation_id', 0));
                if (empty($product_id) || empty($variation_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_id and variation_id are required');
                    return true;
                }

                $variation = wc_get_product($variation_id);
                if (!$variation || !$variation->is_type('variation')) {
                    $r['error'] = array('code' => -50002, 'message' => 'Variation not found');
                    return true;
                }

                if ((int) $variation->get_parent_id() !== $product_id) {
                    $r['error'] = array('code' => -50008, 'message' => 'Variation does not belong to the provided product_id');
                    return true;
                }
                
                $force = (bool) $utils::getArrayValue($args, 'force', false);
                $result = wp_delete_post($variation_id, $force);
                
                if ($result) {
                    $syncVariableParent($product_id);
                    $addResultText($r, 'Variation deleted: ' . $variation_id);
                } else {
                    $r['error'] = array('code' => -50003, 'message' => 'Failed to delete variation');
                }
                return true;

            case 'wc_get_product_attributes':
                if (!function_exists('wc_get_attribute_taxonomies')) {
                    $r['error'] = array('code' => -50000, 'message' => 'WooCommerce attribute API is unavailable');
                    return true;
                }

                $attributeTaxonomies = wc_get_attribute_taxonomies();
                $result = array();
                foreach ((array) $attributeTaxonomies as $attributeTaxonomy) {
                    $taxonomy = wc_attribute_taxonomy_name($attributeTaxonomy->attribute_name);
                    $result[] = array(
                        'id' => (int) $attributeTaxonomy->attribute_id,
                        'name' => $attributeTaxonomy->attribute_label,
                        'slug' => $attributeTaxonomy->attribute_name,
                        'taxonomy' => $taxonomy,
                        'type' => $attributeTaxonomy->attribute_type,
                        'order_by' => $attributeTaxonomy->attribute_orderby,
                        'has_archives' => !empty($attributeTaxonomy->attribute_public),
                    );
                }

                $addResultText($r, 'Found ' . count($result) . ' product attributes: ' . wp_json_encode($result, JSON_PRETTY_PRINT));
                return true;

            case 'wc_get_attribute_terms':
                $attribute_id = intval($utils::getArrayValue($args, 'attribute_id', 0));
                $attribute_slug = sanitize_title($utils::getArrayValue($args, 'attribute_slug', ''));
                if ($attribute_id <= 0 && '' === $attribute_slug) {
                    $r['error'] = array('code' => -50001, 'message' => 'attribute_id or attribute_slug is required');
                    return true;
                }

                $taxonomy = '';
                if ($attribute_id > 0 && function_exists('wc_attribute_taxonomy_name_by_id')) {
                    $taxonomy = (string) wc_attribute_taxonomy_name_by_id($attribute_id);
                }
                if ('' === $taxonomy && '' !== $attribute_slug) {
                    $taxonomy = 0 === strpos($attribute_slug, 'pa_') ? $attribute_slug : wc_attribute_taxonomy_name($attribute_slug);
                }

                if ('' === $taxonomy || !taxonomy_exists($taxonomy)) {
                    $r['error'] = array('code' => -50002, 'message' => 'Attribute taxonomy not found');
                    return true;
                }

                $termsArgs = array(
                    'taxonomy' => $taxonomy,
                    'hide_empty' => false,
                    'number' => intval($utils::getArrayValue($args, 'limit', 100)),
                    'offset' => intval($utils::getArrayValue($args, 'offset', 0)),
                );
                if (!empty($args['search'])) {
                    $termsArgs['search'] = sanitize_text_field($args['search']);
                }

                $terms = get_terms($termsArgs);
                if (is_wp_error($terms)) {
                    $r['error'] = array('code' => -50004, 'message' => $terms->get_error_message());
                    return true;
                }

                $result = array();
                foreach ($terms as $term) {
                    $result[] = array(
                        'term_id' => (int) $term->term_id,
                        'name' => $term->name,
                        'slug' => $term->slug,
                        'count' => (int) $term->count,
                    );
                }

                $addResultText($r, 'Found ' . count($result) . ' attribute terms for ' . $taxonomy . ': ' . wp_json_encode($result, JSON_PRETTY_PRINT));
                return true;

            case 'wc_create_product_attribute':
                if (!function_exists('wc_create_attribute')) {
                    $r['error'] = array('code' => -50000, 'message' => 'WooCommerce attribute API is unavailable');
                    return true;
                }

                $name = sanitize_text_field($utils::getArrayValue($args, 'name', ''));
                if ('' === $name) {
                    $r['error'] = array('code' => -50001, 'message' => 'name is required');
                    return true;
                }

                $attributeData = array(
                    'name' => $name,
                    'slug' => sanitize_title($utils::getArrayValue($args, 'slug', '')),
                    'type' => sanitize_key($utils::getArrayValue($args, 'type', 'select')),
                    'order_by' => sanitize_key($utils::getArrayValue($args, 'order_by', 'menu_order')),
                    'has_archives' => !empty($args['has_archives']) ? 1 : 0,
                );

                if (!in_array($attributeData['type'], array('select', 'text'), true)) {
                    $attributeData['type'] = 'select';
                }
                if (!in_array($attributeData['order_by'], array('menu_order', 'name', 'name_num', 'id'), true)) {
                    $attributeData['order_by'] = 'menu_order';
                }

                $attributeId = wc_create_attribute($attributeData);
                if (is_wp_error($attributeId)) {
                    $r['error'] = array('code' => -50004, 'message' => $attributeId->get_error_message());
                    return true;
                }

                delete_transient('wc_attribute_taxonomies');
                $addResultText($r, 'Product attribute created with ID: ' . intval($attributeId));
                return true;

            case 'wc_set_product_attributes':
                $product_id = intval($utils::getArrayValue($args, 'product_id', 0));
                $attributesInput = $utils::getArrayValue($args, 'attributes', array());
                if ($product_id <= 0 || !is_array($attributesInput)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_id and attributes array are required');
                    return true;
                }

                $product = wc_get_product($product_id);
                if (!$product) {
                    $r['error'] = array('code' => -50002, 'message' => 'Product not found');
                    return true;
                }

                $attributes = array();
                $position = 0;
                foreach ($attributesInput as $attrData) {
                    if (!is_array($attrData)) {
                        continue;
                    }

                    $attribute = new WC_Product_Attribute();
                    $attributeId = isset($attrData['id']) ? intval($attrData['id']) : 0;
                    $visible = isset($attrData['visible']) ? (bool) $attrData['visible'] : true;
                    $variation = isset($attrData['variation']) ? (bool) $attrData['variation'] : false;
                    $rawOptions = isset($attrData['options']) && is_array($attrData['options']) ? $attrData['options'] : array();

                    if ($attributeId > 0 && function_exists('wc_attribute_taxonomy_name_by_id')) {
                        $taxonomy = (string) wc_attribute_taxonomy_name_by_id($attributeId);
                        if ('' === $taxonomy || !taxonomy_exists($taxonomy)) {
                            continue;
                        }

                        $termIds = array();
                        foreach ($rawOptions as $optionValue) {
                            if (is_numeric($optionValue)) {
                                $termIds[] = intval($optionValue);
                                continue;
                            }

                            $termName = sanitize_text_field((string) $optionValue);
                            if ('' === $termName) {
                                continue;
                            }

                            $existing = term_exists($termName, $taxonomy);
                            if (empty($existing)) {
                                $created = wp_insert_term($termName, $taxonomy);
                                if (is_wp_error($created) || empty($created['term_id'])) {
                                    continue;
                                }
                                $termIds[] = (int) $created['term_id'];
                            } else {
                                $termIds[] = is_array($existing) ? (int) $existing['term_id'] : (int) $existing;
                            }
                        }

                        $attribute->set_id($attributeId);
                        $attribute->set_name($taxonomy);
                        $attribute->set_options(array_values(array_unique(array_filter($termIds))));
                    } else {
                        $name = sanitize_text_field(isset($attrData['name']) ? $attrData['name'] : '');
                        if ('' === $name) {
                            continue;
                        }

                        $options = array();
                        foreach ($rawOptions as $optionValue) {
                            $optionValue = sanitize_text_field((string) $optionValue);
                            if ('' !== $optionValue) {
                                $options[] = $optionValue;
                            }
                        }

                        $attribute->set_id(0);
                        $attribute->set_name($name);
                        $attribute->set_options($options);
                    }

                    $attribute->set_visible($visible);
                    $attribute->set_variation($variation);
                    $attribute->set_position($position++);
                    $attributes[] = $attribute;
                }

                if (empty($attributes)) {
                    $r['error'] = array('code' => -50001, 'message' => 'No valid attributes were provided');
                    return true;
                }

                $product->set_attributes($attributes);
                $product->save();
                if ($product->is_type('variable')) {
                    $syncVariableParent($product_id);
                }

                $addResultText($r, 'Updated attributes for product #' . $product_id . ' (' . count($attributes) . ' attributes)');
                return true;
                
            case 'wc_get_product_categories':
                $args_tax = array(
                    'taxonomy' => 'product_cat',
                    'hide_empty' => (bool) $utils::getArrayValue($args, 'hide_empty', false),
                    'number' => intval($utils::getArrayValue($args, 'limit', 100)),
                    'offset' => intval($utils::getArrayValue($args, 'offset', 0)),
                );
                
                if (!empty($args['search'])) {
                    $args_tax['search'] = sanitize_text_field($args['search']);
                }
                
                $terms = get_terms($args_tax);
                $result = array();
                
                if (!is_wp_error($terms)) {
                    foreach ($terms as $term) {
                        $result[] = array(
                            'id' => $term->term_id,
                            'name' => $term->name,
                            'slug' => $term->slug,
                            'count' => $term->count,
                            'parent' => $term->parent,
                        );
                    }
                }
                
                $addResultText($r, 'Found ' . count($result) . ' categories: ' . wp_json_encode($result, JSON_PRETTY_PRINT));
                return true;
                
            case 'wc_create_product_category':
                $name = sanitize_text_field($utils::getArrayValue($args, 'name', ''));
                if (empty($name)) {
                    $r['error'] = array('code' => -50001, 'message' => 'name is required');
                    return true;
                }
                
                $term_args = array();
                if (!empty($args['slug'])) {
                    $term_args['slug'] = sanitize_title($args['slug']);
                }
                if (!empty($args['description'])) {
                    $term_args['description'] = sanitize_textarea_field($args['description']);
                }
                if (!empty($args['parent'])) {
                    $term_args['parent'] = intval($args['parent']);
                }
                
                $result = wp_insert_term($name, 'product_cat', $term_args);
                
                if (is_wp_error($result)) {
                    $r['error'] = array('code' => -50004, 'message' => $result->get_error_message());
                } else {
                    $addResultText($r, 'Category created with ID: ' . $result['term_id']);
                }
                return true;
                
            case 'wc_update_product_category':
                $term_id = intval($utils::getArrayValue($args, 'category_id', 0));
                if (empty($term_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'category_id is required');
                    return true;
                }
                
                $term_args = array();
                if (!empty($args['name'])) {
                    $term_args['name'] = sanitize_text_field($args['name']);
                }
                if (isset($args['slug'])) {
                    $term_args['slug'] = sanitize_title($args['slug']);
                }
                if (isset($args['description'])) {
                    $term_args['description'] = sanitize_textarea_field($args['description']);
                }
                if (isset($args['parent'])) {
                    $term_args['parent'] = intval($args['parent']);
                }
                
                $result = wp_update_term($term_id, 'product_cat', $term_args);
                
                if (is_wp_error($result)) {
                    $r['error'] = array('code' => -50004, 'message' => $result->get_error_message());
                } else {
                    $addResultText($r, 'Category updated: ' . $term_id);
                }
                return true;
                
            case 'wc_delete_product_category':
                $term_id = intval($utils::getArrayValue($args, 'category_id', 0));
                if (empty($term_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'category_id is required');
                    return true;
                }
                
                $result = wp_delete_term($term_id, 'product_cat');
                
                if (is_wp_error($result)) {
                    $r['error'] = array('code' => -50004, 'message' => $result->get_error_message());
                } else {
                    $addResultText($r, 'Category deleted: ' . $term_id);
                }
                return true;
                
            case 'wc_get_product_tags':
                $args_tax = array(
                    'taxonomy' => 'product_tag',
                    'hide_empty' => (bool) $utils::getArrayValue($args, 'hide_empty', false),
                    'number' => intval($utils::getArrayValue($args, 'limit', 100)),
                    'offset' => intval($utils::getArrayValue($args, 'offset', 0)),
                );
                
                if (!empty($args['search'])) {
                    $args_tax['search'] = sanitize_text_field($args['search']);
                }
                
                $terms = get_terms($args_tax);
                $result = array();
                
                if (!is_wp_error($terms)) {
                    foreach ($terms as $term) {
                        $result[] = array(
                            'id' => $term->term_id,
                            'name' => $term->name,
                            'slug' => $term->slug,
                            'count' => $term->count,
                        );
                    }
                }
                
                $addResultText($r, 'Found ' . count($result) . ' tags: ' . wp_json_encode($result, JSON_PRETTY_PRINT));
                return true;
                
            case 'wc_create_product_tag':
                $name = sanitize_text_field($utils::getArrayValue($args, 'name', ''));
                if (empty($name)) {
                    $r['error'] = array('code' => -50001, 'message' => 'name is required');
                    return true;
                }
                
                $term_args = array();
                if (!empty($args['slug'])) {
                    $term_args['slug'] = sanitize_title($args['slug']);
                }
                if (!empty($args['description'])) {
                    $term_args['description'] = sanitize_textarea_field($args['description']);
                }
                
                $result = wp_insert_term($name, 'product_tag', $term_args);
                
                if (is_wp_error($result)) {
                    $r['error'] = array('code' => -50004, 'message' => $result->get_error_message());
                } else {
                    $addResultText($r, 'Tag created with ID: ' . $result['term_id']);
                }
                return true;
                
            case 'wc_update_product_tag':
                $term_id = intval($utils::getArrayValue($args, 'tag_id', 0));
                if (empty($term_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'tag_id is required');
                    return true;
                }
                
                $term_args = array();
                if (!empty($args['name'])) {
                    $term_args['name'] = sanitize_text_field($args['name']);
                }
                if (isset($args['slug'])) {
                    $term_args['slug'] = sanitize_title($args['slug']);
                }
                if (isset($args['description'])) {
                    $term_args['description'] = sanitize_textarea_field($args['description']);
                }
                
                $result = wp_update_term($term_id, 'product_tag', $term_args);
                
                if (is_wp_error($result)) {
                    $r['error'] = array('code' => -50004, 'message' => $result->get_error_message());
                } else {
                    $addResultText($r, 'Tag updated: ' . $term_id);
                }
                return true;
                
            case 'wc_delete_product_tag':
                $term_id = intval($utils::getArrayValue($args, 'tag_id', 0));
                if (empty($term_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'tag_id is required');
                    return true;
                }
                
                $result = wp_delete_term($term_id, 'product_tag');
                
                if (is_wp_error($result)) {
                    $r['error'] = array('code' => -50004, 'message' => $result->get_error_message());
                } else {
                    $addResultText($r, 'Tag deleted: ' . $term_id);
                }
                return true;
                
            case 'wc_get_product_reviews':
                $query_args = array(
                    'post_type' => 'product',
                    'status' => 'approve',
                    'number' => intval($utils::getArrayValue($args, 'limit', 10)),
                    'offset' => intval($utils::getArrayValue($args, 'offset', 0)),
                );
                
                if (!empty($args['product_id'])) {
                    $query_args['post_id'] = intval($args['product_id']);
                }
                
                $comments = get_comments($query_args);
                $result = array();
                
                foreach ($comments as $comment) {
                    $result[] = array(
                        'id' => $comment->comment_ID,
                        'product_id' => $comment->comment_post_ID,
                        'author' => $comment->comment_author,
                        'email' => $comment->comment_author_email,
                        'content' => $comment->comment_content,
                        'rating' => get_comment_meta($comment->comment_ID, 'rating', true),
                        'date' => $comment->comment_date,
                    );
                }
                
                $addResultText($r, 'Found ' . count($result) . ' reviews: ' . wp_json_encode($result, JSON_PRETTY_PRINT));
                return true;
                
            case 'wc_create_product_review':
                $product_id = intval($utils::getArrayValue($args, 'product_id', 0));
                $content = wp_kses_post($utils::getArrayValue($args, 'content', ''));
                
                if (empty($product_id) || empty($content)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_id and content are required');
                    return true;
                }
                
                $comment_data = array(
                    'comment_post_ID' => $product_id,
                    'comment_content' => $content,
                    'comment_type' => 'review',
                    'comment_approved' => 1,
                );
                
                if (!empty($args['author'])) {
                    $comment_data['comment_author'] = sanitize_text_field($args['author']);
                }
                if (!empty($args['email'])) {
                    $comment_data['comment_author_email'] = sanitize_email($args['email']);
                }
                
                $comment_id = wp_insert_comment($comment_data);
                
                if ($comment_id && !empty($args['rating'])) {
                    update_comment_meta($comment_id, 'rating', intval($args['rating']));
                }
                
                $addResultText($r, 'Review created with ID: ' . $comment_id);
                return true;
                
            case 'wc_update_product_review':
                $review_id = intval($utils::getArrayValue($args, 'review_id', 0));
                if (empty($review_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'review_id is required');
                    return true;
                }
                
                $comment_data = array('comment_ID' => $review_id);
                
                if (isset($args['content'])) {
                    $comment_data['comment_content'] = wp_kses_post($args['content']);
                }
                if (isset($args['status'])) {
                    $comment_data['comment_approved'] = sanitize_key($args['status']);
                }
                
                $result = wp_update_comment($comment_data);
                
                if ($result && isset($args['rating'])) {
                    update_comment_meta($review_id, 'rating', intval($args['rating']));
                }
                
                $addResultText($r, 'Review updated: ' . $review_id);
                return true;
                
            case 'wc_delete_product_review':
                $review_id = intval($utils::getArrayValue($args, 'review_id', 0));
                if (empty($review_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'review_id is required');
                    return true;
                }
                
                $force = (bool) $utils::getArrayValue($args, 'force', false);
                $result = wp_delete_comment($review_id, $force);
                
                if ($result) {
                    $addResultText($r, 'Review deleted: ' . $review_id);
                } else {
                    $r['error'] = array('code' => -50003, 'message' => 'Failed to delete review');
                }
                return true;
                
            // Stock Management
            case 'wc_update_stock':
                $product_id = intval($utils::getArrayValue($args, 'product_id', 0));
                $quantity = intval($utils::getArrayValue($args, 'quantity', 0));
                $operation = sanitize_key($utils::getArrayValue($args, 'operation', 'set'));
                
                if (empty($product_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_id is required');
                    return true;
                }
                
                $product = wc_get_product($product_id);
                if (!$product) {
                    $r['error'] = array('code' => -50002, 'message' => 'Product not found');
                    return true;
                }
                
                $product->set_manage_stock(true);
                
                switch ($operation) {
                    case 'increase':
                        $new_stock = $product->get_stock_quantity() + $quantity;
                        $product->set_stock_quantity($new_stock);
                        break;
                    case 'decrease':
                        $new_stock = $product->get_stock_quantity() - $quantity;
                        $product->set_stock_quantity($new_stock);
                        break;
                    case 'set':
                    default:
                        $product->set_stock_quantity($quantity);
                        break;
                }
                
                $product->save();
                
                $addResultText($r, 'Stock updated for product #' . $product_id . ': ' . $product->get_stock_quantity());
                return true;
                
            case 'wc_get_low_stock_products':
                $threshold = intval($utils::getArrayValue($args, 'threshold', 5));
                $limit = intval($utils::getArrayValue($args, 'limit', 50));
                
                $query_args = array(
                    'limit' => $limit,
                    'stock_quantity' => array(0, $threshold),
                    'stock_status' => 'instock',
                );
                
                $products = wc_get_products($query_args);
                $result = array();
                
                foreach ($products as $product) {
                    if ($product->managing_stock()) {
                        $stock_qty = $product->get_stock_quantity();
                        if ($stock_qty !== null && $stock_qty <= $threshold) {
                            $result[] = array(
                                'id' => $product->get_id(),
                                'name' => $product->get_name(),
                                'sku' => $product->get_sku(),
                                'stock_quantity' => $stock_qty,
                                'stock_status' => $product->get_stock_status(),
                            );
                        }
                    }
                }
                
                $addResultText($r, 'Found ' . count($result) . ' low stock products: ' . wp_json_encode($result, JSON_PRETTY_PRINT));
                return true;
                
            case 'wc_set_stock_status':
                $product_id = intval($utils::getArrayValue($args, 'product_id', 0));
                $status = sanitize_key($utils::getArrayValue($args, 'status', 'instock'));
                
                if (empty($product_id)) {
                    $r['error'] = array('code' => -50001, 'message' => 'product_id is required');
                    return true;
                }
                
                if (!in_array($status, array('instock', 'outofstock', 'onbackorder'), true)) {
                    $r['error'] = array('code' => -50007, 'message' => 'Invalid stock status. Must be: instock, outofstock, or onbackorder');
                    return true;
                }
                
                $product = wc_get_product($product_id);
                if (!$product) {
                    $r['error'] = array('code' => -50002, 'message' => 'Product not found');
                    return true;
                }
                
                $product->set_stock_status($status);
                $product->save();
                
                $addResultText($r, 'Stock status set to "' . $status . '" for product #' . $product_id);
                return true;
        }
        
        return null; // Tool not handled by this module
    }
}
