<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class StifliFlexMcp_Plugin_Integrations_Registry {

    public static function get_integrations() {
        return array(
            array(
                'id' => 'all_sources_images',
                'name' => 'All Sources Images',
                'description' => 'Find stock images, generate AI images, and set featured/inline images in posts.',
                'plugin_files' => array( 'all-sources-images/all-sources-images.php' ),
                'install_slug' => 'all-sources-images',
                'featured' => true,
                'featured_label' => 'Recommended!',
                'match' => array(
                    // Discover abilities dynamically (allsi/* -> ability_allsi_*).
                    'prefixes' => array( 'ability_allsi_' ),
                ),
                'catalog_tools' => array(),
            ),
            array(
                'id' => 'stifli_backup_tools',
                'name' => 'Stifli Backup Tools',
                'description' => 'Backup and restore workflows for WordPress using plugin abilities discoverable from MCP.',
                'plugin_files' => array( 'stifli-backup-tools/stifli-backup-tools.php' ),
                'install_slug' => 'stifli-backup-tools',
                'featured' => true,
                'featured_label' => 'Recommended!',
                'match' => array(
                    // Discover abilities dynamically (stifbt/* -> ability_stifbt_*).
                    'prefixes' => array( 'ability_stifbt_' ),
                ),
                'catalog_tools' => array(),
            ),
            array(
                'id' => 'aipatch_security_scanner',
                'name' => 'AiPatch Security Scanner',
                'description' => 'Security auditing and vulnerability scanning with AI-powered recommendations.',
                'plugin_files' => array( 'aipatch-security-scanner/aipatch-security-scanner.php' ),
                'install_slug' => 'aipatch-security-scanner',
                'featured' => true,
                'featured_label' => 'Recommended!',
                'match' => array(
                    // Auto-discover abilities with aipatch/ prefix
                    'prefixes' => array( 'ability_aipatch_' ),
                ),
                'catalog_tools' => array(),
            ),
            array(
                'id' => 'notification_for_telegram',
                'name' => 'Notification for Telegram',
                'description' => 'Send Telegram notifications from MCP tools via discovered plugin abilities.',
                'plugin_files' => array(
                    'notification-for-telegram/index.php',
                    'notification-for-telegram/notification-for-telegram.php',
                ),
                'install_slug' => 'notification-for-telegram',
                'match' => array(
                    // notification-for-telegram/send-message -> ability_notification_for_telegram_send_message
                    'prefixes' => array( 'ability_notification_for_telegram_' ),
                ),
                'catalog_tools' => array(),
            ),
            array(
                'id' => 'wpcode',
                'name' => 'WPCode',
                'description' => 'Snippet automation pack shared across snippets plugins.',
                'plugin_files' => array( 'insert-headers-and-footers/ihaf.php' ),
                'install_slug' => 'insert-headers-and-footers',
                'match' => array(
                    'prefixes' => array( 'snippet_' ),
                ),
                'catalog_tools' => array( 'snippet_list', 'snippet_get', 'snippet_create', 'snippet_update', 'snippet_delete' ),
            ),
            array(
                'id' => 'code_snippets',
                'name' => 'Code Snippets',
                'description' => 'Uses the same snippets tool pack as WPCode and Woody.',
                'plugin_files' => array( 'code-snippets/code-snippets.php' ),
                'install_slug' => 'code-snippets',
                'match' => array(
                    'prefixes' => array( 'snippet_' ),
                ),
                'catalog_tools' => array( 'snippet_list', 'snippet_get', 'snippet_create', 'snippet_update', 'snippet_delete' ),
            ),
            array(
                'id' => 'woody_snippets',
                'name' => 'Woody Snippets',
                'description' => 'Alternative snippets provider that shares snippet_* tools.',
                'plugin_files' => array( 'insert-php-code-snippet/insert-php-code-snippet.php' ),
                'install_slug' => 'insert-php-code-snippet',
                'match' => array(
                    'prefixes' => array( 'snippet_' ),
                ),
                'catalog_tools' => array( 'snippet_list', 'snippet_get', 'snippet_create', 'snippet_update', 'snippet_delete' ),
            ),
            array(
                'id' => 'acf_catalog',
                'name' => 'Advanced Custom Fields Catalog',
                'description' => 'Tools for reading and updating ACF fields and field groups.',
                'plugin_files' => array( 'advanced-custom-fields/acf.php' ),
                'install_slug' => 'advanced-custom-fields',
                'match' => array(
                    'tools' => array( 'acf_get_fields', 'acf_update_field', 'acf_get_field_groups' ),
                ),
                'catalog_tools' => array( 'acf_get_fields', 'acf_update_field', 'acf_get_field_groups' ),
            ),
            array(
                'id' => 'yoast_catalog',
                'name' => 'Yoast SEO Catalog',
                'description' => 'SEO tools for reading and updating Yoast metadata and indexing tasks.',
                'plugin_files' => array( 'wordpress-seo/wp-seo.php' ),
                'install_slug' => 'wordpress-seo',
                'match' => array(
                    'tools' => array( 'yoast_get_meta', 'yoast_get_schema', 'yoast_set_meta', 'yoast_reindex' ),
                ),
                'catalog_tools' => array( 'yoast_get_meta', 'yoast_get_schema', 'yoast_set_meta', 'yoast_reindex' ),
            ),
            array(
                'id' => 'rankmath_catalog',
                'name' => 'Rank Math Catalog',
                'description' => 'SEO tools for Rank Math head output and post SEO metadata updates.',
                'plugin_files' => array( 'seo-by-rank-math/rank-math.php', 'seo-by-rank-math-pro/rank-math-pro.php' ),
                'match_classes' => array( 'RankMath', 'RankMath\\Runner' ),
                'match_constants' => array( 'RANK_MATH_VERSION' ),
                'install_slug' => 'seo-by-rank-math',
                'match' => array(
                    'tools' => array( 'wp_rm_get_head', 'wp_rm_get_post_seo', 'wp_rm_update_post_seo' ),
                ),
                'catalog_tools' => array( 'wp_rm_get_head', 'wp_rm_get_post_seo', 'wp_rm_update_post_seo' ),
            ),
            array(
                'id' => 'wpforms_catalog',
                'name' => 'WPForms Catalog',
                'description' => 'Form tools for listing WPForms forms and reading entries.',
                'plugin_files' => array( 'wpforms-lite/wpforms.php' ),
                'install_slug' => 'wpforms-lite',
                'match' => array(
                    'tools' => array( 'wpforms_list_forms', 'wpforms_get_form', 'wpforms_get_entries', 'wpforms_get_entry' ),
                ),
                'catalog_tools' => array( 'wpforms_list_forms', 'wpforms_get_form', 'wpforms_get_entries', 'wpforms_get_entry' ),
            ),
            array(
                'id' => 'contact_form_7_catalog',
                'name' => 'Contact Form 7 Catalog',
                'description' => 'Form tools for listing Contact Form 7 forms and reading normalized field schemas.',
                'plugin_files' => array( 'contact-form-7/wp-contact-form-7.php' ),
                'match_classes' => array( 'WPCF7_ContactForm' ),
                'install_slug' => 'contact-form-7',
                'match' => array(
                    'tools' => array( 'cf7_list_forms', 'cf7_get_form' ),
                ),
                'catalog_tools' => array( 'cf7_list_forms', 'cf7_get_form' ),
            ),
            array(
                'id' => 'flamingo_catalog',
                'name' => 'Flamingo Catalog',
                'description' => 'Sensitive read access to redacted Contact Form 7 submissions stored by Flamingo.',
                'plugin_files' => array( 'flamingo/flamingo.php' ),
                'install_slug' => 'flamingo',
                'match' => array(
                    'tools' => array( 'flamingo_get_submissions' ),
                ),
                'catalog_tools' => array( 'flamingo_get_submissions' ),
            ),
            array(
                'id' => 'gravityforms_catalog',
                'name' => 'Gravity Forms Catalog',
                'description' => 'Form tools for listing Gravity Forms, reading entries, and updates.',
                'plugin_files' => array( 'gravityforms/gravityforms.php' ),
                'install_slug' => 'gravityforms',
                'match' => array(
                    'tools' => array( 'gf_list_forms', 'gf_get_entries', 'gf_update_entry' ),
                ),
                'catalog_tools' => array( 'gf_list_forms', 'gf_get_entries', 'gf_update_entry' ),
            ),
            array(
                'id' => 'forminator_catalog',
                'name' => 'Forminator Catalog',
                'description' => 'Form tools for listing Forminator forms and reading entries.',
                'plugin_files' => array( 'forminator/forminator.php' ),
                'install_slug' => 'forminator',
                'match' => array(
                    'tools' => array( 'forminator_list_forms', 'forminator_get_entries' ),
                ),
                'catalog_tools' => array( 'forminator_list_forms', 'forminator_get_entries' ),
            ),
            array(
                'id' => 'elementor',
                'name' => 'Elementor',
                'description' => 'Clone and customize Elementor pages safely without generating page-builder JSON from scratch.',
                'plugin_files' => array( 'elementor/elementor.php' ),
                'match_classes' => array( 'Elementor\\Plugin' ),
                'install_slug' => 'elementor',
                'match' => array(
                    'prefixes' => array( 'elementor_' ),
                ),
                'catalog_tools' => array(
                    'elementor_clone_page',
                    'elementor_replace_text',
                    'elementor_replace_image',
                    'elementor_replace_link',
                    'elementor_get_page_outline',
                    'elementor_get_widget_settings',
                    'elementor_update_widget',
                    'elementor_list_local_templates',
                    'elementor_import_template',
                    'elementor_export_template',
                    'elementor_add_widget',
                    'elementor_apply_template_to_page',
                    'elementor_repair_render',
                    'elementor_repair_render_bulk',
                ),
            ),
            array(
                'id' => 'divi',
                'name' => 'Divi',
                'description' => 'Inspect, validate, and safely update Divi Builder layouts and local library templates.',
                'plugin_files' => array( 'divi-builder/divi-builder.php' ),
                'match_classes' => array( 'ET_Builder_Plugin' ),
                'match_constants' => array( 'ET_BUILDER_VERSION' ),
                'install_slug' => 'divi-builder',
                'match' => array(
                    'tools' => array(
                        'divi_get_page_format',
                        'divi_get_page_outline',
                        'divi_list_local_templates',
                        'divi_library_get',
                        'divi_replace_text',
                        'divi_clone_page',
                        'divi_replace_image',
                        'divi_apply_library_template',
                    ),
                ),
                'catalog_tools' => array(
                    'divi_get_page_format',
                    'divi_get_page_outline',
                    'divi_validate_layout',
                    'divi_list_local_templates',
                    'divi_library_get',
                    'divi_replace_text',
                    'divi_clone_page',
                    'divi_replace_image',
                    'divi_apply_library_template',
                ),
            ),
            array(
                'id' => 'the_events_calendar',
                'name' => 'The Events Calendar',
                'description' => 'Manage events, venues, and organizers through the native The Events Calendar REST API.',
                'plugin_files' => array( 'the-events-calendar/the-events-calendar.php' ),
                'match_classes' => array( 'Tribe__Events__Main' ),
                'install_slug' => 'the-events-calendar',
                'match' => array(
                    'tools' => array(
                        'wp_tec_list_events',
                        'wp_tec_get_event',
                        'wp_tec_save_event',
                        'wp_tec_list_entities',
                        'wp_tec_save_entity',
                        'wp_tec_trash_event',
                    ),
                ),
                'catalog_tools' => array(
                    'wp_tec_list_events',
                    'wp_tec_get_event',
                    'wp_tec_save_event',
                    'wp_tec_list_entities',
                    'wp_tec_save_entity',
                    'wp_tec_trash_event',
                ),
            ),
        );
    }

    public static function get_integration_ids() {
        $ids = array();
        foreach ( self::get_integrations() as $integration ) {
            $ids[] = $integration['id'];
        }
        return $ids;
    }

    public static function get_integrations_for_tool( $tool_name ) {
        $matches = array();
        foreach ( self::get_integrations() as $integration ) {
            if ( self::tool_matches_integration( $tool_name, $integration ) ) {
                $matches[] = $integration['id'];
            }
        }
        return $matches;
    }

    public static function tool_matches_integration( $tool_name, $integration ) {
        $match = isset( $integration['match'] ) && is_array( $integration['match'] ) ? $integration['match'] : array();
        $tools = isset( $match['tools'] ) && is_array( $match['tools'] ) ? $match['tools'] : array();
        $prefixes = isset( $match['prefixes'] ) && is_array( $match['prefixes'] ) ? $match['prefixes'] : array();

        if ( in_array( $tool_name, $tools, true ) ) {
            return true;
        }

        foreach ( $prefixes as $prefix ) {
            if ( '' !== $prefix && strpos( $tool_name, $prefix ) === 0 ) {
                return true;
            }
        }

        return false;
    }
}
