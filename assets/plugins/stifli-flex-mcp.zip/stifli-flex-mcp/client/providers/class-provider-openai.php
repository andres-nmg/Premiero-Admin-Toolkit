<?php
/**
 * OpenAI Provider Handler (Responses API)
 *
 * @package StifliFlexMcp
 * @since 1.0.5
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-provider-base.php';

/**
 * OpenAI provider handler using the Responses API
 */
class StifliFlexMcp_Client_OpenAI extends StifliFlexMcp_Client_Provider_Base {

	/**
	 * API endpoint
	 */
	const API_URL = 'https://api.openai.com/v1/responses';

	/**
	 * Models that don't support sampling parameters (temperature, top_p, penalties)
	 * These are "reasoning" models that use adaptive reasoning instead.
	 */
	const REASONING_MODELS = array(
		'gpt-5.4-pro',
		'gpt-5.4',
		'gpt-5.4-mini',
		'gpt-5.4-nano',
		'gpt-5.3',
		'gpt-5.3-mini',
		'gpt-5.2',
		'gpt-5.2-chat-latest',
		'gpt-5',
		'gpt-5-mini',
		'gpt-5-nano',
		'o1',
		'o1-mini',
		'o1-preview',
		'o3',
		'o3-mini',
	);

	/**
	 * Check if model is a reasoning model (no sampling params)
	 *
	 * @param string $model Model name.
	 * @return bool
	 */
	private function is_reasoning_model( $model ) {
		foreach ( self::REASONING_MODELS as $reasoning_model ) {
			if ( strpos( $model, $reasoning_model ) === 0 ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Send a message to OpenAI
	 *
	 * @param array $args Message arguments.
	 * @return array|WP_Error Response data or error.
	 */
	public function send_message( $args ) {
		$api_key       = $args['api_key'];
		$model         = $args['model'] ?: 'gpt-5.4';
		$message       = $args['message'];
		$conversation  = $args['conversation'] ?? array();
		$tools         = $args['tools'] ?? array();
		$tool_result   = $args['tool_result'] ?? null;
		$system_prompt = $args['system_prompt'] ?? '';
		$temperature   = $args['temperature'] ?? 0.7;
		$max_tokens    = $args['max_tokens'] ?? 4096;
		$top_p         = $args['top_p'] ?? 1.0;
		$frequency_penalty = $args['frequency_penalty'] ?? 0;
		$presence_penalty  = $args['presence_penalty'] ?? 0;

		// Build input array
		$input = array();

		// Add conversation history
		foreach ( $conversation as $msg ) {
			$input[] = $msg;
		}

		// If we have a tool result, add it
		if ( $tool_result ) {
			// Support both single result and array of results.
			if ( isset( $tool_result['call_id'] ) ) {
				$input[] = array(
					'type'    => 'function_call_output',
					'call_id' => $tool_result['call_id'],
					'output'  => wp_json_encode( $tool_result['output'] ),
				);
			} elseif ( is_array( $tool_result ) ) {
				foreach ( $tool_result as $tr ) {
					if ( isset( $tr['call_id'] ) ) {
						$input[] = array(
							'type'    => 'function_call_output',
							'call_id' => $tr['call_id'],
							'output'  => wp_json_encode( $tr['output'] ),
						);
					}
				}
			}
		} elseif ( ! empty( $message ) ) {
			// Add new user message
			$input[] = array(
				'role'    => 'user',
				'content' => $message,
			);
		}

		// Build request body - base parameters
		$body = array(
			'model'             => $model,
			'input'             => $input,
			'instructions'      => $this->get_system_prompt( $system_prompt ),
			'max_output_tokens' => intval( $max_tokens ),
		);

		// Add sampling parameters only for non-reasoning models
		// GPT-5 family and o1/o3 models use adaptive reasoning and don't support these
		if ( ! $this->is_reasoning_model( $model ) ) {
			$body['temperature']       = floatval( $temperature );
			$body['top_p']             = floatval( $top_p );
			$body['frequency_penalty'] = floatval( $frequency_penalty );
			$body['presence_penalty']  = floatval( $presence_penalty );
		}

		// Add tools if available
		if ( ! empty( $tools ) ) {
			$body['tools'] = $this->format_tools( $tools );
		}

		stifli_flex_mcp_log( sprintf(
			'[OpenAI] Request summary model=%s input_items=%d tools=%d max_tokens=%d',
			$model,
			count( $input ),
			count( $tools ),
			intval( $max_tokens )
		) );

		// Make request
		$meta = $this->make_request_with_meta(
			self::API_URL,
			array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $api_key,
			),
			$body
		);

		if ( is_wp_error( $meta ) ) {
			// Log rate limit headers on errors (429s).
			$data = $meta->get_error_data();
			if ( is_array( $data ) && ! empty( $data['headers'] ) && is_array( $data['headers'] ) ) {
				$h = $data['headers'];
				$keys = array(
					'retry-after',
					'x-ratelimit-remaining-tokens',
					'x-ratelimit-remaining-requests',
					'x-ratelimit-limit-tokens',
					'x-ratelimit-limit-requests',
				);
				$parts = array();
				foreach ( $keys as $k ) {
					if ( isset( $h[ $k ] ) ) {
						$parts[] = $k . '=' . $h[ $k ];
					}
				}
				if ( ! empty( $parts ) ) {
					stifli_flex_mcp_log( '[OpenAI] Error rate-limit headers: ' . implode( ' ', $parts ) );
				}
			}
			return $meta;
		}

		$response = $meta['body'] ?? array();
		$headers  = $meta['headers'] ?? array();

		// Log provider-reported usage if present.
		if ( isset( $response['usage'] ) && is_array( $response['usage'] ) ) {
			$u = $response['usage'];
			$prompt   = isset( $u['input_tokens'] ) ? $u['input_tokens'] : ( isset( $u['prompt_tokens'] ) ? $u['prompt_tokens'] : 'n/a' );
			$output   = isset( $u['output_tokens'] ) ? $u['output_tokens'] : ( isset( $u['completion_tokens'] ) ? $u['completion_tokens'] : 'n/a' );
			$total    = isset( $u['total_tokens'] ) ? $u['total_tokens'] : 'n/a';
			// Cached tokens: Responses API uses input_tokens_details, Chat API uses prompt_tokens_details
			$cached   = 'n/a';
			if ( isset( $u['input_tokens_details']['cached_tokens'] ) ) {
				$cached = $u['input_tokens_details']['cached_tokens'];
			} elseif ( isset( $u['prompt_tokens_details']['cached_tokens'] ) ) {
				$cached = $u['prompt_tokens_details']['cached_tokens'];
			}
			stifli_flex_mcp_log( sprintf(
				'[OpenAI] Usage input=%s output=%s total=%s cached=%s',
				$prompt, $output, $total, $cached
			) );
		}

		// Log key rate limit headers if present.
		if ( is_array( $headers ) && ! empty( $headers ) ) {
			$keys = array(
				'x-ratelimit-remaining-tokens',
				'x-ratelimit-remaining-requests',
				'x-ratelimit-limit-tokens',
				'x-ratelimit-limit-requests',
				'x-ratelimit-reset-tokens',
				'x-ratelimit-reset-requests',
			);
			$parts = array();
			foreach ( $keys as $k ) {
				if ( isset( $headers[ $k ] ) ) {
					$parts[] = $k . '=' . $headers[ $k ];
				}
			}
			if ( ! empty( $parts ) ) {
				stifli_flex_mcp_log( '[OpenAI] Rate headers: ' . implode( ' ', $parts ) );
			}
		}

		$parsed = $this->parse_response( $response, $input );

		// Include usage data for token tracking
		if ( isset( $response['usage'] ) && is_array( $response['usage'] ) ) {
			$u = $response['usage'];
			$input_tokens  = isset( $u['input_tokens'] ) ? (int) $u['input_tokens'] : ( isset( $u['prompt_tokens'] ) ? (int) $u['prompt_tokens'] : 0 );
			$output_tokens = isset( $u['output_tokens'] ) ? (int) $u['output_tokens'] : ( isset( $u['completion_tokens'] ) ? (int) $u['completion_tokens'] : 0 );
			$cached_tokens = 0;
			if ( isset( $u['input_tokens_details']['cached_tokens'] ) ) {
				$cached_tokens = (int) $u['input_tokens_details']['cached_tokens'];
			} elseif ( isset( $u['prompt_tokens_details']['cached_tokens'] ) ) {
				$cached_tokens = (int) $u['prompt_tokens_details']['cached_tokens'];
			}

			$parsed['usage'] = array(
				'input_tokens'          => $input_tokens,
				'output_tokens'         => $output_tokens,
				'cached_tokens'         => $cached_tokens,
				'billable_input_tokens' => max( 0, $input_tokens - $cached_tokens ),
			);
		} else {
			$est_output = ! empty( $parsed['text'] ) ? (int) ceil( strlen( $parsed['text'] ) / 4 ) : 0;
			$parsed['usage'] = array(
				'input_tokens'          => 0,
				'output_tokens'         => $est_output,
				'cached_tokens'         => 0,
				'billable_input_tokens' => 0,
			);
			stifli_flex_mcp_log( '[OpenAI] Usage not reported by API, estimated output=' . $est_output );		}

		return $parsed;
	}

	/**
	 * Format MCP tools for OpenAI
	 *
	 * @param array $mcp_tools MCP tool definitions.
	 * @return array OpenAI function tools.
	 */
	protected function format_tools( $mcp_tools ) {
		$formatted = array();

		foreach ( $mcp_tools as $tool ) {
			$params = StifliFlexMcpUtils::normalizeToolInputSchema( $tool['inputSchema'] ?? array() );

			$formatted[] = array(
				'type'        => 'function',
				'name'        => $tool['name'],
				'description' => $tool['description'],
				'parameters'  => $params,
			);
		}

		return $formatted;
	}

	/**
	 * Parse OpenAI response
	 *
	 * @param array $response API response.
	 * @param array $input    Input messages sent.
	 * @return array Parsed response.
	 */
	private function parse_response( $response, $input ) {
		$result = array(
			'text'         => '',
			'tool_calls'   => array(),
			'conversation' => $input,
			'finished'     => true,
		);

		if ( ! isset( $response['output'] ) || ! is_array( $response['output'] ) ) {
			return $result;
		}

		foreach ( $response['output'] as $item ) {
			// Add to conversation history
			$result['conversation'][] = $item;

			if ( $item['type'] === 'message' ) {
				// Extract text from message content
				if ( isset( $item['content'] ) && is_array( $item['content'] ) ) {
					foreach ( $item['content'] as $content ) {
						if ( isset( $content['type'] ) && $content['type'] === 'output_text' ) {
							$result['text'] .= $content['text'];
						}
					}
				}
			} elseif ( $item['type'] === 'function_call' ) {
				$decoded_args = $this->decode_function_arguments( $item['arguments'] ?? array() );
				// Tool call detected
				$result['tool_calls'][] = array(
					'id'        => $item['id'] ?? '',
					'call_id'   => $item['call_id'] ?? '',
					'name'      => $item['name'] ?? '',
					'arguments' => $decoded_args,
				);
				$result['finished'] = false;
			}
		}

		return $result;
	}

	/**
	 * Decode OpenAI function-call arguments safely.
	 *
	 * Responses API normally returns a JSON string in `arguments`, but some
	 * model outputs can include wrappers or malformed JSON. This helper keeps
	 * execution resilient and logs parse failures for debugging.
	 *
	 * @param mixed $arguments Raw arguments payload.
	 * @return array
	 */
	private function decode_function_arguments( $arguments ) {
		if ( is_array( $arguments ) ) {
			return $arguments;
		}

		if ( $arguments instanceof stdClass ) {
			return (array) $arguments;
		}

		if ( ! is_string( $arguments ) ) {
			return array();
		}

		$raw = trim( $arguments );
		if ( '' === $raw ) {
			return array();
		}

		$decoded = json_decode( $raw, true );
		if ( json_last_error() === JSON_ERROR_NONE && is_array( $decoded ) ) {
			return $decoded;
		}

		// Retry if the model wrapped JSON in markdown code fences.
		$without_fences = preg_replace( '/^```(?:json)?\s*|\s*```$/i', '', $raw );
		if ( is_string( $without_fences ) ) {
			$without_fences = trim( $without_fences );
			$decoded_retry = json_decode( $without_fences, true );
			if ( json_last_error() === JSON_ERROR_NONE && is_array( $decoded_retry ) ) {
				return $decoded_retry;
			}
		}

		stifli_flex_mcp_log( '[OpenAI] Failed to decode function arguments: ' . json_last_error_msg() . ' raw=' . substr( $raw, 0, 500 ) );
		return array();
	}

	/**
	 * Execute a tool and get the result
	 *
	 * @param string $tool_name Tool name.
	 * @param array  $arguments Tool arguments.
	 * @return array Tool result.
	 */
	public function execute_tool_call( $tool_name, $arguments ) {
		return $this->execute_tool( $tool_name, $arguments );
	}
}
