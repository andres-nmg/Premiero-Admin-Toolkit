<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class StifliFlexMcp {
	private $logging = false;
	private $addedFilter = false;
	private $namespace = 'stifli-flex-mcp/v1';
	private $sessionID = null;
	private $lastAction = 0;
	private $protocolVersion = '2025-11-25';
	private $serverVersion = '0.0.1';
	private $queueTable = '';
	private $queueTtl = 300; // seconds
	private $taskDefaultTtlMs = 300000; // 5 minutes
	private $taskMaxTtlMs = 1800000; // 30 minutes
	private $taskPollIntervalMs = 3000;
	private $oauthWellKnownProbeTtl = 43200; // 12 hours
	private $activeConnectionContext = array();

	public function __construct() {
		global $wpdb;
		if ( defined( 'SFLMCP_VERSION' ) ) {
			$this->serverVersion = SFLMCP_VERSION;
		}
		if (isset($wpdb->prefix)) {
			$this->queueTable = StifliFlexMcpUtils::getPrefixedTable('sflmcp_queue', false);
		}
	}

	public function init() {
		add_action('rest_api_init', array($this, 'restApiInit'));
		add_filter('rest_post_dispatch', array($this, 'addNoCacheHeadersForNamespace'), 9, 3);
		add_filter( 'rest_allowed_cors_headers', static function( $headers ) { return array_unique( array_merge( $headers, array( 'MCP-Protocol-Version', 'Mcp-Method', 'Mcp-Name' ) ) ); } );
		add_filter( 'rest_exposed_cors_headers', static function( $headers ) { return array_unique( array_merge( $headers, array( 'MCP-Protocol-Version', 'Retry-After' ) ) ); } );
		add_action('sflmcp_process_task', array($this, 'processTaskAsync'), 10, 1);
		$this->ensureDispatcherCallbackRegistered();
		// Register admin menu and settings when in WP admin
		if (is_admin()) {
			add_action('admin_menu', array($this, 'registerAdmin'));
			add_action('admin_menu', array($this, 'registerMcpServerSubmenu'), 15);
			add_action('admin_menu', array($this, 'registerMultimediaSubmenu'), 25);
			if ( stifli_flex_mcp_addon_enabled( 'seo' ) ) {
				add_action('admin_menu', array($this, 'registerSeoSubmenu'), 26);
			}
			add_action('admin_init', array($this, 'registerSettings'));
			add_action('admin_init', array($this, 'handleOAuthWellKnownNoticeDismiss'));
			add_action('admin_init', array($this, 'handleOAuthWellKnownRecheck'));
			add_action('admin_init', array($this, 'handleWpMcpHubPromoNoticeDismiss'));
			add_action('admin_notices', array($this, 'renderOAuthWellKnownNotice'));
			add_action('admin_notices', array($this, 'renderWpMcpHubPromoNotice'), 20);
			add_action('admin_footer', array($this, 'renderWpMcpHubPromoFooter'));
			add_action('admin_enqueue_scripts', array($this, 'enqueueAdminScripts'));
			// AJAX handlers for profiles management
			add_action('wp_ajax_sflmcp_create_profile', array($this, 'ajax_create_profile'));
			add_action('wp_ajax_sflmcp_update_profile', array($this, 'ajax_update_profile'));
			add_action('wp_ajax_sflmcp_delete_profile', array($this, 'ajax_delete_profile'));
			add_action('wp_ajax_sflmcp_duplicate_profile', array($this, 'ajax_duplicate_profile'));
			add_action('wp_ajax_sflmcp_apply_profile', array($this, 'ajax_apply_profile'));
			add_action('wp_ajax_sflmcp_export_profile', array($this, 'ajax_export_profile'));
			add_action('wp_ajax_sflmcp_import_profile', array($this, 'ajax_import_profile'));
			add_action('wp_ajax_sflmcp_restore_system_profiles', array($this, 'ajax_restore_system_profiles'));
			// AJAX handlers for WordPress/WooCommerce tools
			add_action('wp_ajax_sflmcp_toggle_tool', array($this, 'ajax_toggle_tool'));
			add_action('wp_ajax_sflmcp_bulk_toggle_tools', array($this, 'ajax_bulk_toggle_tools'));
			add_action('wp_ajax_sflmcp_toggle_tool_by_checkbox', array($this, 'ajax_toggle_tool_by_checkbox'));
			add_action('wp_ajax_sflmcp_bulk_toggle_tools_by_id', array($this, 'ajax_bulk_toggle_tools_by_id'));
			// AJAX handlers for WordPress Abilities API (WordPress 6.9+)
			add_action('wp_ajax_sflmcp_discover_abilities', array($this, 'ajax_discover_abilities'));
			add_action('wp_ajax_sflmcp_import_ability', array($this, 'ajax_import_ability'));
			add_action('wp_ajax_sflmcp_toggle_ability', array($this, 'ajax_toggle_ability'));
			add_action('wp_ajax_sflmcp_delete_ability', array($this, 'ajax_delete_ability'));
			add_action('wp_ajax_sflmcp_get_imported_abilities', array($this, 'ajax_get_imported_abilities'));
			add_action('wp_ajax_sflmcp_bulk_manage_abilities', array($this, 'ajax_bulk_manage_abilities'));
			// AJAX handlers for Multimedia settings
			add_action('wp_ajax_sflmcp_save_multimedia_settings', array($this, 'ajax_save_multimedia_settings'));
			add_action('wp_ajax_sflmcp_load_multimedia_settings', array($this, 'ajax_load_multimedia_settings'));
			add_action('wp_ajax_sflmcp_mm_toggle_tool', array($this, 'ajax_mm_toggle_tool'));
			add_action('wp_ajax_sflmcp_mm_reveal_key', array($this, 'ajax_mm_reveal_key'));
			// AJAX handlers for OAuth Clients
			add_action('wp_ajax_sflmcp_oauth_delete_client', array($this, 'ajax_oauth_delete_client'));
			add_action('wp_ajax_sflmcp_oauth_revoke_token', array($this, 'ajax_oauth_revoke_token'));
			add_action('wp_ajax_sflmcp_oauth_reset_state', array($this, 'ajax_oauth_reset_state'));
			add_action('wp_ajax_sflmcp_oauth_save_settings', array($this, 'ajax_oauth_save_settings'));
			add_action('wp_ajax_sflmcp_oauth_approve_client', array($this, 'ajax_oauth_approve_client'));
			add_action('wp_ajax_sflmcp_oauth_check_header', array($this, 'ajax_oauth_check_header'));
			add_action('wp_ajax_sflmcp_generate_app_password', array($this, 'ajax_generate_app_password'));
			add_action('admin_post_sflmcp_download_mcpb_bundle', array($this, 'handleDownloadMcpbBundle'));
		}
	}

	private function ensureDispatcherCallbackRegistered(): void {
		if ($this->addedFilter) {
			return;
		}
		StifliFlexMcpDispatcher::addFilter('sflmcp_callback', array($this, 'handleCallback'), 10, 4);
		$this->addedFilter = true;
	}

	public function restApiInit() {
		register_rest_route($this->namespace, '/sse', array(
			'methods' => 'GET',
			'callback' => array($this, 'handleSSE'),
			'permission_callback' => function( $request ) {
				return $this->canAccessMCP($request);
			},
		));
		register_rest_route($this->namespace, '/sse', array(
			'methods' => 'POST',
			'callback' => array($this, 'handleSSE'),
			'permission_callback' => function( $request ) {
				return $this->canAccessMCP($request);
			},
		));
		register_rest_route($this->namespace, '/messages', array(
			'methods' => 'POST',
			'callback' => array($this, 'handleMessage'),
			'permission_callback' => function( $request ) {
				return $this->canAccessMCP($request);
			},
		));
		register_rest_route($this->namespace, '/messages', array(
			'methods' => 'GET',
			'callback' => array($this, 'handleMessagesGet'),
			'permission_callback' => function( $request ) {
				return $this->canAccessMCP($request);
			},
		));
		$this->ensureDispatcherCallbackRegistered();
	}

	/**
	 * Check if the request can access the MCP endpoint.
	 * WordPress 5.6+ handles Application Password authentication natively.
	 * This method only checks that the user has sufficient capabilities.
	 * 
	 * @see https://developer.wordpress.org/rest-api/using-the-rest-api/authentication/
	 * @see https://make.wordpress.org/core/2020/11/05/application-passwords-integration-guide/
	 */
	public function canAccessMCP( $request ) {
		// --- Verbose debug logging ---
		$req_method = $request->get_method();
		$req_route  = $request->get_route();
		$auth_hdr   = $this->getAuthorizationHeader( $request );
		stifli_flex_mcp_log( sprintf(
			'canAccessMCP: %s %s | Auth: %s | User-Agent: %s',
			$req_method,
			$req_route,
			$auth_hdr ? '(present)' : '(none)',
			$request->get_header( 'User-Agent' ) ?: '(none)'
		) );
		$this->traceMcpRequest('canAccessMCP/entry', array(
			'method' => $req_method,
			'route' => $req_route,
			'auth_header' => $auth_hdr ? 'present' : 'none',
			'query_token' => $request->get_param('token') ? 'present' : 'none',
			'user_agent' => $request->get_header('User-Agent') ?: 'n/a',
		));

		// Streamable HTTP security: reject invalid Origin headers.
		$origin = trim( (string) $request->get_header( 'Origin' ) );
		if ( '' !== $origin ) {
			$origin_host = wp_parse_url( $origin, PHP_URL_HOST );
			$site_host = wp_parse_url( home_url(), PHP_URL_HOST );
			$allowed_hosts = array_filter( apply_filters( 'sflmcp_allowed_origin_hosts', array( $site_host ) ) );
			$allowed_hosts = array_map( static function( $host ) {
				return strtolower( (string) $host );
			}, $allowed_hosts );
			$origin_host = strtolower( (string) $origin_host );

			if ( '' === $origin_host || ! in_array( $origin_host, $allowed_hosts, true ) ) {
				stifli_flex_mcp_log( sprintf( 'canAccessMCP: Invalid Origin header rejected (%s)', $origin ) );
				return new WP_Error( 'invalid_origin', 'Invalid Origin header.', array( 'status' => 403 ) );
			}
		}

		// --- OAuth 2.1 Bearer token validation ---
		$auth_header = $auth_hdr;
		if ( $auth_header && stripos( $auth_header, 'Bearer ' ) === 0 ) {
			$bearer_token = substr( $auth_header, 7 );
			if ( class_exists( 'StifliFlexMcp_OAuth_Server' ) ) {
				$oauth_user_id = StifliFlexMcp_OAuth_Server::get_instance()->validate_token( $bearer_token );
				if ( $oauth_user_id ) {
					wp_set_current_user( $oauth_user_id );
					stifli_flex_mcp_log( sprintf( 'canAccessMCP: OAuth token validated for user %d', $oauth_user_id ) );

					// Resolve OAuth client name for source tracking
					if ( class_exists( 'StifliFlexMcp_ChangeTracker' ) ) {
						$client_label = $this->resolveOAuthClientLabel( $bearer_token );
						StifliFlexMcp_ChangeTracker::setSourceContext( 'mcp', $client_label );
					}

					return StifliFlexMcpUtils::checkRateLimit( 'user:' . $oauth_user_id, apply_filters( 'sflmcp_authenticated_rate_limit', 180 ) );
				}
			}
			// Bearer token present but invalid → 401.
			$rate = StifliFlexMcpUtils::checkRateLimit( 'anonymous:' . StifliFlexMcpUtils::getClientIp(), 30 );
			if ( is_wp_error( $rate ) ) {
				return $rate;
			}
			stifli_flex_mcp_log( 'canAccessMCP: Invalid OAuth Bearer token' );
			return new WP_Error( 'invalid_token', 'Invalid or expired Bearer token.', array( 'status' => 401 ) );
		}

		$current_user_id = get_current_user_id();
		
		if ($current_user_id > 0 && current_user_can('edit_posts')) {
			stifli_flex_mcp_log(sprintf('canAccessMCP: user %d has sufficient capabilities', $current_user_id));
			return StifliFlexMcpUtils::checkRateLimit( 'user:' . $current_user_id, apply_filters( 'sflmcp_authenticated_rate_limit', 180 ) );
		}
		$rate = StifliFlexMcpUtils::checkRateLimit( 'anonymous:' . StifliFlexMcpUtils::getClientIp(), 30 );
		if ( is_wp_error( $rate ) ) {
			return $rate;
		}
		
		stifli_flex_mcp_log('canAccessMCP: Access denied - no authenticated user with edit_posts capability');
		if ( class_exists( 'StifliFlexMcp_OAuth_Server' ) ) {
			return StifliFlexMcp_OAuth_Server::get_instance()->get_unauthorized_error();
		}
		return false;
	}

	private function getAuthorizationHeader( $request ) {
		$auth_header = $request ? $request->get_header( 'Authorization' ) : '';
		if ( ! $auth_header && $request ) {
			$auth_header = $request->get_header( 'authorization' );
		}

		if ( ! $auth_header ) {
			foreach ( array( 'HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION' ) as $server_key ) {
				if ( ! empty( $_SERVER[ $server_key ] ) ) {
					$auth_header = wp_unslash( $_SERVER[ $server_key ] );
					break;
				}
			}
		}

		if ( ! $auth_header && function_exists( 'getallheaders' ) ) {
			$headers = getallheaders();
			if ( is_array( $headers ) ) {
				foreach ( $headers as $name => $value ) {
					if ( 'authorization' === strtolower( (string) $name ) ) {
						$auth_header = $value;
						break;
					}
				}
			}
		}

		return is_string( $auth_header ) ? trim( sanitize_text_field( $auth_header ) ) : '';
	}

		private function inferAuthMethodFromRequest( $request ) {
			$auth_header = $this->getAuthorizationHeader( $request );
			if ( is_string( $auth_header ) && '' !== $auth_header ) {
				if ( 0 === stripos( $auth_header, 'Bearer ' ) ) {
					return 'bearer';
				}
				if ( 0 === stripos( $auth_header, 'Basic ' ) ) {
					return 'basic';
				}
				return 'authorization_header';
			}

			if ( $request && $request->get_param( 'token' ) ) {
				return 'query_token';
			}

			if ( get_current_user_id() > 0 ) {
				return 'cookie_session';
			}

			return 'unknown';
		}

		private function primeActiveConnectionContext( $request, $transport, $session_id = '' ) {
			$route = $request && method_exists( $request, 'get_route' ) ? (string) $request->get_route() : '';
			$this->activeConnectionContext = array(
				'transport' => is_string( $transport ) ? $transport : 'unknown',
				'route' => $route,
				'auth_method' => $this->inferAuthMethodFromRequest( $request ),
				'session_id' => is_string( $session_id ) ? $this->normalizeSessionId( $session_id ) : '',
				'user_id' => (int) get_current_user_id(),
				'is_authenticated' => get_current_user_id() > 0,
				'request_time_gmt' => gmdate( 'c' ),
			);
		}

		private function buildToolConnectionContext( $tool, $id, $arguments, $is_task_augmented = false ) {
			$context = is_array( $this->activeConnectionContext ) ? $this->activeConnectionContext : array();
			$context['tool'] = is_scalar( $tool ) ? (string) $tool : '';
			$context['request_id'] = $id;
			$context['task_augmented'] = (bool) $is_task_augmented;
			$context['arguments_keys'] = is_array( $arguments ) ? array_values( array_map( 'strval', array_keys( $arguments ) ) ) : array();
			return $context;
		}

	/**
	 * Resolve OAuth client_name from a bearer token for source tracking.
	 *
	 * @param string $bearer_token Raw bearer token.
	 * @return string Client name or empty string.
	 */
	private function resolveOAuthClientLabel( $bearer_token ) {
		if ( ! class_exists( 'StifliFlexMcp_OAuth_Storage' ) ) {
			return '';
		}
		$storage = StifliFlexMcp_OAuth_Storage::get_instance();
		$record  = $storage->validate_access_token( $bearer_token );
		if ( $record && ! empty( $record->client_id ) ) {
			$client = $storage->get_client( $record->client_id );
			if ( $client && ! empty( $client->client_name ) ) {
				return $client->client_name;
			}
		}
		return '';
	}

	public function handleCallback( $result, string $tool, array $args, $id ) {
		if (!empty($result)) {
			$this->traceMcpRequest('callback/short-circuit', array(
				'id' => $id,
				'tool' => $tool,
			));
			return $result;
		}
		$tools = $this->getModel()->getTools();
		if (!isset($tools[$tool])) {
			$this->traceMcpRequest('callback/tool-not-found', array(
				'id' => $id,
				'tool' => $tool,
			));
			StifliFlexMcpFrame::_()->saveDebugLogging('Tool not found ' . $tool, false, 'SFLMCP');
			return $result;
		}
		$this->traceMcpRequest('callback/before-dispatch', array(
			'id' => $id,
			'tool' => $tool,
			'args' => $args,
		));
		if ('wp_create_post' === $tool) {
			$this->traceWpCreatePost('callback/before-dispatch', array(
				'id' => $id,
				'tool' => $tool,
				'args' => $args,
			));
		}
		$dispatch_result = $this->getModel()->dispatchTool($tool, $args, $id);
		$this->traceMcpRequest('callback/after-dispatch', array(
			'id' => $id,
			'tool' => $tool,
			'has_result' => is_array($dispatch_result) && isset($dispatch_result['result']),
			'has_error' => is_array($dispatch_result) && isset($dispatch_result['error']),
		));
		if ('wp_create_post' === $tool) {
			$this->traceWpCreatePost('callback/after-dispatch', array(
				'id' => $id,
				'has_result' => is_array($dispatch_result) && isset($dispatch_result['result']),
				'has_error' => is_array($dispatch_result) && isset($dispatch_result['error']),
				'dispatch_result' => $dispatch_result,
			));
		}
		return $dispatch_result;
	}

	private function getSSEid($req) {
		$last = $req ? $req->get_header('last-event-id') : '';
		return empty($last) ? str_replace('-', '', wp_generate_uuid4()) : $last;
	}

	private function getSupportedProtocolVersions(): array {
		return array('2026-07-28', '2025-11-25', '2025-06-18', '2025-03-26');
	}

	private function isSupportedProtocolVersion( $version ): bool {
		if (!is_string($version) || '' === $version) {
			return false;
		}
		return in_array($version, $this->getSupportedProtocolVersions(), true);
	}

	private function negotiateProtocolVersion( $requestedVersion ): string {
		if ('2026-07-28' !== $requestedVersion && $this->isSupportedProtocolVersion($requestedVersion)) {
			return $requestedVersion;
		}
		return $this->protocolVersion;
	}

	private function getServerInfo( string $protocolVersion ) {
		$serverInfo = array(
			'name' => get_bloginfo('name') . ' Flex MCP',
			'version' => $this->serverVersion,
		);

		if ( in_array( $protocolVersion, array( '2025-11-25', '2026-07-28' ), true ) ) {
			$site_url = home_url( '/' );
			$site = wp_parse_url( $site_url );
			$site_label = StifliFlexMcpUtils::getArrayValue( $site, 'host', '' );
			if ( isset( $site['port'] ) ) {
				$site_label .= ':' . $site['port'];
			}
			$site_label .= rtrim( StifliFlexMcpUtils::getArrayValue( $site, 'path', '' ), '/' );
			$serverInfo['title'] = $serverInfo['name'] . ' (' . $site_label . ')';
			$serverInfo['websiteUrl'] = $site_url;
			$serverInfo['description'] = 'WordPress site: ' . $site_url;
		}

		if ( in_array( $protocolVersion, array( '2025-11-25', '2026-07-28' ), true ) && function_exists( 'get_site_icon_url' ) ) {
			$iconUrl = get_site_icon_url( 512 );
			if ( $iconUrl ) {
				$icon = array(
					'src' => esc_url_raw( $iconUrl ),
					'sizes' => array( '512x512' ),
				);
				$iconId = function_exists( 'get_option' ) ? absint( get_option( 'site_icon', 0 ) ) : 0;
				$mimeType = $iconId ? get_post_mime_type( $iconId ) : '';
				if ( is_string( $mimeType ) && '' !== $mimeType ) {
					$icon['mimeType'] = $mimeType;
				}
				$serverInfo['icons'] = array( $icon );
			}
		}

		return (object) $serverInfo;
	}

	private function getProtocolVersionHeader( $request ) {
		$version = trim((string) $request->get_header('MCP-Protocol-Version'));
		return '' === $version ? null : $version;
	}

	private function protocolVersionErrorResponse( $id, string $requestedVersion ) {
		$response = new WP_REST_Response(array(
			'jsonrpc' => '2.0',
			'id' => $id,
			'error' => array(
				'code' => -32602,
				'message' => 'Unsupported protocol version',
				'data' => array(
					'supported' => $this->getSupportedProtocolVersions(),
					'requested' => $requestedVersion,
				),
			),
		), 400);
		$response->set_headers(array('Content-Type' => 'application/json'));
		return $this->withNoCacheHeaders($response);
	}

	private function getNoCacheHeaders(): array {
		return array(
			'Cache-Control' => 'no-store, no-cache, must-revalidate, private',
			'Pragma' => 'no-cache',
			'Expires' => '0',
		);
	}

	private function withNoCacheHeaders( WP_REST_Response $response ): WP_REST_Response {
		foreach ($this->getNoCacheHeaders() as $name => $value) {
			$response->header($name, $value);
		}
		if ( method_exists( $response, 'get_status' ) && 429 === $response->get_status() ) {
			$body = $response->get_data();
			$response->header( 'Retry-After', (string) max( 1, (int) StifliFlexMcpUtils::getArrayValue( StifliFlexMcpUtils::getArrayValue( $body, 'data', array() ), 'retry_after', 60 ) ) );
		}
		return $response;
	}

	public function addNoCacheHeadersForNamespace( $response, $server, $request ) {
		if (!is_object($response) || !method_exists($response, 'header')) {
			return $response;
		}

		$route = (is_object($request) && method_exists($request, 'get_route'))
			? (string) $request->get_route()
			: '';
		if ('' === $route) {
			return $response;
		}

		$prefix = '/' . $this->namespace;
		if (0 !== strpos($route, $prefix)) {
			return $response;
		}
		if ( $response instanceof WP_REST_Response && in_array( $route, array( $prefix . '/sse', $prefix . '/messages' ), true ) ) {
			StifliFlexMcpUtils::recordProtocolUsage( $request, $response );
		}

		return $response instanceof WP_REST_Response ? $this->withNoCacheHeaders( $response ) : $response;
	}

	private function withProtocolHeaders( WP_REST_Response $response, string $protocolVersion, bool $hasJsonBody = true ): WP_REST_Response {
		$headers = array(
			'MCP-Protocol-Version' => $protocolVersion,
		);
		$headers = array_merge($headers, $this->getNoCacheHeaders());
		if ($hasJsonBody) {
			$headers['Content-Type'] = 'application/json';
		}
		$response->set_headers($headers);
		return $response;
	}

	private function getTaskManagedTools(): array {
		return array('wp_generate_image', 'wp_generate_video');
	}

	private function usesModernProtocol( $request, array $data ): bool {
		$meta = StifliFlexMcpUtils::getArrayValue( StifliFlexMcpUtils::getArrayValue( $data, 'params', array() ), '_meta', array() );
		$version = StifliFlexMcpUtils::getArrayValue( $meta, 'io.modelcontextprotocol/protocolVersion', '' );
		$header = $this->getProtocolVersionHeader( $request );
		$legacy = array( '2025-11-25', '2025-06-18', '2025-03-26' );
		return ( '' !== $version && ! in_array( $version, $legacy, true ) )
			|| ( null !== $header && ! in_array( $header, $legacy, true ) );
	}

	private function decodeMcpHeader( string $value ) {
		if ( preg_match( '/[^\x20-\x7e\t]/', $value ) ) {
			return false;
		}
		if ( 0 === strpos( $value, '=?base64?' ) && substr( $value, -2 ) === '?=' ) {
			return base64_decode( substr( $value, 9, -2 ), true );
		}
		return $value;
	}

	private function modernResponse( $id, string $method, array $reply, int $status = 200 ): WP_REST_Response {
		if ( array_key_exists( 'result', $reply ) ) {
			$result = (array) $reply['result'];
			if ( ! isset( $result['resultType'] ) ) {
				$result['resultType'] = 'complete';
			}
			$result['_meta']['io.modelcontextprotocol/serverInfo'] = $this->getServerInfo( '2026-07-28' );
			if ( in_array( $method, array( 'server/discover', 'tools/list', 'prompts/list', 'resources/list', 'resources/templates/list', 'resources/read' ), true ) && 'complete' === $result['resultType'] ) {
				$result['ttlMs'] = 0;
				$result['cacheScope'] = 'private';
			}
			$reply['result'] = $result;
		}
		if ( isset( $reply['error'] ) && -32601 === $reply['error']['code'] ) {
			$status = 404;
		}
		if ( isset( $reply['error'] ) && in_array( $reply['error']['code'], array( -32020, -32021, -32022 ), true ) ) {
			$status = 400;
		}
		if ( 'resources/read' === $method && isset( $reply['error'] ) && -32004 === $reply['error']['code'] ) {
			$reply['error']['code'] = -32602;
		}
		$body = array_merge( array( 'jsonrpc' => '2.0', 'id' => $id ), $reply );
		if ( null === $id ) {
			unset( $body['id'] );
		}
		return $this->withProtocolHeaders( new WP_REST_Response( $body, $status ), '2026-07-28' );
	}

	private function handleModernJsonRPC( $request, array $data ): WP_REST_Response {
		$id = StifliFlexMcpUtils::getArrayValue( $data, 'id', null );
		$method = StifliFlexMcpUtils::getArrayValue( $data, 'method', '' );
		if ( ! is_string( $method ) || '' === $method || '2.0' !== StifliFlexMcpUtils::getArrayValue( $data, 'jsonrpc', '' ) || ( array_key_exists( 'id', $data ) && ! is_string( $id ) && ! is_int( $id ) ) ) {
			return $this->modernResponse( null, '', array( 'error' => array( 'code' => -32600, 'message' => 'Invalid Request' ) ), 400 );
		}
		$params = StifliFlexMcpUtils::getArrayValue( $data, 'params', array() );
		$meta = StifliFlexMcpUtils::getArrayValue( $params, '_meta', array() );
		$version = StifliFlexMcpUtils::getArrayValue( $meta, 'io.modelcontextprotocol/protocolVersion', '' );
		$header = $this->getProtocolVersionHeader( $request );
		$name = StifliFlexMcpUtils::getArrayValue( $params, 'resources/read' === $method ? 'uri' : 'name', null );
		$requires_name = in_array( $method, array( 'tools/call', 'resources/read', 'prompts/get' ), true );
		if ( null === $header || $header !== $version || $method !== $request->get_header( 'Mcp-Method' )
			|| ( $requires_name && ( ! is_string( $name ) || '' === $name || $name !== $this->decodeMcpHeader( (string) $request->get_header( 'Mcp-Name' ) ) ) ) ) {
			return $this->modernResponse( $id, $method, array( 'error' => array( 'code' => -32020, 'message' => 'Missing, malformed or mismatched MCP request headers.' ) ), 400 );
		}
		if ( '2026-07-28' !== $version ) {
			return $this->modernResponse( $id, $method, array( 'error' => array( 'code' => -32022, 'message' => 'Unsupported protocol version', 'data' => array( 'supported' => $this->getSupportedProtocolVersions(), 'requested' => $version ) ) ), 400 );
		}
		$capabilities = StifliFlexMcpUtils::getArrayValue( $meta, 'io.modelcontextprotocol/clientCapabilities', null );
		$raw = json_decode( $request->get_body() );
		$raw_meta = isset( $raw->params->_meta ) ? $raw->params->_meta : null;
		$raw_capabilities = is_object( $raw_meta ) && isset( $raw_meta->{'io.modelcontextprotocol/clientCapabilities'} ) ? $raw_meta->{'io.modelcontextprotocol/clientCapabilities'} : null;
		if ( ! is_array( $params ) || ! is_array( $meta ) || ! is_array( $capabilities ) || ! is_object( $raw_capabilities ) ) {
			return $this->modernResponse( $id, $method, array( 'error' => array( 'code' => -32602, 'message' => 'params._meta.clientCapabilities must be an object.' ) ), 400 );
		}
		if ( property_exists( $raw_capabilities, 'extensions' ) ) {
			if ( ! is_object( $raw_capabilities->extensions ) ) {
				return $this->modernResponse( $id, $method, $this->rpcError( $id, -32602, 'extensions must be an object.' ), 400 );
			}
			foreach ( $raw_capabilities->extensions as $extension ) {
				if ( ! is_object( $extension ) ) {
					return $this->modernResponse( $id, $method, $this->rpcError( $id, -32602, 'Extension settings must be objects.' ), 400 );
				}
			}
		}
		if ( ! array_key_exists( 'id', $data ) ) {
			return $this->withProtocolHeaders( new WP_REST_Response( null, 202 ), $version, false );
		}
		$this->primeActiveConnectionContext( $request, 'streamable_http' );
		$this->activeConnectionContext['protocol_version'] = $version;
		$client = StifliFlexMcpUtils::getArrayValue( $meta, 'io.modelcontextprotocol/clientInfo', array() );
		if ( class_exists( 'StifliFlexMcp_ChangeTracker' ) ) {
			StifliFlexMcp_ChangeTracker::getInstance()->setSessionId( 'mcp-' . wp_generate_uuid4() );
			$client_name = StifliFlexMcpUtils::getArrayValue( $client, 'name', '' );
			if ( is_string( $client_name ) && '' !== $client_name ) {
				StifliFlexMcp_ChangeTracker::setSourceContext( 'mcp', sanitize_text_field( $client_name ) );
			}
		}
		try {
			switch ( $method ) {
				case 'server/discover':
					$reply = array( 'result' => array(
						'supportedVersions' => $this->getSupportedProtocolVersions(),
						'capabilities' => array( 'tools' => (object) array(), 'resources' => (object) array(), 'prompts' => (object) array(), 'extensions' => array( 'io.modelcontextprotocol/tasks' => (object) array() ) ),
					) );
					break;
				case 'tools/list':
					$tools = $this->getToolsList();
					usort( $tools, static function( $first, $second ) { return strcmp( $first['name'], $second['name'] ); } );
					foreach ( $tools as &$definition ) {
						unset( $definition['execution'] );
					}
					unset( $definition );
					$reply = array( 'result' => array( 'tools' => $tools ) );
					break;
				case 'tools/call':
					if ( array_key_exists( 'arguments', $params ) && ! is_object( $raw->params->arguments ) ) {
						$reply = $this->rpcError( $id, -32602, 'arguments must be an object.' );
						break;
					}
					unset( $params['task'] );
					$extensions = StifliFlexMcpUtils::getArrayValue( $capabilities, 'extensions', array() );
					$task_enabled = is_array( $extensions ) && array_key_exists( 'io.modelcontextprotocol/tasks', $extensions );
					if ( $task_enabled && $this->toolRequiresTask( $name ) ) {
						$params['task'] = array();
					}
					$reply = $this->handleToolsCallMethod( $id, $params );
					if ( $task_enabled && isset( $reply['result']['task'] ) ) {
						$reply['result'] = $this->formatModernTask( $reply['result']['task'], 'task' );
					}
					break;
				case 'tasks/get':
				case 'tasks/update':
				case 'tasks/cancel':
					$extensions = StifliFlexMcpUtils::getArrayValue( $capabilities, 'extensions', array() );
					if ( ! is_array( $extensions ) || ! array_key_exists( 'io.modelcontextprotocol/tasks', $extensions ) ) {
						$reply = $this->rpcError( $id, -32021, 'Client must declare io.modelcontextprotocol/tasks.' );
						$reply['error']['data'] = array( 'requiredCapabilities' => array( 'extensions' => array( 'io.modelcontextprotocol/tasks' => (object) array() ) ) );
						break;
					}
					$reply = $this->handleModernTaskMethod( $method, $params, $id );
					break;
				case 'resources/list':
					$reply = array( 'result' => array( 'resources' => $this->getResourcesList() ) );
					break;
				case 'resources/read':
					$reply = $this->handleResourcesReadMethod( $id, $params );
					break;
				case 'resources/templates/list':
					$reply = array( 'result' => array( 'resourceTemplates' => array() ) );
					break;
				case 'prompts/list':
					$reply = array( 'result' => array( 'prompts' => $this->getPromptsList() ) );
					break;
				default:
					$reply = $this->rpcError( $id, -32601, 'Method not found: ' . $method );
			}
			return $this->modernResponse( $id, $method, $reply );
		} catch ( Throwable $exception ) {
			stifli_flex_mcp_log( 'MCP request failed: ' . $exception->getMessage() );
			return $this->modernResponse( $id, $method, array( 'error' => array( 'code' => -32603, 'message' => 'Internal error' ) ), 500 );
		}
	}

	private function toolRequiresTask( $tool ): bool {
		return is_string($tool) && in_array($tool, $this->getTaskManagedTools(), true);
	}

	private function isWpCreatePostToolsCallPayload( array $params ): bool {
		if (isset($params['name']) && 'wp_create_post' === (string) $params['name']) {
			return true;
		}
		if (isset($params['tool']) && 'wp_create_post' === (string) $params['tool']) {
			return true;
		}
		return false;
	}

	private function isVerboseTraceEnabled(): bool {
		return defined('SFLMCP_VERBOSE_TRACE') && true === SFLMCP_VERBOSE_TRACE;
	}

	private function traceWpCreatePost( string $stage, array $payload = array() ): void {
		if (!$this->isVerboseTraceEnabled()) {
			return;
		}
		$encoded = wp_json_encode(StifliFlexMcpUtils::redactSecrets($payload));
		if (false === $encoded) {
			$encoded = '[unserializable]';
		}
		if (strlen($encoded) > 3000) {
			$encoded = substr($encoded, 0, 3000) . '...[truncated]';
		}
		stifli_flex_mcp_log('[TRACE wp_create_post] ' . $stage . ' ' . $encoded);
	}

	private function traceMcpRequest( string $stage, array $payload = array() ): void {
		if (!$this->isVerboseTraceEnabled()) {
			return;
		}
		$encoded = wp_json_encode(StifliFlexMcpUtils::redactSecrets($payload));
		if (false === $encoded) {
			$encoded = '[unserializable]';
		}
		if (strlen($encoded) > 3000) {
			$encoded = substr($encoded, 0, 3000) . '...[truncated]';
		}
		stifli_flex_mcp_log('[TRACE mcp] ' . $stage . ' ' . $encoded);
	}

	private function getToolNameFromToolsCallParams( array $params ): string {
		if (isset($params['name']) && is_scalar($params['name'])) {
			return (string) $params['name'];
		}
		if (isset($params['tool']) && is_scalar($params['tool'])) {
			return (string) $params['tool'];
		}
		return '';
	}

	private function normalizeArgumentsForTaskKey( $value ) {
		if (!is_array($value)) {
			return $value;
		}
		$isList = array_keys($value) === range(0, count($value) - 1);
		if (!$isList) {
			ksort($value);
		}
		foreach ($value as $k => $v) {
			$value[$k] = $this->normalizeArgumentsForTaskKey($v);
		}
		return $value;
	}

	private function getManagedFallbackTransientKey( int $userId, string $tool, array $arguments ): string {
		$normalized = $this->normalizeArgumentsForTaskKey($arguments);
		$encoded = wp_json_encode($normalized);
		if (false === $encoded) {
			$encoded = '';
		}
		return 'sflmcp_mft_' . md5($userId . '|' . $tool . '|' . $encoded);
	}

	private function buildManagedFallbackWorkingReply( $id, string $taskId, string $tool, string $status = 'working', string $message = '' ): array {
		if ('' === $message) {
			$message = 'Generating media in background. Please wait and repeat the same tool call to retrieve the result.';
		}
		return array(
			'jsonrpc' => '2.0',
			'id' => $id,
			'result' => array(
				'content' => array(
					array(
						'type' => 'text',
						'text' => $message,
					),
				),
				'structuredContent' => array(
					'taskId' => $taskId,
					'status' => $status,
					'tool' => $tool,
				),
				'isError' => false,
			),
		);
	}

	private function withRequestIdFromPayload( array $payload, $id ): array {
		if (isset($payload['error']) && is_array($payload['error'])) {
			return array(
				'jsonrpc' => '2.0',
				'id' => $id,
				'error' => $payload['error'],
			);
		}
		if (isset($payload['result']) && is_array($payload['result'])) {
			return array(
				'jsonrpc' => '2.0',
				'id' => $id,
				'result' => $payload['result'],
			);
		}
		return $this->rpcError($id, -32603, 'Task payload is invalid');
	}

	private function handleManagedToolWithoutTask( $id, string $tool, array $arguments, array $params, string $toolLog ) {
		$userId = (int) get_current_user_id();
		$fallbackKey = $this->getManagedFallbackTransientKey($userId, $tool, $arguments);
		$existingTaskId = get_transient($fallbackKey);

		if (is_string($existingTaskId) && '' !== $existingTaskId) {
			$existingTask = $this->loadTaskRecord($existingTaskId, true);
			if (is_array($existingTask)) {
				$status = isset($existingTask['status']) ? (string) $existingTask['status'] : 'working';
				if ($this->isTaskTerminalStatus($status)) {
					stifli_flex_mcp_log('tools/call: returning completed fallback task result for tool=' . $toolLog . ' taskId=' . $existingTaskId);
					delete_transient($fallbackKey);
					$payload = isset($existingTask['payload']) && is_array($existingTask['payload']) ? $existingTask['payload'] : array();
					return $this->withRequestIdFromPayload($payload, $id);
				}
				stifli_flex_mcp_log('tools/call: fallback task still working for tool=' . $toolLog . ' taskId=' . $existingTaskId);
				return $this->buildManagedFallbackWorkingReply($id, $existingTaskId, $tool, $status);
			}
			delete_transient($fallbackKey);
		}

		$taskReply = $this->createToolTaskResult($id, $tool, $arguments, $params);
		$taskId = isset($taskReply['result']['task']['taskId']) ? (string) $taskReply['result']['task']['taskId'] : '';
		if ('' === $taskId) {
			return $this->rpcError($id, -32603, 'Failed to create background task');
		}

		$taskTtlMs = isset($taskReply['result']['task']['ttl']) ? (int) $taskReply['result']['task']['ttl'] : (int) $this->taskDefaultTtlMs;
		$taskTtlSeconds = max(60, (int) ceil($taskTtlMs / 1000) + 300);
		set_transient($fallbackKey, $taskId, $taskTtlSeconds);

		stifli_flex_mcp_log('tools/call: created fallback background task for tool=' . $toolLog . ' taskId=' . $taskId);
		return $this->buildManagedFallbackWorkingReply($id, $taskId, $tool);
	}

	private function nowIso8601(): string {
		return gmdate('c');
	}

	private function normalizeTaskTtlMs( $requestedTtl ): int {
		if (!is_numeric($requestedTtl)) {
			return (int) $this->taskDefaultTtlMs;
		}
		$ttl = (int) $requestedTtl;
		if ($ttl <= 0) {
			return (int) $this->taskDefaultTtlMs;
		}
		return min($ttl, (int) $this->taskMaxTtlMs);
	}

	private function getTaskTransientKey( string $taskId ): string {
		return 'sflmcp_task_' . md5($taskId);
	}

	private function getTaskIndexTransientKey( int $userId ): string {
		return 'sflmcp_task_index_' . $userId;
	}

	private function getTaskIndexForUser( int $userId ): array {
		if ($userId <= 0) {
			return array();
		}
		$index = get_transient($this->getTaskIndexTransientKey($userId));
		if (!is_array($index)) {
			return array();
		}
		return array_values(array_filter($index, 'is_string'));
	}

	private function saveTaskIndexForUser( int $userId, array $taskIds, int $ttlSeconds ): void {
		if ($userId <= 0) {
			return;
		}
		$taskIds = array_values(array_unique(array_filter($taskIds, 'is_string')));
		if (count($taskIds) > 200) {
			$taskIds = array_slice($taskIds, -200);
		}
		set_transient($this->getTaskIndexTransientKey($userId), $taskIds, max(60, $ttlSeconds));
	}

	private function addTaskToUserIndex( int $userId, string $taskId, int $ttlSeconds ): void {
		$index = $this->getTaskIndexForUser($userId);
		$index[] = $taskId;
		$this->saveTaskIndexForUser($userId, $index, $ttlSeconds);
	}

	private function removeTaskFromUserIndex( int $userId, string $taskId ): void {
		$index = $this->getTaskIndexForUser($userId);
		if (empty($index)) {
			return;
		}
		$index = array_values(array_filter($index, static function( $value ) use ( $taskId ) {
			return $value !== $taskId;
		}));
		$this->saveTaskIndexForUser($userId, $index, 3600);
	}

	private function isTaskTerminalStatus( $status ): bool {
		return in_array($status, array('completed', 'failed', 'cancelled'), true);
	}

	private function isTaskExpired( array $task ): bool {
		if (!isset($task['ttl']) || is_null($task['ttl'])) {
			return false;
		}
		$createdAt = isset($task['createdAt']) ? strtotime((string) $task['createdAt']) : false;
		if (false === $createdAt) {
			return false;
		}
		$expiresAtMs = ((int) $createdAt * 1000) + (int) $task['ttl'];
		$nowMs = (int) round(microtime(true) * 1000);
		return $nowMs > $expiresAtMs;
	}

	private function saveTaskRecord( array $task ): void {
		if (empty($task['taskId'])) {
			return;
		}
		$ttlMs = isset($task['ttl']) && !is_null($task['ttl']) ? (int) $task['ttl'] : (int) $this->taskDefaultTtlMs;
		$ttlSeconds = max(60, (int) ceil($ttlMs / 1000) + 300);
		set_transient($this->getTaskTransientKey($task['taskId']), $task, $ttlSeconds);
		$ownerUserId = isset($task['ownerUserId']) ? (int) $task['ownerUserId'] : 0;
		if ($ownerUserId > 0) {
			$this->addTaskToUserIndex($ownerUserId, $task['taskId'], $ttlSeconds);
		}
	}

	private function loadTaskRecord( string $taskId, bool $pruneExpired = true ) {
		$task = get_transient($this->getTaskTransientKey($taskId));
		if (!is_array($task)) {
			return null;
		}
		if ($pruneExpired && $this->isTaskExpired($task)) {
			$this->deleteTaskRecord($taskId, $task);
			return null;
		}
		return $task;
	}

	private function deleteTaskRecord( string $taskId, $existingTask = null ): void {
		$task = is_array($existingTask) ? $existingTask : $this->loadTaskRecord($taskId, false);
		delete_transient($this->getTaskTransientKey($taskId));
		if (is_array($task) && isset($task['ownerUserId'])) {
			$this->removeTaskFromUserIndex((int) $task['ownerUserId'], $taskId);
		}
	}

	private function formatTaskForResult( array $task ): array {
		$result = array(
			'taskId' => isset($task['taskId']) ? $task['taskId'] : '',
			'status' => isset($task['status']) ? $task['status'] : 'working',
			'createdAt' => isset($task['createdAt']) ? $task['createdAt'] : $this->nowIso8601(),
			'lastUpdatedAt' => isset($task['lastUpdatedAt']) ? $task['lastUpdatedAt'] : $this->nowIso8601(),
			'ttl' => isset($task['ttl']) ? $task['ttl'] : (int) $this->taskDefaultTtlMs,
			'pollInterval' => isset($task['pollInterval']) ? (int) $task['pollInterval'] : (int) $this->taskPollIntervalMs,
		);
		if (!empty($task['statusMessage'])) {
			$result['statusMessage'] = $task['statusMessage'];
		}
		return $result;
	}

	private function getScopedTaskRecord( string $taskId, $id, &$errorReply = null ) {
		$task = $this->loadTaskRecord($taskId, true);
		if (!is_array($task)) {
			$errorReply = $this->rpcError($id, -32602, 'Failed to retrieve task: Task not found');
			return null;
		}
		$currentUserId = get_current_user_id();
		$ownerUserId = isset($task['ownerUserId']) ? (int) $task['ownerUserId'] : 0;
		if ($ownerUserId <= 0 || $currentUserId <= 0 || $ownerUserId !== $currentUserId) {
			$errorReply = $this->rpcError($id, -32602, 'Failed to retrieve task: Task not found');
			return null;
		}
		return $task;
	}

	private function formatModernTask( array $task, string $result_type = 'complete' ): array {
		$result = $this->formatTaskForResult( $task );
		$result['resultType'] = $result_type;
		$result['ttlMs'] = $result['ttl'];
		$result['pollIntervalMs'] = $result['pollInterval'];
		unset( $result['ttl'], $result['pollInterval'] );
		$payload = StifliFlexMcpUtils::getArrayValue( $task, 'payload', array() );
		if ( in_array( $result['status'], array( 'completed', 'failed' ), true ) && isset( $payload['result'] ) ) {
			$result['status'] = 'completed';
			$result['result'] = $payload['result'];
			$result['result']['resultType'] = 'complete';
		} elseif ( 'failed' === $result['status'] ) {
			$result['error'] = StifliFlexMcpUtils::getArrayValue( $payload, 'error', array( 'code' => -32603, 'message' => 'Task failed.' ) );
			if ( ! is_int( $result['error']['code'] ) ) {
				$result['error']['code'] = -32603;
			}
		}
		return $result;
	}

	private function handleModernTaskMethod( string $method, array $params, $id ): array {
		$task_id = StifliFlexMcpUtils::getArrayValue( $params, 'taskId', '' );
		if ( ! is_string( $task_id ) || '' === $task_id ) {
			return $this->rpcError( $id, -32602, 'taskId is required.' );
		}
		$error = null;
		$task = $this->getScopedTaskRecord( $task_id, $id, $error );
		if ( ! is_array( $task ) ) {
			return $error;
		}
		if ( 'tasks/get' === $method ) {
			return array( 'result' => $this->formatModernTask( $task ) );
		}
		if ( 'tasks/update' === $method && ! is_array( StifliFlexMcpUtils::getArrayValue( $params, 'inputResponses', null ) ) ) {
			return $this->rpcError( $id, -32602, 'inputResponses must be an object.' );
		}
		if ( 'tasks/cancel' === $method && ! $this->isTaskTerminalStatus( $task['status'] ) ) {
			$task['status'] = 'cancelled';
			$task['lastUpdatedAt'] = $this->nowIso8601();
			$task['statusMessage'] = 'Cancellation requested.';
			$this->saveTaskRecord( $task );
		}
		return array( 'result' => array( 'resultType' => 'complete' ) );
	}

	private function createToolTaskResult( $id, string $tool, array $arguments, array $params ): array {
		$taskParams = isset($params['task']) && is_array($params['task']) ? $params['task'] : array();
		$ttlMs = $this->normalizeTaskTtlMs(isset($taskParams['ttl']) ? $taskParams['ttl'] : null);
		$taskId = wp_generate_uuid4();
		$now = $this->nowIso8601();
		$connectionContext = isset($params['_sflmcp_connection_context']) && is_array($params['_sflmcp_connection_context'])
			? $params['_sflmcp_connection_context']
			: $this->buildToolConnectionContext( $tool, $id, $arguments, true );
		$connectionContext['task_id'] = $taskId;

		$task = array(
			'taskId' => $taskId,
			'status' => 'working',
			'statusMessage' => 'The operation is now in progress.',
			'createdAt' => $now,
			'lastUpdatedAt' => $now,
			'ttl' => $ttlMs,
			'pollInterval' => (int) $this->taskPollIntervalMs,
			'ownerUserId' => (int) get_current_user_id(),
			'toolName' => $tool,
			'toolArguments' => $arguments,
			'connectionContext' => $connectionContext,
			'requestId' => $id,
			'payload' => null,
		);

		$this->saveTaskRecord($task);

		if (!wp_next_scheduled('sflmcp_process_task', array($taskId))) {
			wp_schedule_single_event(time() + 1, 'sflmcp_process_task', array($taskId));
			if (function_exists('spawn_cron')) {
				spawn_cron(time());
			}
		}

		return array(
			'jsonrpc' => '2.0',
			'id' => $id,
			'result' => array(
				'task' => $this->formatTaskForResult($task),
				'_meta' => array(
					'io.modelcontextprotocol/model-immediate-response' => 'Generating media. Please wait and poll the task status.',
				),
			),
		);
	}

	public function processTaskAsync( $taskId ): void {
		$taskId = is_scalar($taskId) ? (string) $taskId : '';
		if ('' === $taskId) {
			return;
		}

		$task = $this->loadTaskRecord($taskId, true);
		if (!is_array($task)) {
			return;
		}
		if ($this->isTaskTerminalStatus(isset($task['status']) ? $task['status'] : '')) {
			return;
		}
		stifli_flex_mcp_log('task/process: start taskId=' . $taskId . ' tool=' . (isset($task['toolName']) ? $task['toolName'] : 'n/a'));

		if ( function_exists( 'ignore_user_abort' ) ) {
			ignore_user_abort(true);
		}
		// phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged,WordPress.PHP.NoSilencedErrors.Discouraged -- required to avoid execution cut during long-running task processing.
		@set_time_limit(0);

		$originalUserId = get_current_user_id();
		$ownerUserId = isset($task['ownerUserId']) ? (int) $task['ownerUserId'] : 0;
		if ($ownerUserId > 0 && $ownerUserId !== $originalUserId) {
			wp_set_current_user($ownerUserId);
		}
		$this->ensureDispatcherCallbackRegistered();

		try {
			$toolName = isset($task['toolName']) ? (string) $task['toolName'] : '';
			$toolArgs = isset($task['toolArguments']) && is_array($task['toolArguments']) ? $task['toolArguments'] : array();
			$requestId = isset($task['requestId']) ? $task['requestId'] : null;
			if ( class_exists( 'StifliFlexMcpModel' ) && method_exists( 'StifliFlexMcpModel', 'setRuntimeConnectionContext' ) ) {
				$taskContext = isset($task['connectionContext']) && is_array($task['connectionContext']) ? $task['connectionContext'] : array();
				$taskContext['transport'] = 'async_task';
				$taskContext['task_id'] = $taskId;
				StifliFlexMcpModel::setRuntimeConnectionContext( $taskContext );
			}
			$payload = $this->executeTool($toolName, $toolArgs, $requestId);

			$status = 'completed';
			$statusMessage = 'Task completed successfully.';
			if (is_array($payload) && isset($payload['error'])) {
				$status = 'failed';
				$errorMessage = isset($payload['error']['message']) ? (string) $payload['error']['message'] : 'Unknown error';
				$statusMessage = 'Task failed: ' . $errorMessage;
			} elseif (is_array($payload) && isset($payload['result']['isError']) && true === $payload['result']['isError']) {
				$status = 'failed';
				$statusMessage = 'Task failed during tool execution.';
			}

			$task['payload'] = $payload;
			$task['status'] = $status;
			$task['statusMessage'] = $statusMessage;
			$task['lastUpdatedAt'] = $this->nowIso8601();
			$this->saveTaskRecord($task);
			stifli_flex_mcp_log('task/process: done taskId=' . $taskId . ' status=' . $status);
		} catch ( Throwable $e ) {
			$task['payload'] = $this->rpcError(isset($task['requestId']) ? $task['requestId'] : null, -32603, 'Internal task error', $e->getMessage());
			$task['status'] = 'failed';
			$task['statusMessage'] = 'Task failed: ' . $e->getMessage();
			$task['lastUpdatedAt'] = $this->nowIso8601();
			$this->saveTaskRecord($task);
			stifli_flex_mcp_log('task/process: failed taskId=' . $taskId . ' message=' . $e->getMessage());
		}

		if ($ownerUserId !== $originalUserId) {
			wp_set_current_user($originalUserId);
		}
	}

	private function handleTasksMethod( string $method, array $params, $id ) {
		$taskId = isset($params['taskId']) && is_scalar($params['taskId']) ? trim((string) $params['taskId']) : '';

		switch ($method) {
			case 'tasks/get':
				if ('' === $taskId) {
					return $this->rpcError($id, -32602, 'Failed to retrieve task: taskId is required');
				}
				$errorReply = null;
				$task = $this->getScopedTaskRecord($taskId, $id, $errorReply);
				if (!is_array($task)) {
					return $errorReply;
				}
				return array('jsonrpc' => '2.0', 'id' => $id, 'result' => $this->formatTaskForResult($task));

			case 'tasks/result':
				if ('' === $taskId) {
					return $this->rpcError($id, -32602, 'Failed to retrieve task: taskId is required');
				}
				$errorReply = null;
				$task = $this->getScopedTaskRecord($taskId, $id, $errorReply);
				if (!is_array($task)) {
					return $errorReply;
				}
				if (!$this->isTaskTerminalStatus(isset($task['status']) ? $task['status'] : '')) {
					$this->processTaskAsync($taskId);
					$task = $this->loadTaskRecord($taskId, true);
				}
				if (!is_array($task)) {
					return $this->rpcError($id, -32602, 'Failed to retrieve task: Task not found');
				}
				if (!$this->isTaskTerminalStatus(isset($task['status']) ? $task['status'] : '')) {
					return $this->rpcError($id, -32603, 'Task is still in progress');
				}

				$payload = isset($task['payload']) ? $task['payload'] : null;
				if (!is_array($payload)) {
					return $this->rpcError($id, -32603, 'Task has no result payload');
				}

				if (isset($payload['error']) && is_array($payload['error'])) {
					return array('jsonrpc' => '2.0', 'id' => $id, 'error' => $payload['error']);
				}
				if (!isset($payload['result']) || !is_array($payload['result'])) {
					return $this->rpcError($id, -32603, 'Task payload is invalid');
				}

				$result = $payload['result'];
				if (!isset($result['_meta']) || !is_array($result['_meta'])) {
					$result['_meta'] = array();
				}
				$result['_meta']['io.modelcontextprotocol/related-task'] = array('taskId' => $taskId);

				return array('jsonrpc' => '2.0', 'id' => $id, 'result' => $result);

			case 'tasks/cancel':
				if ('' === $taskId) {
					return $this->rpcError($id, -32602, 'Cannot cancel task: taskId is required');
				}
				$errorReply = null;
				$task = $this->getScopedTaskRecord($taskId, $id, $errorReply);
				if (!is_array($task)) {
					return $errorReply;
				}
				if ($this->isTaskTerminalStatus(isset($task['status']) ? $task['status'] : '')) {
					return $this->rpcError($id, -32602, "Cannot cancel task: already in terminal status '" . $task['status'] . "'");
				}
				$task['status'] = 'cancelled';
				$task['statusMessage'] = 'The task was cancelled by request.';
				$task['lastUpdatedAt'] = $this->nowIso8601();
				$this->saveTaskRecord($task);
				return array('jsonrpc' => '2.0', 'id' => $id, 'result' => $this->formatTaskForResult($task));

			case 'tasks/list':
				$cursor = isset($params['cursor']) ? (string) $params['cursor'] : '';
				if ('' !== $cursor && !ctype_digit($cursor)) {
					return $this->rpcError($id, -32602, 'Invalid cursor');
				}
				$offset = '' === $cursor ? 0 : (int) $cursor;
				$limit = 20;

				$userId = (int) get_current_user_id();
				$index = $this->getTaskIndexForUser($userId);
				$tasks = array();
				$validTaskIds = array();
				foreach ($index as $taskIdFromIndex) {
					$task = $this->loadTaskRecord($taskIdFromIndex, true);
					if (!is_array($task)) {
						continue;
					}
					$validTaskIds[] = $taskIdFromIndex;
					$tasks[] = $task;
				}
				$this->saveTaskIndexForUser($userId, $validTaskIds, 3600);

				usort($tasks, static function( $a, $b ) {
					$ta = isset($a['createdAt']) ? strtotime((string) $a['createdAt']) : 0;
					$tb = isset($b['createdAt']) ? strtotime((string) $b['createdAt']) : 0;
					return $tb <=> $ta;
				});

				$total = count($tasks);
				$slice = array_slice($tasks, $offset, $limit);
				$result = array(
					'tasks' => array_map(array($this, 'formatTaskForResult'), $slice),
				);
				if (($offset + $limit) < $total) {
					$result['nextCursor'] = (string) ($offset + $limit);
				}
				return array('jsonrpc' => '2.0', 'id' => $id, 'result' => $result);

			default:
				return $this->rpcError($id, -32601, 'Method not found: ' . $method);
		}
	}

	private function handleToolsCallMethod( $id, array $params ) {

		$this->traceMcpRequest('tools-call/raw-params', array(
			'id' => $id,
			'tool' => $this->getToolNameFromToolsCallParams($params),
			'params' => $params,
		));

		if ($this->isWpCreatePostToolsCallPayload($params)) {
			$this->traceWpCreatePost('tools-call/raw-params', array(
				'id' => $id,
				'params' => $params,
			));
		}

		$tool = null;
		$arguments = array();
		if (isset($params['name'])) {
			$tool = $params['name'];
			$arguments = isset($params['arguments']) && is_array($params['arguments']) ? $params['arguments'] : array();
		} elseif (isset($params['tool'])) {
			$tool = $params['tool'];
			$arguments = isset($params['args']) && is_array($params['args']) ? $params['args'] : array();
		}

		$isTaskAugmented = isset($params['task']) && is_array($params['task']);
		$tool_connection_context = $this->buildToolConnectionContext( $tool, $id, $arguments, $isTaskAugmented );
		if ( class_exists( 'StifliFlexMcpModel' ) && method_exists( 'StifliFlexMcpModel', 'setRuntimeConnectionContext' ) ) {
			StifliFlexMcpModel::setRuntimeConnectionContext( $tool_connection_context );
		}
		$params['_sflmcp_connection_context'] = $tool_connection_context;
		$toolLog = wp_json_encode($tool);
		if (false === $toolLog) {
			$toolLog = is_scalar($tool) ? (string) $tool : '[unserializable]';
		}
		$argsLog = wp_json_encode(StifliFlexMcpUtils::redactSecrets($arguments));
		if (false === $argsLog) {
			$argsLog = '[unserializable]';
		}
		stifli_flex_mcp_log(sprintf('tools/call: tool=%s arguments=%s task_augmented=%s', $toolLog, $argsLog, $isTaskAugmented ? 'yes' : 'no'));
		$this->traceMcpRequest('tools-call/parsed', array(
			'id' => $id,
			'tool' => is_scalar($tool) ? (string) $tool : '',
			'arguments' => StifliFlexMcpUtils::redactSecrets($arguments),
			'task_augmented' => $isTaskAugmented,
		));
		if ('wp_create_post' === $tool) {
			$this->traceWpCreatePost('tools-call/parsed', array(
				'id' => $id,
				'tool' => $tool,
				'arguments' => $arguments,
				'task_augmented' => $isTaskAugmented,
			));
		}

		if ($this->toolRequiresTask($tool)) {
			if ($isTaskAugmented) {
				stifli_flex_mcp_log('tools/call: creating async task for tool=' . $toolLog);
				return $this->createToolTaskResult($id, $tool, $arguments, $params);
			}
			// Compatibility fallback for clients that still don't support task augmentation.
			stifli_flex_mcp_log('tools/call: task missing for managed tool, using async compatibility fallback for tool=' . $toolLog);
			return $this->handleManagedToolWithoutTask($id, $tool, $arguments, $params, $toolLog);
		}

		if ($isTaskAugmented) {
			stifli_flex_mcp_log('tools/call: task augmentation rejected for unsupported tool=' . $toolLog);
			return $this->rpcError($id, -32601, 'Task augmentation is not supported for tool: ' . $tool);
		}
		$this->traceMcpRequest('tools-call/before-execute', array(
			'id' => $id,
			'tool' => is_scalar($tool) ? (string) $tool : '',
		));
		if ('wp_create_post' === $tool) {
			$this->traceWpCreatePost('tools-call/before-execute', array('id' => $id));
		}

		return $this->executeTool($tool, $arguments, $id);
	}

	public function handleSSE( $request ) {
		$body = $request->get_body();
		$remote = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'n/a';
		$uaHeader = $request->get_header('User-Agent');
		$ua = $uaHeader ? sanitize_text_field( $uaHeader ) : 'n/a';
		$hdrAuth = $request->get_header('Authorization') ? 'present' : 'none';
		$qp = $request->get_param('token') ? 'present' : 'none';
		stifli_flex_mcp_log(sprintf('handleSSE start: remote=%s, method=%s, auth_header=%s, query_token=%s, body_len=%d, ua=%s', $remote, $request->get_method(), $hdrAuth, $qp, strlen($body), $ua));
		if ($request->get_method() === 'POST' && !empty($body)) {
			$data = json_decode($body, true);
			return $this->handleDirectJsonRPC($request, $data);
		}
		if ( $this->usesModernProtocol( $request, array() ) ) {
			return $this->handleMessagesGet( $request );
		}
		if ( function_exists( 'ini_set' ) ) {
			ini_set('zlib.output_compression', '0'); // phpcs:ignore WordPress.PHP.DiscouragedFunctions.runtime_ini_set,Squiz.PHP.DiscouragedFunctions.Discouraged
			ini_set('output_buffering', '0'); // phpcs:ignore WordPress.PHP.DiscouragedFunctions.runtime_ini_set,Squiz.PHP.DiscouragedFunctions.Discouraged
			ini_set('implicit_flush', '1'); // phpcs:ignore WordPress.PHP.DiscouragedFunctions.runtime_ini_set,Squiz.PHP.DiscouragedFunctions.Discouraged
		}
		if (function_exists('ob_implicit_flush')) {
			ob_implicit_flush( true );
		}
		header('Content-Type: text/event-stream');
		header('Cache-Control: no-store, no-cache, must-revalidate, private');
		header('Pragma: no-cache');
		header('Expires: 0');
		header('X-Accel-Buffering: no');
		header('Connection: keep-alive');
		header('Access-Control-Allow-Origin: *');
		header('Access-Control-Allow-Headers: Authorization, Content-Type');
		while (ob_get_level()) {
			ob_end_flush();
		}
		$this->sessionID = $this->getSSEid($request);
		$this->lastAction = time();
		$msgUri = sprintf('%s/messages?session_id=%s', rest_url($this->namespace), $this->sessionID);
		// Note: Client must include HTTP Basic auth header when posting to msgUri
		stifli_flex_mcp_log('handleSSE: sessionID=' . $this->sessionID . ' msgUri=' . $msgUri);
		$this->reply('endpoint', $msgUri, 'text');
		while (true) {
			$maxTime = $this->logging ? 60 : 60 * 5;
			$idle = ( time() - $this->lastAction ) >= $maxTime;
			if (connection_aborted() || $idle) {
				stifli_flex_mcp_log('handleSSE: connection aborted or idle, aborting session ' . $this->sessionID);
				$this->reply('bye');
				break;
			}
			foreach ($this->fetchMessages($this->sessionID) as $p) {
				if (isset($p['method']) && 'SFLMCP/kill' === $p['method']) {
					$this->reply('bye');
					exit;
				}
				stifli_flex_mcp_log('handleSSE: sending message to session ' . $this->sessionID . ' method=' . (isset($p['method']) ? $p['method'] : 'n/a'));
				$this->reply('message', $p);
			}
			usleep(200000);
			if (time() - $this->lastAction > 10) $this->reply('heartbeat', ['status' => 'alive']);
		}
		exit;
	}

	private function reply( string $event, $data = null, string $enc = 'json' ) {
		if ('bye' === $event) {
			echo "event: bye\ndata: \n\n";
			if (ob_get_level()) {
				ob_end_flush();
			}
			flush();
			$this->lastAction = time();
			return;
		}
		if ('json' === $enc && null === $data) {
			return;
		}
		echo 'event: ' . esc_attr( $event ) . "\n";
		if ('json' === $enc) {
			// SSE data is consumed by MCP clients (not HTML context).
			// wp_json_encode handles safe encoding; esc_html would break JSON
			// by converting " to &quot;.  phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$data = null === $data ? '{}' : wp_json_encode($data, JSON_UNESCAPED_UNICODE);
		}
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- SSE text/event-stream data, not HTML context
		echo 'data: ' . $data . "\n\n";
		if (ob_get_level()) {
			ob_end_flush();
		}
		flush();
		$this->lastAction = time();
	}

	public function handleDirectJsonRPC( $request, $data ) {
		if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $data ) ) {
			return new WP_REST_Response( array( 'jsonrpc' => '2.0', 'id' => null, 'error' => array( 'code' => -32700, 'message' => 'Parse error: invalid JSON' ) ), 400 );
		}
		if ( $this->usesModernProtocol( $request, $data ) ) {
			return $this->handleModernJsonRPC( $request, $data );
		}
			$this->primeActiveConnectionContext( $request, 'direct_jsonrpc', (string) $request->get_param( 'session_id' ) );
		$id = isset($data['id']) ? $data['id'] : null;
		$method = isset($data['method']) ? $data['method'] : null;
		$replyProtocolVersion = $this->protocolVersion;
		$qp = $request->get_param('token') ? 'present' : 'none';
		$hdr = $request->get_header('Authorization') ? 'present' : 'none';
		stifli_flex_mcp_log(sprintf('handleDirectJsonRPC: id=%s method=%s header=%s query=%s', $id, $method, $hdr, $qp));
		$this->traceMcpRequest('direct-rpc/entry', array(
			'id' => $id,
			'method' => is_scalar($method) ? (string) $method : '',
			'header_auth' => $hdr,
			'query_token' => $qp,
			'data_keys' => is_array($data) ? array_keys($data) : array(),
		));
		if ('tools/call' === $method) {
			$params_for_trace = StifliFlexMcpUtils::getArrayValue($data, 'params', array(), 2);
			if (is_array($params_for_trace)) {
				$this->traceMcpRequest('direct-rpc/tools-call', array(
					'id' => $id,
					'tool' => $this->getToolNameFromToolsCallParams($params_for_trace),
					'params' => $params_for_trace,
				));
			}
			if (is_array($params_for_trace) && $this->isWpCreatePostToolsCallPayload($params_for_trace)) {
				$this->traceWpCreatePost('direct-rpc/entry', array(
					'id' => $id,
					'params' => $params_for_trace,
				));
			}
		}

		// Set session_id for ChangeTracker — use query param or generate per request.
		if ( class_exists( 'StifliFlexMcp_ChangeTracker' ) ) {
			$sess = sanitize_text_field( $request->get_param( 'session_id' ) );
			if ( ! $sess ) {
				$sess = 'mcp-' . wp_generate_uuid4();
			}
			StifliFlexMcp_ChangeTracker::getInstance()->setSessionId( $sess );
		}
		if (json_last_error() !== JSON_ERROR_NONE) {
			return new WP_REST_Response(array(
				'jsonrpc' => '2.0',
				'id' => null,
				'error' => array('code' => -32700, 'message' => 'Parse error: invalid JSON'),
			), 200);
		}
		if (!is_array($data) || !$method) {
			return new WP_REST_Response(array(
				'jsonrpc' => '2.0',
				'id' => $id,
				'error' => array('code' => -32600, 'message' => 'Invalid Request'),
			), 200);
		}
		$headerProtocolVersion = $this->getProtocolVersionHeader($request);
		if ('initialize' !== $method && null !== $headerProtocolVersion) {
			if (!$this->isSupportedProtocolVersion($headerProtocolVersion)) {
				return $this->protocolVersionErrorResponse($id, $headerProtocolVersion);
			}
			$replyProtocolVersion = $headerProtocolVersion;
		}
		try {
			$reply = null;
			switch ($method) {
				case 'initialize':
					$params = StifliFlexMcpUtils::getArrayValue($data, 'params', array(), 2);
					$reqVersion = StifliFlexMcpUtils::getArrayValue($params, 'protocolVersion', null);
					$replyProtocolVersion = $this->negotiateProtocolVersion($reqVersion);
					$clientInfo = StifliFlexMcpUtils::getArrayValue($params, 'clientInfo', false);

					// Store MCP client name for source tracking
					if ( $clientInfo && class_exists( 'StifliFlexMcp_ChangeTracker' ) ) {
						$client_name = is_array( $clientInfo ) && ! empty( $clientInfo['name'] ) ? $clientInfo['name'] : '';
						if ( $client_name ) {
							StifliFlexMcp_ChangeTracker::setSourceContext( 'mcp', $client_name );
						}
					}

					$reply = array(
						'jsonrpc' => '2.0',
						'id' => $id,
						'result' => array(
							'protocolVersion' => $replyProtocolVersion,
							'serverInfo' => $this->getServerInfo( $replyProtocolVersion ),
							'capabilities' => array(
								'tools' => array('listChanged' => false),
								'prompts' => array('subscribe' => false, 'listChanged' => false),
								'resources' => array('subscribe' => false, 'listChanged' => false),
								'tasks' => array(
									'list' => (object) array(),
									'cancel' => (object) array(),
									'requests' => array(
										'tools' => array(
											'call' => (object) array(),
										),
									),
								),
							),
						),
					);
					break;
				case 'ping':
					$reply = array(
						'jsonrpc' => '2.0',
						'id' => $id,
						'result' => (object) array(),
					);
					break;
				case 'tools/list':
					$tools = $this->getToolsList();
					$reply = array(
						'jsonrpc' => '2.0',
						'id' => $id,
						'result' => array('tools' => $tools),
					);
					break;
				case 'tools/call':
					$params = StifliFlexMcpUtils::getArrayValue($data, 'params', array(), 2);
					$reply = $this->handleToolsCallMethod($id, $params);
					break;
				case 'tasks/get':
				case 'tasks/result':
				case 'tasks/list':
				case 'tasks/cancel':
					$params = StifliFlexMcpUtils::getArrayValue($data, 'params', array(), 2);
					$reply = $this->handleTasksMethod($method, $params, $id);
					break;
				case 'initialized':
				case 'notifications/initialized':
					return $this->withProtocolHeaders(new WP_REST_Response(null, 202), $replyProtocolVersion, false);
				case 'resources/list':
					$reply = array(
						'jsonrpc' => '2.0',
						'id' => $id,
						'result' => array('resources' => $this->getResourcesList()),
					);
					break;
				case 'resources/read':
					$params = StifliFlexMcpUtils::getArrayValue($data, 'params', array(), 2);
					$reply = $this->handleResourcesReadMethod($id, $params);
					break;
				case 'prompts/list':
					$reply = array(
						'jsonrpc' => '2.0',
						'id' => $id,
						'result' => array('prompts' => array()),
					);
					break;
				default:
					if (is_null($id) && strpos($method, 'notifications/') === 0) {
						return $this->withProtocolHeaders(new WP_REST_Response(null, 202), $replyProtocolVersion, false);
					}
					$reply = array(
						'jsonrpc' => '2.0',
						'id' => $id,
						'error' => array('code' => -32601, 'message' => "Method not found: {$method}"),
					);
			}
			$this->traceMcpRequest('direct-rpc/reply', array(
				'id' => $id,
				'method' => is_scalar($method) ? (string) $method : '',
				'has_result' => is_array($reply) && isset($reply['result']),
				'has_error' => is_array($reply) && isset($reply['error']),
			));
			return $this->withProtocolHeaders(new WP_REST_Response($reply, 200), $replyProtocolVersion);
		}
		catch ( Exception $e ) {
			$this->traceMcpRequest('direct-rpc/exception', array(
				'id' => $id,
				'method' => is_scalar($method) ? (string) $method : '',
				'message' => $e->getMessage(),
			));
			return $this->withProtocolHeaders(new WP_REST_Response(array(
				'jsonrpc' => '2.0',
				'id' => $id,
				'error' => array('code' => -44000, 'message' => 'Internal error', 'data' => $e->getMessage())
			), 200), $replyProtocolVersion);
		}
	}

	public function handleMessagesGet( $request ) {
		$response = new WP_REST_Response(null, 405);
		$response->set_headers(array_merge($this->getNoCacheHeaders(), array(
			'Allow' => 'POST',
			'MCP-Protocol-Version' => $this->protocolVersion,
		)));
		return $response;
	}

	public function handleMessage( $request ) {
		$decoded = json_decode( $request->get_body(), true );
		if ( ! $request->get_param( 'session_id' ) || ( is_array( $decoded ) && $this->usesModernProtocol( $request, $decoded ) ) ) {
			return $this->handleDirectJsonRPC( $request, $decoded );
		}
		   $sess = sanitize_text_field($request->get_param('session_id'));
		   $this->primeActiveConnectionContext( $request, 'messages_post', $sess );
		   $body = $request->get_body();
		   $hdr = $request->get_header('Authorization') ? 'present' : 'none';
		   $qp = $request->get_param('token') ? 'present' : 'none';
		   $remote = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'n/a';
		   $this->traceMcpRequest('messages/entry', array(
			   'session' => $sess,
			   'remote' => $remote,
			   'header_auth' => $hdr,
			   'query_token' => $qp,
			   'body_len' => strlen($body),
		   ));
		   if (false !== strpos((string) $body, 'wp_create_post')) {
			   $this->traceWpCreatePost('messages/entry-body-hit', array(
				   'session' => $sess,
				   'remote' => $remote,
				   'body_len' => strlen($body),
			   ));
		   }
		   stifli_flex_mcp_log(sprintf('handleMessage: session=%s remote=%s header=%s query=%s body_len=%d', $sess, $remote, $hdr, $qp, strlen($body)));
		   $data = json_decode($body, true);
		   $decodedForLog = wp_json_encode(StifliFlexMcpUtils::redactSecrets($data));
		   if (false === $decodedForLog) {
			   $decodedForLog = '[unserializable]';
		   }
		   stifli_flex_mcp_log('handleMessage: JSON decoded: ' . $decodedForLog);
		   $id = isset($data['id']) ? $data['id'] : null;
		   $method = StifliFlexMcpUtils::getArrayValue($data, 'method', null);
		   $this->traceMcpRequest('messages/decoded', array(
			   'session' => $sess,
			   'id' => $id,
			   'method' => is_scalar($method) ? (string) $method : '',
			   'json_error' => json_last_error(),
			   'data_keys' => is_array($data) ? array_keys($data) : array(),
		   ));
		   if ('tools/call' === $method) {
			   $params_for_trace = StifliFlexMcpUtils::getArrayValue($data, 'params', array(), 2);
			   if (is_array($params_for_trace)) {
				   $this->traceMcpRequest('messages/tools-call', array(
					   'id' => $id,
					   'tool' => $this->getToolNameFromToolsCallParams($params_for_trace),
					   'params' => $params_for_trace,
				   ));
			   }
			   if (is_array($params_for_trace) && $this->isWpCreatePostToolsCallPayload($params_for_trace)) {
				   $this->traceWpCreatePost('messages/decoded-tools-call', array(
					   'id' => $id,
					   'params' => $params_for_trace,
				   ));
			   }
		   }
		   $replyProtocolVersion = $this->protocolVersion;
		   $headerProtocolVersion = $this->getProtocolVersionHeader($request);
		if ('initialize' !== $method && null !== $headerProtocolVersion) {
			if (!$this->isSupportedProtocolVersion($headerProtocolVersion)) {
				return $this->protocolVersionErrorResponse($id, $headerProtocolVersion);
			}
			$replyProtocolVersion = $headerProtocolVersion;
		}
		if ('initialized' === $method || 'notifications/initialized' === $method) {
			return $this->withProtocolHeaders(new WP_REST_Response(null, 202), $replyProtocolVersion, false);
		}
		if ('SFLMCP/kill' === $method) {
			$this->storeMessage($sess, array('jsonrpc' => '2.0', 'method' => 'SFLMCP/kill'));
			usleep( 100000 );
			return $this->withProtocolHeaders(new WP_REST_Response(null, 202), $replyProtocolVersion, false);
		}
		if (is_null($id) && !is_null($method)) {
			return $this->withProtocolHeaders(new WP_REST_Response(null, 202), $replyProtocolVersion, false);
		}
		if (!$method) {
			$hasRpcResponseShape = is_array($data)
				&& array_key_exists('id', $data)
				&& (array_key_exists('result', $data) || array_key_exists('error', $data));
			if ($hasRpcResponseShape) {
				return $this->withProtocolHeaders(new WP_REST_Response(null, 202), $replyProtocolVersion, false);
			}
			$this->queueError($sess, $id, -32900, 'Invalid Request: method missing');
			return $this->withProtocolHeaders(new WP_REST_Response(null, 202), $replyProtocolVersion, false);
		}

		// Pass session_id to ChangeTracker for grouping
		if ( class_exists( 'StifliFlexMcp_ChangeTracker' ) ) {
			StifliFlexMcp_ChangeTracker::getInstance()->setSessionId( $sess ?: 'sse-' . wp_generate_uuid4() );
		}

		try {
			$reply = null;
			switch ($method) {
				case 'initialize':
					$params = StifliFlexMcpUtils::getArrayValue($data, 'params', array(), 2);
					$requestedVersion = StifliFlexMcpUtils::getArrayValue($params, 'protocolVersion', null);
					$replyProtocolVersion = $this->negotiateProtocolVersion($requestedVersion);
					$clientInfo = StifliFlexMcpUtils::getArrayValue($params, 'clientInfo', null);

					// Store MCP client name for source tracking (e.g. "Claude", "ChatGPT")
					if ( $clientInfo && class_exists( 'StifliFlexMcp_ChangeTracker' ) ) {
						$client_name = is_array( $clientInfo ) && ! empty( $clientInfo['name'] ) ? $clientInfo['name'] : '';
						if ( $client_name ) {
							StifliFlexMcp_ChangeTracker::setSourceContext( 'mcp', $client_name );
						}
					}

					$reply = array(
						'jsonrpc' => '2.0',
						'id' => $id,
						'result' => array(
							'protocolVersion' => $replyProtocolVersion,
							'serverInfo' => $this->getServerInfo( $replyProtocolVersion ),
							'capabilities' => array(
								'tools' => array('listChanged' => false),
								'prompts' => array('subscribe' => false, 'listChanged' => false),
								'resources' => array('subscribe' => false, 'listChanged' => false),
								'tasks' => array(
									'list' => (object) array(),
									'cancel' => (object) array(),
									'requests' => array(
										'tools' => array(
											'call' => (object) array(),
										),
									),
								),
							),
						),
					);
					break;
				case 'ping':
					$reply = array(
						'jsonrpc' => '2.0',
						'id' => $id,
						'result' => (object) array(),
					);
					break;
				case 'tools/list':
					$tools = $this->getToolsList();
					$reply = array(
						'jsonrpc' => '2.0',
						'id' => $id,
						'result' => array('tools' => $tools),
					);
					break;
				case 'resources/list':
					$reply = array(
						'jsonrpc' => '2.0',
						'id' => $id,
						'result' => array('resources' => $this->getResourcesList()),
					);
					break;
				case 'resources/read':
					$params = StifliFlexMcpUtils::getArrayValue($data, 'params', array(), 2);
					$reply = $this->handleResourcesReadMethod($id, $params);
					break;
				case 'prompts/list':
					$reply = array(
						'jsonrpc' => '2.0',
						'id' => $id,
						'result' => array('prompts' => $this->getPromptsList()),
					);
					break;
				case 'tools/call':
					$params = StifliFlexMcpUtils::getArrayValue($data, 'params', array(), 2);
					$reply = $this->handleToolsCallMethod($id, $params);
					break;
				case 'tasks/get':
				case 'tasks/result':
				case 'tasks/list':
				case 'tasks/cancel':
					$params = StifliFlexMcpUtils::getArrayValue($data, 'params', array(), 2);
					$reply = $this->handleTasksMethod($method, $params, $id);
					break;
				default:
					$reply = $this->rpcError($id, -32601, "Method not found: {$method}");
			}
			if ($reply) {
				$this->traceMcpRequest('messages/reply', array(
					'session' => $sess,
					'id' => $id,
					'method' => is_scalar($method) ? (string) $method : '',
					'has_result' => is_array($reply) && isset($reply['result']),
					'has_error' => is_array($reply) && isset($reply['error']),
				));
				if ('' !== $sess) {
					$this->storeMessage($sess, $reply);
					stifli_flex_mcp_log(sprintf('handleMessage: queued response for session=%s id=%s method=%s', $sess, $id, $method));
					return $this->withProtocolHeaders(new WP_REST_Response(null, 202), $replyProtocolVersion, false);
				}
				return $this->withProtocolHeaders(new WP_REST_Response($reply, 200), $replyProtocolVersion);
			}
		}
		catch ( Exception $e ) {
			$this->traceMcpRequest('messages/exception', array(
				'session' => $sess,
				'id' => $id,
				'method' => is_scalar($method) ? (string) $method : '',
				'message' => $e->getMessage(),
			));
			$error = $this->rpcError($id, -45603, 'Internal error', $e->getMessage() );
			return $this->withProtocolHeaders(new WP_REST_Response($error, 200), $replyProtocolVersion);
		}
		$this->traceMcpRequest('messages/no-reply-202', array(
			'session' => $sess,
			'id' => $id,
			'method' => is_scalar($method) ? (string) $method : '',
		));
		return $this->withProtocolHeaders(new WP_REST_Response(null, 202), $replyProtocolVersion, false);
	}

	public function getToolsList() {
		$model = new StifliFlexMcpModel();
		return $model->getToolsList();
	}

	private function getResourcesList() {
		return array(
			array(
				'uri' => 'wp://site/info',
				'name' => 'Site Info',
				'description' => 'Compact WordPress site identity, environment, theme, permalink and MCP server context.',
				'mimeType' => 'application/json',
			),
			array(
				'uri' => 'wp://site/post-types',
				'name' => 'Public Post Types',
				'description' => 'Public post types with labels, REST bases, taxonomies and common editor supports.',
				'mimeType' => 'application/json',
			),
			array(
				'uri' => 'wp://site/recent-posts',
				'name' => 'Recent Posts',
				'description' => 'Recent public posts and pages with IDs, status, modified dates, permalinks and excerpts.',
				'mimeType' => 'application/json',
			),
			array(
				'uri' => 'wp://seo/summary',
				'name' => 'SEO Summary',
				'description' => 'Read-only SEO plugin and Search Console configuration summary without loading optional SEO modules.',
				'mimeType' => 'application/json',
			),
		);
	}

	private function handleResourcesReadMethod( $id, $params ) {
		$params = is_array($params) ? $params : array();
		$uri = isset($params['uri']) ? sanitize_text_field((string) $params['uri']) : '';
		if ('' === $uri) {
			return $this->rpcError($id, -32602, 'Missing required resource uri.');
		}

		$payload = $this->readResourcePayload($uri);
		if (is_wp_error($payload)) {
			return $this->rpcError($id, -32004, $payload->get_error_message());
		}

		$text = wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
		if (false === $text) {
			$text = '{}';
		}

		return array(
			'jsonrpc' => '2.0',
			'id' => $id,
			'result' => array(
				'contents' => array(
					array(
						'uri' => $uri,
						'mimeType' => 'application/json',
						'text' => $text,
					),
				),
			),
		);
	}

	private function readResourcePayload( $uri ) {
		switch ((string) $uri) {
			case 'wp://site/info':
				return $this->buildSiteInfoResource();
			case 'wp://site/post-types':
				return $this->buildPostTypesResource();
			case 'wp://site/recent-posts':
				return $this->buildRecentPostsResource();
			case 'wp://seo/summary':
				return $this->buildSeoSummaryResource();
		}

		return new WP_Error('resource_not_found', 'Unknown MCP resource: ' . (string) $uri);
	}

	private function buildSiteInfoResource() {
		$theme = wp_get_theme();
		$active_plugins = get_option('active_plugins', array());
		$active_plugins = is_array($active_plugins) ? $active_plugins : array();

		return array(
			'uri' => 'wp://site/info',
			'name' => get_bloginfo('name'),
			'description' => get_bloginfo('description'),
			'home_url' => home_url('/'),
			'site_url' => site_url('/'),
			'rest_url' => rest_url(),
			'language' => get_bloginfo('language'),
			'timezone' => wp_timezone_string(),
			'current_time' => current_time('mysql'),
			'wordpress_version' => get_bloginfo('version'),
			'multisite' => is_multisite(),
			'permalink_structure' => get_option('permalink_structure'),
			'active_theme' => array(
				'name' => $theme->get('Name'),
				'version' => $theme->get('Version'),
				'stylesheet' => get_stylesheet(),
				'template' => get_template(),
			),
			'active_plugins_count' => count($active_plugins),
			'mcp' => array(
				'namespace' => $this->namespace,
				'protocol_version' => $this->protocolVersion,
			),
		);
	}

	private function buildPostTypesResource() {
		$post_types = get_post_types(array('public' => true), 'objects');
		$out = array();

		foreach ($post_types as $name => $post_type) {
			$supports = array();
			foreach (array('title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'revisions') as $feature) {
				if (post_type_supports($name, $feature)) {
					$supports[] = $feature;
				}
			}

			$out[] = array(
				'name' => $name,
				'label' => isset($post_type->label) ? $post_type->label : $name,
				'rest_base' => !empty($post_type->rest_base) ? $post_type->rest_base : $name,
				'has_archive' => !empty($post_type->has_archive),
				'hierarchical' => !empty($post_type->hierarchical),
				'taxonomies' => get_object_taxonomies($name),
				'supports' => $supports,
			);
		}

		return array(
			'uri' => 'wp://site/post-types',
			'post_types' => $out,
			'total' => count($out),
		);
	}

	private function buildRecentPostsResource() {
		$query = new WP_Query(array(
			'post_type' => array('post', 'page'),
			'post_status' => array('publish', 'draft', 'pending', 'future', 'private'),
			'posts_per_page' => 10,
			'orderby' => 'modified',
			'order' => 'DESC',
			'no_found_rows' => true,
		));
		$items = array();

		foreach ($query->posts as $post) {
			if (!current_user_can('edit_post', $post->ID)) {
				continue;
			}
			$content = wp_strip_all_tags(strip_shortcodes((string) $post->post_content));
			$excerpt = wp_strip_all_tags((string) $post->post_excerpt);
			if ('' === trim($excerpt)) {
				$excerpt = wp_trim_words($content, 28, '');
			}
			$items[] = array(
				'id' => (int) $post->ID,
				'post_type' => $post->post_type,
				'post_status' => $post->post_status,
				'title' => get_the_title($post),
				'permalink' => get_permalink($post),
				'modified_gmt' => $post->post_modified_gmt,
				'excerpt' => trim(preg_replace('/\s+/', ' ', $excerpt)),
			);
		}

		return array(
			'uri' => 'wp://site/recent-posts',
			'items' => $items,
			'total' => count($items),
		);
	}

	private function buildSeoSummaryResource() {
		$settings = get_option('sflmcp_seo_settings', array());
		$settings = is_array($settings) ? $settings : array();
		$gsc_enabled = isset($settings['gsc_enabled']) && '1' === (string) $settings['gsc_enabled'];
		$gsc_configured = !empty($settings['gsc_oauth_client_id']) && !empty($settings['gsc_oauth_client_secret']) && !empty($settings['gsc_oauth_refresh_token']);
		$tools_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_tools', false);
		$seo_tools = array();

		if (function_exists('stifli_flex_mcp_table_exists') && stifli_flex_mcp_table_exists($tools_table)) {
			global $wpdb;
			$tools_table_sql = StifliFlexMcpUtils::getPrefixedTable('sflmcp_tools');
			$cache_key = 'seo_summary_tools';
			$rows = wp_cache_get($cache_key, 'sflmcp');
			if (false === $rows) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- plugin table name is sanitized by getPrefixedTable().
				$rows = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT tool_name, enabled FROM {$tools_table_sql} WHERE category LIKE %s OR category = %s ORDER BY category, tool_name",
						$wpdb->esc_like('SEO - ') . '%',
						'WordPress - SEO'
					),
					ARRAY_A
				);
				wp_cache_set($cache_key, $rows, 'sflmcp', 5 * MINUTE_IN_SECONDS);
			}
			if (is_array($rows)) {
				foreach ($rows as $row) {
					$seo_tools[] = array(
						'name' => isset($row['tool_name']) ? $row['tool_name'] : '',
						'enabled' => isset($row['enabled']) ? 1 === (int) $row['enabled'] : false,
					);
				}
			}
		}

		return array(
			'uri' => 'wp://seo/summary',
			'plugins' => array(
				'yoast_active' => defined('WPSEO_VERSION') || function_exists('YoastSEO'),
				'rank_math_active' => defined('RANK_MATH_VERSION') || function_exists('rank_math'),
			),
			'search_console' => array(
				'enabled' => $gsc_enabled,
				'configured' => $gsc_configured,
				'runtime_available' => function_exists('stifli_flex_mcp_is_gsc_enabled_for_runtime') ? stifli_flex_mcp_is_gsc_enabled_for_runtime() : false,
				'default_property' => isset($settings['gsc_site_url']) ? sanitize_text_field((string) $settings['gsc_site_url']) : '',
				'cache_ttl' => isset($settings['gsc_cache_ttl']) ? absint($settings['gsc_cache_ttl']) : 900,
				'connected_at' => isset($settings['gsc_oauth_connected_at']) ? sanitize_text_field((string) $settings['gsc_oauth_connected_at']) : '',
				'last_test_status' => isset($settings['gsc_last_test_status']) ? sanitize_text_field((string) $settings['gsc_last_test_status']) : '',
			),
			'tools' => $seo_tools,
		);
	}

	private function getPromptsList() {
		return array();
	}

	private function executeTool( $tool, $args, $id ) {
		try {
			$toolLog = wp_json_encode($tool);
			if (false === $toolLog) {
				$toolLog = is_scalar($tool) ? (string) $tool : '[unserializable]';
			}
			$argsLog = wp_json_encode(StifliFlexMcpUtils::redactSecrets($args));
			if (false === $argsLog) {
				$argsLog = '[unserializable]';
			}
			$idLog = wp_json_encode($id);
			if (false === $idLog) {
				$idLog = is_scalar($id) ? (string) $id : '[unserializable]';
			}
			stifli_flex_mcp_log(sprintf('executeTool: tool=%s args=%s id=%s', $toolLog, $argsLog, $idLog));
			$this->traceMcpRequest('execute/start', array(
				'id' => $id,
				'tool' => is_scalar($tool) ? (string) $tool : '',
				'args' => is_array($args) ? StifliFlexMcpUtils::redactSecrets($args) : array(),
			));
			if ('wp_create_post' === $tool) {
				$this->traceWpCreatePost('execute/start', array(
					'id' => $id,
					'tool' => $tool,
					'args' => $args,
				));
			}

			$filtered = StifliFlexMcpDispatcher::applyFilters('sflmcp_callback', null, $tool, $args, $id, $this);
			if (!is_null($filtered)) {
				$this->traceMcpRequest('execute/after-filter', array(
					'id' => $id,
					'tool' => is_scalar($tool) ? (string) $tool : '',
					'has_result' => is_array($filtered) && isset($filtered['result']),
					'has_error' => is_array($filtered) && isset($filtered['error']),
				));
				if ('wp_create_post' === $tool) {
					$this->traceWpCreatePost('execute/after-filter', array(
						'id' => $id,
						'has_result' => is_array($filtered) && isset($filtered['result']),
						'has_error' => is_array($filtered) && isset($filtered['error']),
						'filtered' => $filtered,
					));
				}
				if (is_array($filtered) && isset($filtered['error']) && !isset($filtered['result'])) {
					return $this->convertToolErrorToResult($filtered, $id, is_scalar($tool) ? (string) $tool : '');
				}
				if (is_array($filtered) && isset($filtered['jsonrpc']) && isset($filtered['id'])) {
					return $filtered;
				}
				return array(
					'jsonrpc' => '2.0',
					'id' => $id,
					'result' => $filtered,
				);
			}

			throw new Exception("Unknown tool: {$tool}");
		} catch ( Exception $e ) {
			stifli_flex_mcp_log('executeTool: Exception: ' . $e->getMessage());
			$this->traceMcpRequest('execute/exception', array(
				'id' => $id,
				'tool' => is_scalar($tool) ? (string) $tool : '',
				'message' => $e->getMessage(),
			));
			if ('wp_create_post' === $tool) {
				$this->traceWpCreatePost('execute/exception', array(
					'id' => $id,
					'message' => $e->getMessage(),
				));
			}
			return $this->convertToolErrorToResult(
				$this->rpcError( $id, -44003, $e->getMessage() ),
				$id,
				is_scalar($tool) ? (string) $tool : ''
			);
		} finally {
			if ( class_exists( 'StifliFlexMcpModel' ) && method_exists( 'StifliFlexMcpModel', 'clearRuntimeConnectionContext' ) ) {
				StifliFlexMcpModel::clearRuntimeConnectionContext();
			}
		}
	}

	private function convertToolErrorToResult( array $payload, $id, string $tool = '' ): array {
		$error = isset($payload['error']) && is_array($payload['error']) ? $payload['error'] : array();
		$errorCodeRaw = isset($error['code']) ? $error['code'] : -32603;
		$errorCodeNumeric = is_int($errorCodeRaw)
			? $errorCodeRaw
			: (is_numeric($errorCodeRaw) ? intval($errorCodeRaw) : -32603);
		$errorCodeLabel = is_scalar($errorCodeRaw) ? (string) $errorCodeRaw : '';

		$errorMessage = isset($error['message']) && is_scalar($error['message'])
			? (string) $error['message']
			: 'Tool execution failed.';

		$structured = array(
			'success' => false,
			'error_code' => $errorCodeNumeric,
			'error_message' => $errorMessage,
		);

		if ('' !== $tool) {
			$structured['tool'] = $tool;
		}
		if ('' !== $errorCodeLabel && (string) $errorCodeNumeric !== $errorCodeLabel) {
			$structured['error_slug'] = $errorCodeLabel;
		}
		if (isset($error['data'])) {
			$structured['error_data'] = $error['data'];
		}

		return array(
			'jsonrpc' => '2.0',
			'id' => $id,
			'result' => array(
				'content' => array(
					array(
						'type' => 'text',
						'text' => $errorMessage,
					),
				),
				'structuredContent' => $structured,
				'isError' => true,
			),
		);
	}

	private function rpcError( $id, int $code, string $msg, $extra = null ): array {
		$err = array('code' => $code, 'message' => $msg);
		if (!is_null($extra)) {
			$err['data'] = $extra;
		}
		return array('jsonrpc' => '2.0', 'id' => $id, 'error' => $err);
	}

	private function queueError( $sess, $id, int $code, string $msg, $extra = null ): void {
		$this->storeMessage($sess, $this->rpcError($id, $code, $msg, $extra));
	}

	/*
	 * Custom queue and profile storage relies on plugin-managed tables.
	 * phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,PluginCheck.Security.DirectDB.UnescapedDBParameter
	 */
	private function storeMessage( $sess, $payload ) {
		if (empty($sess) || empty($this->queueTable)) {
			return;
		}
		global $wpdb;
		$sessionKey = $this->normalizeSessionId($sess);
		if ('' === $sessionKey) {
			return;
		}
		$messageId = null;
		if (is_array($payload) && array_key_exists('id', $payload)) {
			if (is_null($payload['id'])) {
				$messageId = null;
			} elseif (is_scalar($payload['id'])) {
				$messageId = (string) $payload['id'];
			} else {
				$messageId = wp_json_encode($payload['id']);
			}
		}
		if (!is_null($messageId)) {
			$messageId = substr($messageId, 0, 191);
		}
		$nowTs = current_time('timestamp', true);
		$now = gmdate('Y-m-d H:i:s', $nowTs);
		$expires = gmdate('Y-m-d H:i:s', $nowTs + $this->queueTtl);
		$wpdb->insert(
			$this->queueTable,
			array(
				'session_id' => $sessionKey,
				'message_id' => $messageId,
				'payload' => maybe_serialize($payload),
				'created_at' => $now,
				'expires_at' => $expires,
			),
			array('%s', '%s', '%s', '%s', '%s')
		);
	}

	private function fetchMessages( $sess ) {
		if (empty($sess) || empty($this->queueTable)) {
			return array();
		}
		global $wpdb;
		$sessionKey = $this->normalizeSessionId($sess);
		if ('' === $sessionKey) {
			return array();
		}
		$now = gmdate('Y-m-d H:i:s');
		$queue_tbl = StifliFlexMcpUtils::getPrefixedTable('sflmcp_queue');
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- table name from sanitized helper.
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT id, payload FROM {$queue_tbl} WHERE session_id = %s AND expires_at >= %s ORDER BY id ASC", $sessionKey, $now ),
			ARRAY_A
		);
		if (empty($rows)) {
			return array();
		}
		$ids = array();
		$msgs = array();
		foreach ($rows as $row) {
			$ids[] = (int) $row['id'];
			$decoded = maybe_unserialize($row['payload']);
			if ($decoded === false && 'b:0;' !== $row['payload']) {
				$decoded = $row['payload'];
			}
			$msgs[] = $decoded;
		}
		if (!empty($ids)) {
			foreach ($ids as $deleteId) {
				$wpdb->delete($this->queueTable, array('id' => $deleteId), array('%d'));
			}
		}
		return $msgs;
	}

	private function normalizeSessionId( $sess ) {
		if (empty($sess)) {
			return '';
		}
		$sess = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) $sess);
		return substr($sess, 0, 191);
	}
	private function getModel() {
		return new StifliFlexMcpModel();
	}
    
	// ============ PROFILE MANAGEMENT AJAX HANDLERS ============
	
	public function ajax_apply_profile() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => 'No permission'), 403);
		}
		check_ajax_referer('sflmcp_profiles');
		
		global $wpdb;
		$profile_id = isset($_POST['profile_id']) ? absint( wp_unslash( $_POST['profile_id'] ) ) : 0;
		
		if ($profile_id <= 0) {
			wp_send_json_error(array('message' => 'Invalid profile ID'));
		}
		
		$profiles_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profiles', false);
		$profile_tools_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profile_tools', false);
		$tools_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_tools', false);
		$profiles_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profiles_table);
		$profile_tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profile_tools_table);
		$tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($tools_table);
		$profiles_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profiles_table);
		$profile_tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profile_tools_table);
		$tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($tools_table);
		$profiles_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profiles_table);
		$profile_tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profile_tools_table);
		$tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($tools_table);
		$profiles_table_sql = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profiles');
		$profile_tools_table_sql = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profile_tools');
		$tools_table_sql = StifliFlexMcpUtils::getPrefixedTable('sflmcp_tools');
		
		// Get profile tools
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- table name from sanitized helper.
		$profile_tools = $wpdb->get_col(
			$wpdb->prepare( "SELECT tool_name FROM {$profile_tools_table_sql} WHERE profile_id = %d", $profile_id )
		);
		
		if ($profile_tools === null) {
			wp_send_json_error(array('message' => 'Profile not found'));
		}
		
		// Disable all tools first
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- table name from sanitized helper.
		$wpdb->query($wpdb->prepare( "UPDATE {$tools_table_sql} SET enabled = %d", 0 ));
		
		// Enable profile tools
		if (!empty($profile_tools)) {
			$placeholders = implode(',', array_fill(0, count($profile_tools), '%s'));
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- table name from sanitized helper, placeholders are dynamic.
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$tools_table_sql} SET enabled = 1 WHERE tool_name IN ({$placeholders})",
					...$profile_tools
				)
			);
		}
		
		// Mark profile as active
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- table name from sanitized helper.
		$wpdb->query($wpdb->prepare( "UPDATE {$profiles_table_sql} SET is_active = %d", 0 ));
		$wpdb->update($profiles_table, array('is_active' => 1), array('id' => $profile_id), array('%d'), array('%d'));
		
		wp_send_json_success(array('message' => count($profile_tools) . ' herramientas habilitadas'));
	}
	
	public function ajax_delete_profile() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => 'No permission'), 403);
		}
		check_ajax_referer('sflmcp_profiles');
		
		global $wpdb;
		$profile_id = isset($_POST['profile_id']) ? absint( wp_unslash( $_POST['profile_id'] ) ) : 0;
		
		$profiles_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profiles', false);
		$profiles_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profiles_table);
		
		// Check if system profile
		$system_query = sprintf('SELECT is_system FROM %s WHERE id = %%d', $profiles_table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$is_system = $wpdb->get_var($wpdb->prepare($system_query, $profile_id));
		
		if ($is_system === null) {
			wp_send_json_error(array('message' => 'Profile not found'));
		}
		
		if (intval($is_system) === 1) {
			wp_send_json_error(array('message' => 'Cannot delete system profiles'));
		}
		
		$wpdb->delete($profiles_table, array('id' => $profile_id), array('%d'));
		
		wp_send_json_success();
	}
	
	public function ajax_duplicate_profile() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => 'No permission'), 403);
		}
		check_ajax_referer('sflmcp_profiles');
		
		global $wpdb;
		$profile_id = isset($_POST['profile_id']) ? absint( wp_unslash( $_POST['profile_id'] ) ) : 0;
		
		$profiles_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profiles', false);
		$profile_tools_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profile_tools', false);
		$profiles_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profiles_table);
		$profile_tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profile_tools_table);
		
		// Get original profile
		$profile_query = sprintf('SELECT * FROM %s WHERE id = %%d', $profiles_table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$original = $wpdb->get_row($wpdb->prepare($profile_query, $profile_id), ARRAY_A);
		
		if (!$original) {
			wp_send_json_error(array('message' => 'Profile not found'));
		}
		
		// Create new profile name
		$new_name = 'Copia de ' . $original['profile_name'];
		$counter = 1;
		$profile_name_check = sprintf('SELECT id FROM %s WHERE profile_name = %%s', $profiles_table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		while ($wpdb->get_var($wpdb->prepare($profile_name_check, $new_name))) {
			$counter++;
			$new_name = 'Copia de ' . $original['profile_name'] . ' (' . $counter . ')';
		}
		
		$now = current_time('mysql', true);
		
		// Insert new profile
		$wpdb->insert(
			$profiles_table,
			array(
				'profile_name' => $new_name,
				'profile_description' => $original['profile_description'],
				'is_system' => 0, // Duplicates are always custom
				'is_active' => 0,
				'created_at' => $now,
				'updated_at' => $now,
			),
			array('%s', '%s', '%d', '%d', '%s', '%s')
		);
		
		$new_profile_id = $wpdb->insert_id;
		
		// Copy tools
		$tools_query = sprintf('SELECT tool_name FROM %s WHERE profile_id = %%d', $profile_tools_table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$tools = $wpdb->get_col($wpdb->prepare($tools_query, $profile_id));
		
		foreach ($tools as $tool_name) {
			$wpdb->insert(
				$profile_tools_table,
				array(
					'profile_id' => $new_profile_id,
					'tool_name' => $tool_name,
					'created_at' => $now,
				),
				array('%d', '%s', '%s')
			);
		}
		
		wp_send_json_success();
	}
	
	public function ajax_export_profile() {
		if (!current_user_can('manage_options')) {
			wp_die('No permission', 403);
		}
		check_ajax_referer('sflmcp_profiles');
		
		global $wpdb;
		$profile_id = intval($_GET['profile_id'] ?? 0);
		
		$profiles_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profiles', false);
		$profile_tools_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profile_tools', false);
		$tools_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_tools', false);
		$profiles_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profiles_table);
		$profile_tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profile_tools_table);
		$tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($tools_table);
		
		$profile_query = sprintf('SELECT * FROM %s WHERE id = %%d', $profiles_table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$profile = $wpdb->get_row($wpdb->prepare($profile_query, $profile_id), ARRAY_A);
		
		if (!$profile) {
			wp_die('Profile not found', 404);
		}
		
		$tools_query = sprintf('SELECT tool_name FROM %s WHERE profile_id = %%d ORDER BY tool_name', $profile_tools_table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$tools = $wpdb->get_col($wpdb->prepare($tools_query, $profile_id));
		
		// Get categories
		$categories = array();
		if (!empty($tools)) {
			$placeholders = implode(',', array_fill(0, count($tools), '%s'));
			$categories_query = 'SELECT DISTINCT category FROM ' . $tools_table_sql . ' WHERE tool_name IN (' . $placeholders . ') ORDER BY category';
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses dynamic placeholders with prepare.
			$categories = $wpdb->get_col($wpdb->prepare($categories_query, ...$tools));
		}
		
		$export = array(
			'format_version' => '1.0',
			'export_date' => gmdate('Y-m-d\TH:i:s\Z'),
			'plugin_version' => '0.1.0',
			'profile' => array(
				'name' => $profile['profile_name'],
				'description' => $profile['profile_description'],
				'tools' => $tools,
				'tools_count' => count($tools),
				'categories_included' => $categories,
			),
		);
		
		$filename = sanitize_file_name($profile['profile_name']) . '-profile.json';
		
		header('Content-Type: application/json');
		header('Content-Disposition: attachment; filename="' . $filename . '"');
		echo json_encode($export, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
		exit;
	}
	
	public function ajax_import_profile() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => 'No permission'), 403);
		}
		check_ajax_referer('sflmcp_profiles');
		
		global $wpdb;
		$profiles_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profiles', false);
		$profile_tools_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profile_tools', false);
		$tools_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_tools', false);
		$profiles_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profiles_table);
		$profile_tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profile_tools_table);
		$tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($tools_table);

		$json_data = isset($_POST['profile_json']) ? StifliFlexMcpUtils::sanitizeJsonString( sanitize_text_field( wp_unslash( $_POST['profile_json'] ) ) ) : '';
		if (empty($json_data)) {
			wp_send_json_error(array('message' => 'No JSON data provided'));
		}
		
		$data = json_decode($json_data, true);
		if (!$data || !isset($data['profile'])) {
			wp_send_json_error(array('message' => 'Invalid JSON format'));
		}
		
		$profile = $data['profile'];
		$name = sanitize_text_field($profile['name'] ?? 'Importado');
		$description = sanitize_textarea_field($profile['description'] ?? '');
		$tools_list = isset($profile['tools']) && is_array($profile['tools']) ? $profile['tools'] : array();
		$tools = array();
		foreach ($tools_list as $tool_name) {
			if (!is_string($tool_name)) {
				continue;
			}
			$clean_tool = sanitize_key($tool_name);
			if ('' !== $clean_tool) {
				$tools[] = $clean_tool;
			}
		}
		
		// Check if name exists
		$counter = 1;
		$original_name = $name;
		$profile_name_check = sprintf('SELECT id FROM %s WHERE profile_name = %%s', $profiles_table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		while ($wpdb->get_var($wpdb->prepare($profile_name_check, $name))) {
			$counter++;
			$name = $original_name . ' (' . $counter . ')';
		}
		
		// Validate tools exist
		$existing_tools_query = sprintf('SELECT tool_name FROM %s WHERE 1 = %%d', $tools_table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$existing_tools = $wpdb->get_col($wpdb->prepare($existing_tools_query, 1));
		$valid_tools = array_intersect($tools, $existing_tools);
		
		if (empty($valid_tools)) {
			wp_send_json_error(array('message' => 'No valid tools found in profile'));
		}
		
		$now = current_time('mysql', true);
		
		// Insert profile
		$wpdb->insert(
			$profiles_table,
			array(
				'profile_name' => $name,
				'profile_description' => $description,
				'is_system' => 0,
				'is_active' => 0,
				'created_at' => $now,
				'updated_at' => $now,
			),
			array('%s', '%s', '%d', '%d', '%s', '%s')
		);
		
		$profile_id = $wpdb->insert_id;
		
		// Insert tools
		foreach ($valid_tools as $tool_name) {
			$wpdb->insert(
				$profile_tools_table,
				array(
					'profile_id' => $profile_id,
					'tool_name' => $tool_name,
					'created_at' => $now,
				),
				array('%d', '%s', '%s')
			);
		}
		
		$ignored_count = count($tools) - count($valid_tools);
		$message = 'Perfil importado: ' . count($valid_tools) . ' herramientas';
		if ($ignored_count > 0) {
			$message .= ' (' . $ignored_count . ' herramientas no encontradas fueron ignoradas)';
		}
		
		wp_send_json_success(array('message' => $message));
	}
	
	public function ajax_restore_system_profiles() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => 'No permission'), 403);
		}
		check_ajax_referer('sflmcp_profiles');
		
		global $wpdb;
		$profiles_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profiles', false);
		$profile_tools_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profile_tools', false);
		$profiles_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profiles_table);
		$profile_tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profile_tools_table);
		
		// Delete existing system profiles
		$system_ids_query = sprintf('SELECT id FROM %s WHERE is_system = %%d', $profiles_table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$system_ids = $wpdb->get_col($wpdb->prepare($system_ids_query, 1));
		if (!empty($system_ids)) {
			$placeholders = implode(',', array_fill(0, count($system_ids), '%d'));
			$delete_relations_query = 'DELETE FROM ' . $profile_tools_table_sql . ' WHERE profile_id IN (' . $placeholders . ')';
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses dynamic placeholders with prepare.
			$wpdb->query($wpdb->prepare($delete_relations_query, ...$system_ids));
			$delete_profiles_query = sprintf('DELETE FROM %s WHERE is_system = %%d', $profiles_table_sql);
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
			$wpdb->query($wpdb->prepare($delete_profiles_query, 1));
		}
		
		// Re-seed system profiles
		stifli_flex_mcp_seed_system_profiles();
		
		wp_send_json_success();
	}
	
	public function ajax_create_profile() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => 'No permission'), 403);
		}
		check_ajax_referer('sflmcp_profiles');
		
		// TODO: Implement create/edit modal in next phase
		wp_send_json_error(array('message' => 'Not implemented yet'));
	}
	
	public function ajax_update_profile() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => 'No permission'), 403);
		}
		check_ajax_referer('sflmcp_profiles');
		
		// TODO: Implement create/edit modal in next phase
		wp_send_json_error(array('message' => 'Not implemented yet'));
	}

	/**
	 * Register top-level admin menu.
	 * Only creates the parent — submenus are added by priority:
	 *   Priority 10: AI Chat Agent (client class, same slug as parent → first item)
	 *   Priority 20: MCP Server (this class → second item)
	 */
	public function registerAdmin() {
		$top_level_callback = stifli_flex_mcp_addon_enabled( 'ai_chat' ) ? '__return_null' : array($this, 'adminPage');
		add_menu_page(
			__('Flex MCP', 'stifli-flex-mcp'),
			__('Flex MCP', 'stifli-flex-mcp'),
			'manage_options',
			'stifli-flex-mcp',
			$top_level_callback,
			'dashicons-rest-api',
			30
		);
	}

	/**
	 * Register MCP Server submenu at priority 20 (after AI Chat Agent at priority 10).
	 */
	public function registerMcpServerSubmenu() {
		add_submenu_page(
			'stifli-flex-mcp',
			__('MCP Server', 'stifli-flex-mcp'),
			__('MCP Server', 'stifli-flex-mcp'),
			'manage_options',
			'sflmcp-server',
			array($this, 'adminPage')
		);
	}

	/**
	 * Register Multimedia submenu at priority 25 (after MCP Server at 15).
	 */
	public function registerMultimediaSubmenu() {
		add_submenu_page(
			'stifli-flex-mcp',
			__('Multimedia', 'stifli-flex-mcp'),
			__('Multimedia', 'stifli-flex-mcp'),
			'manage_options',
			'sflmcp-multimedia',
			array($this, 'multimediaPage')
		);
	}

	/**
	 * Register SEO submenu without loading the optional SEO module.
	 */
	public function registerSeoSubmenu() {
		add_submenu_page(
			'stifli-flex-mcp',
			__('SEO', 'stifli-flex-mcp'),
			__('SEO', 'stifli-flex-mcp'),
			'manage_options',
			'sflmcp-seo',
			array($this, 'seoPage')
		);
	}

	/**
	 * Load and render the optional SEO admin module on demand.
	 */
	public function seoPage() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'stifli-flex-mcp' ) );
		}

		$seo_admin = function_exists( 'stifli_flex_mcp_load_seo_admin_module' ) ? stifli_flex_mcp_load_seo_admin_module() : null;
		if ( $seo_admin && method_exists( $seo_admin, 'render_page' ) ) {
			$seo_admin->render_page();
			return;
		}

		wp_die( esc_html__( 'SEO module is not available.', 'stifli-flex-mcp' ) );
	}

	/**
	 * Register settings used by the plugin
	 */
	public function registerSettings() {
		// No custom settings needed - uses WordPress Application Passwords
	}

	/**
	 * Check if Application Passwords are available for a given user.
	 *
	 * @param WP_User $user WordPress user object.
	 * @return bool
	 */
	private function isApplicationPasswordsAvailableForUser( $user ) {
		if ( ! class_exists( 'WP_Application_Passwords' ) ) {
			return false;
		}

		if ( function_exists( 'wp_is_application_passwords_available_for_user' ) ) {
			return (bool) wp_is_application_passwords_available_for_user( $user );
		}

		if ( function_exists( 'wp_is_application_passwords_available' ) ) {
			return (bool) wp_is_application_passwords_available();
		}

		return true;
	}

	/**
	 * Check if an application password name already exists for a user.
	 *
	 * @param int    $user_id User ID.
	 * @param string $name    Candidate application password name.
	 * @return bool
	 */
	private function applicationPasswordNameExistsForUser( $user_id, $name ) {
		if ( class_exists( 'WP_Application_Passwords' ) && method_exists( 'WP_Application_Passwords', 'application_name_exists_for_user' ) ) {
			return (bool) WP_Application_Passwords::application_name_exists_for_user( $user_id, $name );
		}

		if ( class_exists( 'WP_Application_Passwords' ) && method_exists( 'WP_Application_Passwords', 'get_user_application_passwords' ) ) {
			$passwords = WP_Application_Passwords::get_user_application_passwords( $user_id );
			foreach ( $passwords as $password ) {
				$current_name = isset( $password['name'] ) ? (string) $password['name'] : '';
				if ( 0 === strcasecmp( $current_name, $name ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Generate a unique default Application Password name for the current site.
	 *
	 * @param int $user_id User ID.
	 * @return string
	 */
	private function getNextDefaultApplicationPasswordName( $user_id ) {
		$base_name  = 'StifLi MCP App';
		$candidate  = $base_name;
		$next_index = 2;

		while ( $this->applicationPasswordNameExistsForUser( $user_id, $candidate ) ) {
			$candidate = $base_name . ' ' . $next_index;
			$next_index++;

			if ( $next_index > 999 ) {
				$candidate = $base_name . ' ' . wp_generate_password( 4, false, false );
				break;
			}
		}

		return $candidate;
	}

	private function getOAuthWellKnownProbeTransientKey() {
		$host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
		if ('' === $host) {
			$host = 'site';
		}
		$path = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_PATH));
		return 'sflmcp_oauth_wk_probe_' . md5('v2|' . $host . '|' . $path);
	}

	private function getOAuthWellKnownDismissOptionKey() {
		$host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
		if ('' === $host) {
			$host = 'site';
		}
		$path = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_PATH));
		return 'sflmcp_oauth_wk_notice_dismissed_' . md5('v2|' . $host . '|' . $path);
	}

	private function invalidateOAuthWellKnownProbeCache() {
		delete_transient($this->getOAuthWellKnownProbeTransientKey());
		delete_option($this->getOAuthWellKnownDismissOptionKey());
	}

	private function shouldSkipOAuthWellKnownSelfCheck() {
		if (is_multisite() && !is_main_site()) {
			return true;
		}

		if (function_exists('wp_get_environment_type')) {
			$env = (string) wp_get_environment_type();
			if (in_array($env, array('local', 'development'), true)) {
				return true;
			}
		}

		$host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
		if ('' === $host) {
			return true;
		}

		if (in_array($host, array('localhost', '127.0.0.1', '::1'), true)) {
			return true;
		}

		$devSuffixes = array('.local', '.test', '.example', '.invalid', '.localhost');
		foreach ($devSuffixes as $suffix) {
			if (strlen($host) > strlen($suffix) && substr($host, -strlen($suffix)) === $suffix) {
				return true;
			}
		}

		if (filter_var($host, FILTER_VALIDATE_IP)) {
			$publicIp = filter_var(
				$host,
				FILTER_VALIDATE_IP,
				FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
			);
			if (false === $publicIp) {
				return true;
			}
		}

		return false;
	}

	private function probeOAuthMetadataEndpoint($url) {
		$result = array(
			'status' => 'unknown',
			'blocked' => false,
			'provider' => '',
			'url' => $url,
			'code' => 0,
			'message' => '',
		);

		$response = wp_remote_get($url, array(
			'timeout' => 8,
			'redirection' => 2,
		));

		if (is_wp_error($response)) {
			$result['status'] = 'unknown';
			$result['message'] = $response->get_error_message();
			return $result;
		}

		$code = (int) wp_remote_retrieve_response_code($response);
		$body = (string) wp_remote_retrieve_body($response);
		$server = strtolower((string) wp_remote_retrieve_header($response, 'server'));
		$sucuriId = (string) wp_remote_retrieve_header($response, 'x-sucuri-id');
		$sucuriCache = (string) wp_remote_retrieve_header($response, 'x-sucuri-cache');
		$bodyLower = strtolower($body);
		$result['code'] = $code;
		if ('' !== $sucuriId || '' !== $sucuriCache || false !== strpos($server, 'sucuri') || false !== strpos($server, 'cloudproxy') || false !== strpos($bodyLower, 'sucuri website firewall') || false !== strpos($bodyLower, 'cloudproxy')) {
			$result['provider'] = 'sucuri';
		}

		if (200 === $code) {
			$bodyHead = strtolower(ltrim($body));
			foreach (array('<!doctype html', '<html', '<head', '<?xml') as $htmlPrefix) {
				if (0 === strpos($bodyHead, $htmlPrefix)) {
					$result['status'] = 'body_is_html';
					$result['blocked'] = true;
					$result['message'] = 'The OAuth discovery endpoint returned HTML instead of JSON.';
					return $result;
				}
			}

			$decoded = json_decode($body, true);
			if (is_array($decoded) && !empty($decoded['authorization_endpoint']) && !empty($decoded['token_endpoint'])) {
				$result['status'] = 'ok';
			} else {
				$result['status'] = 'unexpected';
				$result['message'] = 'Unexpected payload at OAuth metadata endpoint.';
			}
		} elseif (in_array($code, array(403, 404), true)) {
			$result['status'] = 'blocked';
			$result['blocked'] = true;
			$result['message'] = 'Host likely blocks /.well-known/* before WordPress routing.';
		} else {
			$result['status'] = 'error';
			$result['message'] = 'Unexpected HTTP status from oauth-authorization-server endpoint.';
		}

		return $result;
	}

	private function getOAuthWellKnownSelfCheckResult() {
		if ($this->shouldSkipOAuthWellKnownSelfCheck()) {
			return array(
				'status' => 'skipped',
				'blocked' => false,
				'checked_at' => time(),
			);
		}

		$transientKey = $this->getOAuthWellKnownProbeTransientKey();
		$cached = get_transient($transientKey);
		if (is_array($cached) && isset($cached['status'])) {
			return $cached;
		}

		$url = (string) apply_filters(
			'stifli_flex_mcp_oauth_metadata_url',
			home_url('/.well-known/oauth-authorization-server'),
			'oauth-authorization-server'
		);
		$result = array(
			'status' => 'unknown',
			'blocked' => false,
			'checked_at' => time(),
			'url' => $url,
			'code' => 0,
			'message' => '',
		);

		$primaryProbe = $this->probeOAuthMetadataEndpoint($url);
		$result['status'] = isset($primaryProbe['status']) ? (string) $primaryProbe['status'] : 'unknown';
		$result['blocked'] = !empty($primaryProbe['blocked']);
		$result['code'] = isset($primaryProbe['code']) ? (int) $primaryProbe['code'] : 0;
		$result['message'] = isset($primaryProbe['message']) ? (string) $primaryProbe['message'] : '';
		$result['provider'] = isset($primaryProbe['provider']) ? (string) $primaryProbe['provider'] : '';

		if ('ok' !== $result['status']) {
			$openidUrl = (string) apply_filters(
				'stifli_flex_mcp_oauth_metadata_url',
				home_url('/.well-known/openid-configuration'),
				'openid-configuration'
			);
			$openidProbe = $this->probeOAuthMetadataEndpoint($openidUrl);
			if (isset($openidProbe['status']) && 'ok' === (string) $openidProbe['status']) {
				$result['status'] = 'ok';
				$result['blocked'] = false;
				$result['url'] = $openidUrl;
				$result['code'] = isset($openidProbe['code']) ? (int) $openidProbe['code'] : 200;
				$result['message'] = '';
				$result['provider'] = '';
			} elseif (empty($result['provider']) && !empty($openidProbe['provider'])) {
				$result['provider'] = (string) $openidProbe['provider'];
			}
		}

		if ('ok' === $result['status']) {
			$registerUrl = rest_url($this->namespace . '/oauth/register');
			$registerResponse = wp_remote_post($registerUrl, array(
				'timeout' => 8,
				'redirection' => 0,
				'headers' => array(
					'Content-Type' => 'application/json',
					'X-Stifli-Flex-MCP-Self-Check' => '1',
				),
				'body' => '{}',
			));

			if (!is_wp_error($registerResponse)) {
				$registerCode = (int) wp_remote_retrieve_response_code($registerResponse);
				$location = (string) wp_remote_retrieve_header($registerResponse, 'location');
				$registerPath = (string) wp_parse_url($registerUrl, PHP_URL_PATH);
				$locationPath = '' !== $location ? (string) wp_parse_url($location, PHP_URL_PATH) : '';
				if (in_array($registerCode, array(301, 302, 307, 308), true) && '' !== $locationPath && untrailingslashit($locationPath) === untrailingslashit($registerPath) && $locationPath !== $registerPath) {
					$result['status'] = 'register_redirect';
					$result['blocked'] = true;
					$result['url'] = $registerUrl;
					$result['code'] = $registerCode;
					$result['location'] = $location;
					$result['message'] = 'The OAuth registration endpoint redirects POST requests to a trailing-slash URL.';
				}
			}
		}

		$probeTtl = !empty($result['blocked']) ? 10 * MINUTE_IN_SECONDS : (int) $this->oauthWellKnownProbeTtl;
		set_transient($transientKey, $result, $probeTtl);
		return $result;
	}

	public function handleOAuthWellKnownRecheck() {
		if (!current_user_can('manage_options')) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce verified below.
		$recheck = isset($_GET['sflmcp_recheck_oauth_well_known']) ? sanitize_text_field(wp_unslash($_GET['sflmcp_recheck_oauth_well_known'])) : '';
		if ('1' !== $recheck) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce is explicitly validated.
		$nonce = isset($_GET['_sflmcpnonce']) ? sanitize_text_field(wp_unslash($_GET['_sflmcpnonce'])) : '';
		if (!wp_verify_nonce($nonce, 'sflmcp_recheck_oauth_well_known')) {
			return;
		}

		$this->invalidateOAuthWellKnownProbeCache();
		$redirect = remove_query_arg(array('sflmcp_recheck_oauth_well_known', '_sflmcpnonce'));
		wp_safe_redirect($redirect);
		exit;
	}

	public function handleOAuthWellKnownNoticeDismiss() {
		if (!current_user_can('manage_options')) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce verified below.
		$dismiss = isset($_GET['sflmcp_dismiss_oauth_well_known_notice']) ? sanitize_text_field(wp_unslash($_GET['sflmcp_dismiss_oauth_well_known_notice'])) : '';
		if ('1' !== $dismiss) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce is explicitly validated.
		$nonce = isset($_GET['_sflmcpnonce']) ? sanitize_text_field(wp_unslash($_GET['_sflmcpnonce'])) : '';
		if (!wp_verify_nonce($nonce, 'sflmcp_dismiss_oauth_well_known_notice')) {
			return;
		}

		update_option($this->getOAuthWellKnownDismissOptionKey(), time(), false);
		$redirect = remove_query_arg(array('sflmcp_dismiss_oauth_well_known_notice', '_sflmcpnonce'));
		wp_safe_redirect($redirect);
		exit;
	}

	public function renderOAuthWellKnownNotice() {
		if (!current_user_can('manage_options')) {
			return;
		}

		if (!function_exists('get_current_screen')) {
			return;
		}

		$screen = get_current_screen();
		if (!$screen || empty($screen->id)) {
			return;
		}

		$allowedScreens = array('flex-mcp_page_sflmcp-server', 'stifli-flex-mcp_page_sflmcp-server');
		$page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- admin page routing only.
		$is_mcp_server_screen = in_array((string) $screen->id, $allowedScreens, true) || 'sflmcp-server' === $page;
		if ('plugins' !== (string) $screen->id && ! $is_mcp_server_screen) {
			return;
		}
		$helpUrl = admin_url('admin.php?page=sflmcp-server&tab=help#troubleshooting');

		// Warn when Plain permalinks are enabled because OAuth discovery/connectors can fail under restrictive hosts.
		$permalink_structure = (string) get_option('permalink_structure', '');
		if ('' === $permalink_structure) {
			$permalinksUrl = admin_url('options-permalink.php');
			?>
			<div class="notice notice-warning">
				<p><strong><?php echo esc_html__('Plain permalinks detected.', 'stifli-flex-mcp'); ?></strong></p>
				<p>
					<?php echo esc_html__('OAuth and MCP connectors are more reliable with a non-Plain permalink structure. Switch to Post name or another pretty permalink option, then save changes.', 'stifli-flex-mcp'); ?>
				</p>
				<p>
					<a class="button button-secondary" href="<?php echo esc_url($permalinksUrl); ?>"><?php echo esc_html__('Open Permalink Settings', 'stifli-flex-mcp'); ?></a>
					<a class="button button-link" href="<?php echo esc_url($helpUrl); ?>"><?php echo esc_html__('Troubleshooting guide', 'stifli-flex-mcp'); ?></a>
				</p>
			</div>
			<?php
		}

		// Warn if stale static .well-known files shadow dynamic OAuth metadata.
		$normalizeEndpoint = static function($url) {
			$url = is_string($url) ? trim($url) : '';
			if ('' === $url) {
				return '';
			}
			$parts = wp_parse_url($url);
			if (!is_array($parts)) {
				return $url;
			}
			$host = isset($parts['host']) ? strtolower((string) $parts['host']) : '';
			$path = isset($parts['path']) ? untrailingslashit((string) $parts['path']) : '';
			$query = '';
			if (!empty($parts['query'])) {
				parse_str((string) $parts['query'], $queryParts);
				if (is_array($queryParts)) {
					ksort($queryParts);
					$query = http_build_query($queryParts);
				}
			}
			return $host . '|' . $path . '|' . $query;
		};

		$expectedEndpoints = array(
			'authorization_endpoint' => home_url('?sflmcp_oauth=authorize'),
			'token_endpoint' => rest_url($this->namespace . '/oauth/token'),
			'registration_endpoint' => rest_url($this->namespace . '/oauth/register'),
		);
		$staticFiles = array(
			trailingslashit(ABSPATH) . '.well-known/oauth-authorization-server',
			trailingslashit(ABSPATH) . '.well-known/oauth-authorization-server.json',
			trailingslashit(ABSPATH) . '.well-known/openid-configuration',
			trailingslashit(ABSPATH) . '.well-known/openid-configuration.json',
		);
		$staleStaticFiles = array();

		foreach ($staticFiles as $filePath) {
			if (!is_string($filePath) || '' === $filePath || !file_exists($filePath) || !is_readable($filePath)) {
				continue;
			}

			// Read only first chunk to avoid large-file overhead.
			$raw = @file_get_contents($filePath, false, null, 0, 262144); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents,WordPress.PHP.NoSilencedErrors.Discouraged
			if (false === $raw || '' === $raw) {
				continue;
			}

			$reason = '';
			$decoded = json_decode($raw, true);
			if (is_array($decoded)) {
				foreach ($expectedEndpoints as $key => $expectedUrl) {
					if (!isset($decoded[$key]) || !is_string($decoded[$key]) || '' === $decoded[$key]) {
						continue;
					}
					if ($normalizeEndpoint($decoded[$key]) !== $normalizeEndpoint($expectedUrl)) {
						$reason = sprintf(
							'Mismatch on %s: found %s',
							$key,
							$decoded[$key]
						);
						break;
					}
				}
			}

			if ('' === $reason) {
				$rawLower = strtolower($raw);
				if (false !== strpos($rawLower, '/wp-json/') && false !== strpos($rawLower, 'oauth') && (false !== strpos($rawLower, 'authorize') || false !== strpos($rawLower, 'token') || false !== strpos($rawLower, 'register'))) {
					$reason = 'Contains legacy REST OAuth endpoint paths.';
				}
			}

			if ('' !== $reason) {
				$staleStaticFiles[] = array(
					'path' => $filePath,
					'reason' => $reason,
				);
			}
		}

		if (!empty($staleStaticFiles)) {
			?>
			<div class="notice notice-warning">
				<p><strong><?php echo esc_html__('Stale static OAuth metadata file detected.', 'stifli-flex-mcp'); ?></strong></p>
				<p><?php echo esc_html__('A static .well-known file may be overriding dynamic OAuth metadata and breaking connector discovery. Remove or update these files:', 'stifli-flex-mcp'); ?></p>
				<ul>
					<?php foreach ($staleStaticFiles as $item) : ?>
						<li><code><?php echo esc_html((string) $item['path']); ?></code> — <?php echo esc_html((string) $item['reason']); ?></li>
					<?php endforeach; ?>
				</ul>
				<p>
					<a class="button button-secondary" href="<?php echo esc_url($helpUrl); ?>"><?php echo esc_html__('View manual fix', 'stifli-flex-mcp'); ?></a>
				</p>
			</div>
			<?php
		}

		$check = $this->getOAuthWellKnownSelfCheckResult();
		if (empty($check['blocked'])) {
			return;
		}

		$dismissedAt = (int) get_option($this->getOAuthWellKnownDismissOptionKey(), 0);
		$checkedAt = isset($check['checked_at']) ? (int) $check['checked_at'] : 0;
		if ($dismissedAt > 0 && $dismissedAt >= $checkedAt) {
			return;
		}

		$dismissUrl = wp_nonce_url(
			add_query_arg(array('sflmcp_dismiss_oauth_well_known_notice' => '1')),
			'sflmcp_dismiss_oauth_well_known_notice',
			'_sflmcpnonce'
		);
		$recheckUrl = wp_nonce_url(
			add_query_arg(array('sflmcp_recheck_oauth_well_known' => '1')),
			'sflmcp_recheck_oauth_well_known',
			'_sflmcpnonce'
		);
		$endpoint = isset($check['url']) ? (string) $check['url'] : home_url('/.well-known/oauth-authorization-server');
		$code = isset($check['code']) ? (int) $check['code'] : 0;
		$status = isset($check['status']) ? (string) $check['status'] : '';
		$provider = isset($check['provider']) ? (string) $check['provider'] : '';
		$title = __('OAuth discovery endpoint may be blocked by hosting.', 'stifli-flex-mcp');
		$description = __('External MCP connectors (Claude/ChatGPT) may fail to open the authorization window if this endpoint is unreachable:', 'stifli-flex-mcp');
		$providerHelpUrl = '';
		if ('sucuri' === $provider) {
			$title = __('Sucuri or CloudProxy is blocking OAuth discovery.', 'stifli-flex-mcp');
			$description = __('Allow the OAuth discovery and registration paths in Sucuri Website Firewall, then re-check the connection:', 'stifli-flex-mcp');
			$providerHelpUrl = 'https://docs.sucuri.net/website-firewall/troubleshooting/whitelist-and-blacklist/';
		} elseif ('body_is_html' === $status) {
			$title = __('OAuth discovery endpoint is returning HTML instead of JSON.', 'stifli-flex-mcp');
			$description = __('A membership plugin, theme, firewall, or host rule may be intercepting this endpoint before the OAuth metadata reaches the client:', 'stifli-flex-mcp');
		} elseif ('register_redirect' === $status) {
			$title = __('OAuth registration endpoint redirects POST requests.', 'stifli-flex-mcp');
			$description = __('Dynamic client registration may fail because this POST endpoint is redirected, usually to a trailing-slash URL:', 'stifli-flex-mcp');
		}
		?>
		<div class="notice notice-warning is-dismissible">
			<p><strong><?php echo esc_html($title); ?></strong></p>
			<p>
				<?php echo esc_html($description); ?>
				<code><?php echo esc_html($endpoint); ?></code>
				<?php if ($code > 0) : ?>
					(HTTP <?php echo esc_html((string) $code); ?>)
				<?php endif; ?>
			</p>
			<p>
				<a class="button button-primary" href="<?php echo esc_url($recheckUrl); ?>"><?php echo esc_html__('Re-check now', 'stifli-flex-mcp'); ?></a>
				<a class="button button-secondary" href="<?php echo esc_url($helpUrl); ?>"><?php echo esc_html__('View manual fix', 'stifli-flex-mcp'); ?></a>
				<?php if ('' !== $providerHelpUrl) : ?>
					<a class="button button-secondary" href="<?php echo esc_url($providerHelpUrl); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('Sucuri fix guide', 'stifli-flex-mcp'); ?></a>
				<?php endif; ?>
				<a class="button button-link" href="<?php echo esc_url($dismissUrl); ?>"><?php echo esc_html__('Dismiss', 'stifli-flex-mcp'); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Show a promotional banner for WP MCP Hub across Flex MCP admin pages.
	 */
	public function renderWpMcpHubPromoNotice() {
		if (!current_user_can('manage_options')) {
			return;
		}

		if (!$this->isStifliFlexMcpAdminPage()) {
			return;
		}

		if ($this->isWpMcpHubPromoNoticeDismissed()) {
			return;
		}

		$siteUrl = 'https://andromedanova.com/wp-mcp-hub.html';
		$repoUrl = 'https://github.com/estebanstifli/wp-mcp-hub';
		$dismissUrl = wp_nonce_url(
			add_query_arg(array('sflmcp_dismiss_wp_mcp_hub_promo' => '1')),
			'sflmcp_dismiss_wp_mcp_hub_promo',
			'_sflmcpnonce'
		);
		?>
		<div class="notice notice-info" style="border-left-color:#0b7a75; padding:14px 16px;">
			<p style="margin:0 0 8px 0;"><strong><?php echo esc_html__('If you are an agency or manage many WordPress installations, use one central point to manage them all.', 'stifli-flex-mcp'); ?></strong></p>
			<p style="margin:0 0 10px 0;">
				<?php echo esc_html__('WP MCP Hub provides that local central layer for connecting and managing multiple WordPress MCP servers. It is free and open source.', 'stifli-flex-mcp'); ?>
			</p>
			<p style="margin:0;">
				<a class="button button-primary" href="<?php echo esc_url($siteUrl); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('View WP MCP Hub', 'stifli-flex-mcp'); ?></a>
				<a class="button button-secondary" href="<?php echo esc_url($repoUrl); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('View on GitHub', 'stifli-flex-mcp'); ?></a>
				<a class="button button-link" href="<?php echo esc_url($dismissUrl); ?>"><?php echo esc_html__('Dismiss', 'stifli-flex-mcp'); ?></a>
			</p>
		</div>
		<?php
	}

	/**
	 * Handle persistent dismissal of WP MCP Hub promo notice per user.
	 */
	public function handleWpMcpHubPromoNoticeDismiss() {
		if (!current_user_can('manage_options')) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce verified below.
		$dismiss = isset($_GET['sflmcp_dismiss_wp_mcp_hub_promo']) ? sanitize_text_field(wp_unslash($_GET['sflmcp_dismiss_wp_mcp_hub_promo'])) : '';
		if ('1' !== $dismiss) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- nonce is explicitly validated.
		$nonce = isset($_GET['_sflmcpnonce']) ? sanitize_text_field(wp_unslash($_GET['_sflmcpnonce'])) : '';
		if (!wp_verify_nonce($nonce, 'sflmcp_dismiss_wp_mcp_hub_promo')) {
			return;
		}

		$userId = get_current_user_id();
		if ($userId > 0) {
			update_user_meta($userId, $this->getWpMcpHubPromoDismissUserMetaKey(), time());
		}

		$redirect = remove_query_arg(array('sflmcp_dismiss_wp_mcp_hub_promo', '_sflmcpnonce'));
		wp_safe_redirect($redirect);
		exit;
	}

	/**
	 * Render a non-dismissible footer promo on plugin admin pages.
	 */
	public function renderWpMcpHubPromoFooter() {
		if (!current_user_can('manage_options')) {
			return;
		}

		if (!$this->isStifliFlexMcpAdminPage()) {
			return;
		}

		$siteUrl = 'https://andromedanova.com/wp-mcp-hub.html';
		$repoUrl = 'https://github.com/estebanstifli/wp-mcp-hub';
		?>
		<div style="display:flex; flex-wrap:wrap; align-items:center; justify-content:center; gap:8px 14px; margin:16px 0 8px; padding:12px 16px; border:1px solid #72aee6; border-left:4px solid #2271b1; background:#f0f6fc; color:#1d2327; font-size:13px; line-height:1.5; text-align:center;">
			<span><strong><?php echo esc_html__('WP MCP Hub', 'stifli-flex-mcp'); ?></strong><?php echo esc_html__(' - One local central point for agencies and teams that manage many WordPress installations. Free and open source.', 'stifli-flex-mcp'); ?></span>
			<span style="display:inline-flex; gap:8px; white-space:nowrap;">
				<a class="button button-small" href="<?php echo esc_url($siteUrl); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('Info', 'stifli-flex-mcp'); ?></a>
				<a class="button button-small" href="<?php echo esc_url($repoUrl); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__('GitHub', 'stifli-flex-mcp'); ?></a>
			</span>
		</div>
		<?php
	}

	/**
	 * Check whether current user dismissed the WP MCP Hub promo notice.
	 *
	 * @return bool
	 */
	private function isWpMcpHubPromoNoticeDismissed() {
		$userId = get_current_user_id();
		if ($userId <= 0) {
			return false;
		}

		$dismissedAt = (int) get_user_meta($userId, $this->getWpMcpHubPromoDismissUserMetaKey(), true);
		return $dismissedAt > 0;
	}

	/**
	 * User meta key for WP MCP Hub promo dismissal.
	 *
	 * @return string
	 */
	private function getWpMcpHubPromoDismissUserMetaKey() {
		return 'sflmcp_wp_mcp_hub_promo_dismissed';
	}

	/**
	 * Detect whether the current admin page belongs to Flex MCP.
	 *
	 * @return bool
	 */
	private function isStifliFlexMcpAdminPage() {
		if (!is_admin()) {
			return false;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only screen detection.
		$page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
		if ('stifli-flex-mcp' === $page) {
			return true;
		}

		return 0 === strpos($page, 'sflmcp-');
	}

	public function handleDownloadMcpbBundle() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'stifli-flex-mcp' ) );
		}

		check_admin_referer( 'sflmcp_download_mcpb_bundle' );

		$server_key = sanitize_title( get_bloginfo( 'name' ) );
		if ( '' === $server_key ) {
			$server_key = 'stifli-flex-mcp';
		}

		$bundle = array(
			'version' => '1.0',
			'generated_at' => gmdate( 'c' ),
			'mcpServers' => array(
				$server_key => array(
					'type' => 'sse',
					'url' => rest_url( $this->namespace . '/sse' ),
				),
			),
		);

		$host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		$host = '' !== $host ? sanitize_title( $host ) : 'site';
		$filename = 'stifli-flex-mcp-' . $host . '.mcpb';

		nocache_headers();
		header( 'Content-Type: application/octet-stream; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=' . $filename );
		header( 'X-Content-Type-Options: nosniff' );

		echo wp_json_encode( $bundle, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		exit;
	}

	/**
	 * Enqueue admin scripts and styles
	 */
	public function enqueueAdminScripts($hook) {
		$asset_version = defined( 'SFLMCP_VERSION' ) ? SFLMCP_VERSION : '3.5.4';

		// Load Multimedia page assets on its own page
		$page = isset($_GET['page']) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- admin page routing only.
		$multimedia_hooks = array('flex-mcp_page_sflmcp-multimedia', 'stifli-flex-mcp_page_sflmcp-multimedia');
		if (in_array($hook, $multimedia_hooks, true) || 'sflmcp-multimedia' === $page) {
			$this->enqueueMultimediaAssets();
			return;
		}

		$is_top_level_fallback = 'toplevel_page_stifli-flex-mcp' === $hook && ! stifli_flex_mcp_addon_enabled( 'ai_chat' );
		$is_mcp_server_page = 'sflmcp-server' === $page || ( 'stifli-flex-mcp' === $page && ! stifli_flex_mcp_addon_enabled( 'ai_chat' ) );
		$mcp_server_hooks = array('flex-mcp_page_sflmcp-server', 'stifli-flex-mcp_page_sflmcp-server');
		if (!in_array($hook, $mcp_server_hooks, true) && ! $is_top_level_fallback && ! $is_mcp_server_page) {
			return;
		}

		// Get active tab early for conditional loading
		$active_tab = isset($_GET['tab']) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : 'settings'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( 'oauth' === $active_tab ) {
			$active_tab = 'settings';
		}

		// Enqueue Settings tab JavaScript
		wp_enqueue_script(
			'sflmcp-admin-settings',
			plugin_dir_url(__FILE__) . 'assets/admin-settings.js',
			array(),
			$asset_version,
			true
		);

		// Localize script with data
		wp_localize_script('sflmcp-admin-settings', 'sflmcpSettings', array(
			'ajaxUrl' => admin_url('admin-ajax.php'),
			'nonce' => wp_create_nonce('SFLMCP-admin'),
			'i18n' => array(
				'urlCopied' => __('URL copied', 'stifli-flex-mcp'),
				'headerCopied' => __('Header copied', 'stifli-flex-mcp'),
				'appPasswordGenerating' => __('Generating...', 'stifli-flex-mcp'),
				'appPasswordGenerateError' => __('Could not generate Application Password. Please try again.', 'stifli-flex-mcp'),
			),
		));

		// Enqueue Profiles tab JavaScript
		wp_enqueue_script(
			'sflmcp-admin-profiles',
			plugin_dir_url(__FILE__) . 'assets/admin-profiles.js',
			array(),
			$asset_version,
			true
		);

		// Localize script with data
		wp_localize_script('sflmcp-admin-profiles', 'sflmcpProfiles', array(
			'nonce' => wp_create_nonce('sflmcp_profiles'),
			'i18n' => array(
				'includedTools' => __('Included tools:', 'stifli-flex-mcp'),
			),
		));

		// Enqueue main admin styles (tools, help page)
		wp_enqueue_style(
			'sflmcp-admin-styles',
			plugin_dir_url(__FILE__) . 'assets/admin-styles.css',
			array(),
			$asset_version
		);

		// Enqueue Custom Tools assets for legacy tab.
		if ($active_tab === 'custom') {
			$this->enqueueCustomToolsAssets();
		}

		// Enqueue Abilities tab assets (WordPress 6.9+)
		if ($active_tab === 'abilities' && stifli_flex_mcp_abilities_available()) {
			wp_enqueue_style(
				'sflmcp-admin-abilities',
				plugin_dir_url(__FILE__) . 'assets/admin-abilities.css',
				array(),
				$asset_version
			);
			wp_enqueue_script(
				'sflmcp-admin-abilities',
				plugin_dir_url(__FILE__) . 'assets/admin-abilities.js',
				array('jquery'),
				$asset_version,
				true
			);
			wp_localize_script('sflmcp-admin-abilities', 'sflmcpAbilities', array(
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'nonce' => wp_create_nonce('sflmcp_abilities'),
				'i18n' => array(
					'discovering' => __('Discovering abilities...', 'stifli-flex-mcp'),
					'discoverButton' => __('Discover Abilities', 'stifli-flex-mcp'),
					'noAbilities' => __('No abilities found. Install plugins that register WordPress Abilities.', 'stifli-flex-mcp'),
					'confirmDelete' => __('Are you sure you want to remove this ability?', 'stifli-flex-mcp'),
					'confirmBulkRemove' => __('Remove the selected imported abilities?', 'stifli-flex-mcp'),
					'confirmBulkImport' => __('Import the selected discovered abilities?', 'stifli-flex-mcp'),
					'imported' => __('Ability imported successfully', 'stifli-flex-mcp'),
					'deleted' => __('Ability removed', 'stifli-flex-mcp'),
					'error' => __('An error occurred', 'stifli-flex-mcp'),
					'chooseBulkAction' => __('Select a bulk action first.', 'stifli-flex-mcp'),
					'noSelection' => __('Select at least one ability.', 'stifli-flex-mcp'),
					'applying' => __('Applying...', 'stifli-flex-mcp'),
					'alreadyImported' => __('Already imported', 'stifli-flex-mcp'),
					'import' => __('Import', 'stifli-flex-mcp'),
					'importing' => __('Importing...', 'stifli-flex-mcp'),
					'enabledLabel' => __('Enabled', 'stifli-flex-mcp'),
					'disabledLabel' => __('Disabled', 'stifli-flex-mcp'),
					'selectedSuffix' => __('selected', 'stifli-flex-mcp'),
					'importedSuffix' => __('imported', 'stifli-flex-mcp'),
					'visibleSuffix' => __('visible', 'stifli-flex-mcp'),
					'allCategories' => __('All categories', 'stifli-flex-mcp'),
					'selectAllVisible' => __('Select all visible', 'stifli-flex-mcp'),
					'clearSelection' => __('Clear selection', 'stifli-flex-mcp'),
					'importSelected' => __('Import selected', 'stifli-flex-mcp'),
					'importVisible' => __('Import visible', 'stifli-flex-mcp'),
				),
			));
		}

		// Enqueue OAuth assets on Settings tab
		if ($active_tab === 'settings') {
			wp_enqueue_style(
				'sflmcp-admin-oauth',
				plugin_dir_url(__FILE__) . 'assets/admin-oauth.css',
				array('sflmcp-admin-styles'),
				$asset_version
			);
			wp_enqueue_script(
				'sflmcp-admin-oauth',
				plugin_dir_url(__FILE__) . 'assets/admin-oauth.js',
				array('jquery'),
				$asset_version,
				true
			);
			wp_localize_script('sflmcp-admin-oauth', 'sflmcpOAuth', array(
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'nonce' => wp_create_nonce('sflmcp_oauth'),
				'i18n' => array(
					'confirmDeleteClient' => __('Are you sure you want to delete this OAuth client and revoke all its tokens?', 'stifli-flex-mcp'),
					'confirmRevokeToken' => __('Revoke this token? The client will need to re-authorize.', 'stifli-flex-mcp'),
					'confirmResetState' => __('Revoke all OAuth access tokens, refresh tokens, and pending authorization codes? Registered clients will be kept so MCP apps can reconnect with the same client ID.', 'stifli-flex-mcp'),
					'clientDeleted' => __('OAuth client deleted', 'stifli-flex-mcp'),
					'tokenRevoked' => __('Token revoked', 'stifli-flex-mcp'),
					'resetStateSuccess' => __('OAuth sessions reset. Reloading...', 'stifli-flex-mcp'),
					'settingsSaved' => __('Settings saved', 'stifli-flex-mcp'),
					'error' => __('An error occurred', 'stifli-flex-mcp'),
				),
			));
		}

		// Enqueue Tools tab JavaScript (WordPress and WooCommerce tools)
		if ($active_tab === 'tools' || $active_tab === 'wc_tools') {
			wp_enqueue_script(
				'sflmcp-admin-tools',
				plugin_dir_url(__FILE__) . 'assets/admin-tools.js',
				array('jquery'),
				$asset_version,
				true
			);
			wp_localize_script('sflmcp-admin-tools', 'sflmcpTools', array(
				'ajaxUrl' => admin_url('admin-ajax.php'),
				'nonce' => wp_create_nonce('sflmcp_tools'),
				'i18n' => array(
					'enabled' => __('Enabled', 'stifli-flex-mcp'),
					'disabled' => __('Disabled', 'stifli-flex-mcp'),
					'error' => __('Error updating tool', 'stifli-flex-mcp'),
				),
			));
		}

		// Extension point for modular admin tabs.
		do_action('sflmcp_admin_enqueue_tab_assets', $active_tab, $hook, $this);
	}

	/**
	 * Ensure shared styles are present for modular tool-management tabs.
	 */
	public function enqueueCustomToolsAssets() {
		wp_enqueue_style(
			'sflmcp-admin-styles',
			plugin_dir_url(__FILE__) . 'assets/admin-styles.css',
			array(),
			defined( 'SFLMCP_VERSION' ) ? SFLMCP_VERSION : '3.5.4'
		);
	}

	/**
	 * Render the admin settings page
	 */
	public function adminPage() {
		if (!current_user_can('manage_options')) {
			wp_die( esc_html__('You do not have permission to view this page.','stifli-flex-mcp') );
		}
		
		// Get active tab
		$active_tab = isset($_GET['tab']) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : 'settings'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- tab selection is a read-only navigation parameter
		if ( 'oauth' === $active_tab ) {
			$active_tab = 'settings';
		}
		
		$tabs = array(
			'settings' => __('Settings', 'stifli-flex-mcp'),
			'addons' => __('Add-ons', 'stifli-flex-mcp'),
			'profiles' => __('Profiles', 'stifli-flex-mcp'),
			'tools' => __('WordPress Tools', 'stifli-flex-mcp'),
			'wc_tools' => __('WooCommerce Tools', 'stifli-flex-mcp'),
		);
		if ( stifli_flex_mcp_abilities_available() ) {
			$tabs['abilities'] = __('Abilities', 'stifli-flex-mcp');
		}
		$tabs['help'] = __('📚 Help', 'stifli-flex-mcp');
		$tabs = apply_filters('sflmcp_admin_tabs', $tabs, $active_tab, $this);

		?>
		<div class="wrap">
			<h1><?php echo esc_html__('MCP Server', 'stifli-flex-mcp'); ?></h1>
			
			<h2 class="nav-tab-wrapper">
				<?php foreach ($tabs as $tab_slug => $tab_label) : ?>
					<a href="<?php echo esc_url(add_query_arg(array('page' => 'sflmcp-server', 'tab' => $tab_slug), admin_url('admin.php'))); ?>" class="nav-tab <?php echo $active_tab === $tab_slug ? 'nav-tab-active' : ''; ?>">
						<?php echo esc_html($tab_label); ?>
					</a>
				<?php endforeach; ?>
			</h2>
			
			<?php
			$handled = false;
			if ($active_tab === 'settings') {
				$this->renderSettingsTab();
				$handled = true;
			} elseif ($active_tab === 'addons') {
				$this->renderAddonsTab();
				$handled = true;
			} elseif ($active_tab === 'profiles') {
				$this->renderProfilesTab();
				$handled = true;
			} elseif ($active_tab === 'tools') {
				$this->renderToolsTab();
				$handled = true;
			} elseif ($active_tab === 'wc_tools') {
				$this->renderWCToolsTab();
				$handled = true;
			} elseif ($active_tab === 'abilities' && stifli_flex_mcp_abilities_available()) {
				$this->renderAbilitiesTab();
				$handled = true;
			} elseif ($active_tab === 'custom' && (bool) apply_filters('sflmcp_enable_legacy_custom_tab', false, $this)) {
				$this->renderCustomToolsTab();
				$handled = true;
			} elseif ($active_tab === 'help') {
				$this->renderHelpTab();
				$handled = true;
			}

			if (!$handled) {
				$external_renderers = apply_filters('sflmcp_admin_tab_renderers', array(), $this);
				if (isset($external_renderers[$active_tab]) && is_callable($external_renderers[$active_tab])) {
					call_user_func($external_renderers[$active_tab], $active_tab, $this);
					$handled = true;
				}
			}

			if (!$handled) {
				$this->renderSettingsTab();
			}
			?>
		</div>
		<?php
	}

	/**
	 * Render optional product layers managed by the core addon registry.
	 */
	private function renderAddonsTab() {
		if ( isset( $_GET['addons-updated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Add-ons updated. The new selection is active.', 'stifli-flex-mcp' ) . '</p></div>';
		}
		?>
		<h2><?php esc_html_e( 'Add-ons', 'stifli-flex-mcp' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Disabled addons do not load their PHP classes, admin hooks, menus, or background jobs.', 'stifli-flex-mcp' ); ?></p>
		<?php StifliFlexMcp_Addons::render_selector( false ); ?>
		<?php
	}
	
	private function renderSettingsTab() {
		$sse_url = rest_url( $this->namespace . '/sse' );

		if ( ! class_exists( 'StifliFlexMcp_OAuth_Storage' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'OAuth module is not loaded.', 'stifli-flex-mcp' ) . '</p></div>';
			return;
		}

		$storage       = StifliFlexMcp_OAuth_Storage::get_instance();
		$clients       = $storage->get_all_clients();

		// Preload token data.
		global $wpdb;
		$tokens_table = $wpdb->prefix . 'sflmcp_oauth_tokens';
		$now          = gmdate( 'Y-m-d H:i:s' );

		$token_counts = array();
		$token_data   = array();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$counts_raw = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT client_id, COUNT(*) as cnt FROM {$tokens_table} WHERE revoked = 0 AND access_expires_at > %s GROUP BY client_id",
				$now
			)
		);
		foreach ( $counts_raw as $row ) {
			$token_counts[ $row->client_id ] = (int) $row->cnt;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$tokens_raw = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT t.id, t.client_id, t.user_id, t.scope, t.access_expires_at, t.created_at, u.display_name as user_name
				FROM {$tokens_table} t
				LEFT JOIN {$wpdb->users} u ON t.user_id = u.ID
				WHERE t.revoked = 0 AND t.access_expires_at > %s
				ORDER BY t.created_at DESC",
				$now
			)
		);
		foreach ( $tokens_raw as $tok ) {
			$token_data[ $tok->client_id ][] = $tok;
		}
		?>

		<div class="sflmcp-settings-connect">
			<h2><?php esc_html_e( 'Connect your AI assistant', 'stifli-flex-mcp' ); ?></h2>
			<p><?php esc_html_e( 'Copy this URL and paste it in your AI client (Claude, ChatGPT, or any MCP-compatible app):', 'stifli-flex-mcp' ); ?></p>

			<div class="sflmcp-settings-url-box">
				<code id="sflmcp_sse_url" class="sflmcp-settings-endpoint-code"><?php echo esc_html( $sse_url ); ?></code>
				<button type="button" class="button button-primary sflmcp-copy-btn" data-copy-target="#sflmcp_sse_url" data-copy-notice="<?php echo esc_attr__( 'URL copied!', 'stifli-flex-mcp' ); ?>">
					<?php esc_html_e( 'Copy', 'stifli-flex-mcp' ); ?>
				</button>
			</div>

			<div class="sflmcp-settings-steps">
				<div class="sflmcp-settings-step">
					<span class="sflmcp-step-number">1</span>
					<div>
						<strong><?php esc_html_e( 'Copy the URL above', 'stifli-flex-mcp' ); ?></strong>
					</div>
				</div>
				<div class="sflmcp-settings-step">
					<span class="sflmcp-step-number">2</span>
					<div>
						<strong><?php esc_html_e( 'Paste it in your AI client', 'stifli-flex-mcp' ); ?></strong>
						<p class="description sflmcp-mb-4"><strong>Claude Desktop:</strong> <?php esc_html_e( 'Customize → Connectors → Add custom connector.', 'stifli-flex-mcp' ); ?></p>
						<p class="description"><strong>ChatGPT:</strong> <?php esc_html_e( 'Settings → Apps & Connectors → Advanced settings → Enable Developer mode → Create app → Paste the URL → Choose OAuth.', 'stifli-flex-mcp' ); ?></p>
					</div>
				</div>
				<div class="sflmcp-settings-step">
					<span class="sflmcp-step-number">3</span>
					<div>
						<strong><?php esc_html_e( 'Authorize when prompted', 'stifli-flex-mcp' ); ?></strong>
						<p class="description"><?php esc_html_e( 'A browser window will open. Log in to WordPress and click "Authorize". You only need to do this once.', 'stifli-flex-mcp' ); ?></p>
					</div>
				</div>
			</div>

			<?php if ( ! empty( $clients ) ) : ?>
			<div class="sflmcp-settings-status">
				<span class="dashicons dashicons-yes-alt sflmcp-color-success"></span>
				<?php
				$client_count = count( $clients );
				$total_tokens = array_sum( $token_counts );
				printf(
					/* translators: %1$d: number of connected clients, %2$d: number of active sessions */
					esc_html( _n(
						'%1$d client connected, %2$d active session.',
						'%1$d clients connected, %2$d active sessions.',
						$client_count,
						'stifli-flex-mcp'
					) ),
					intval( $client_count ),
					intval( $total_tokens )
				);
				?>
			</div>
			<?php endif; ?>
		</div>

		<!-- View More Details -->
		<div class="sflmcp-settings-details-toggle">
			<button type="button" class="button" id="sflmcp-toggle-details">
				<span class="dashicons dashicons-arrow-down-alt2 sflmcp-align-middle"></span>
				<?php esc_html_e( 'View More Details', 'stifli-flex-mcp' ); ?>
			</button>
		</div>

		<div id="sflmcp-settings-details" class="sflmcp-hidden">

			<!-- Connected Clients -->
			<div class="sflmcp-settings-section">
				<h3><?php esc_html_e( 'Connected Clients', 'stifli-flex-mcp' ); ?></h3>
				<p class="description"><?php esc_html_e( 'If external MCP clients are stuck after a site restore or a broken OAuth handshake, you can revoke every OAuth session and pending authorization code while keeping registered clients available for re-authorization. Use Delete to remove a client registration completely.', 'stifli-flex-mcp' ); ?></p>
				<p><button type="button" class="button button-secondary sflmcp-oauth-reset-state"><?php esc_html_e( 'Reset OAuth Sessions', 'stifli-flex-mcp' ); ?></button></p>
				<?php if ( empty( $clients ) ) : ?>
					<p class="description"><?php esc_html_e( 'No clients connected yet. Follow the steps above to connect your first AI assistant.', 'stifli-flex-mcp' ); ?></p>
				<?php else : ?>
					<table class="wp-list-table widefat fixed striped sflmcp-oauth-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Client Name', 'stifli-flex-mcp' ); ?></th>
								<th><?php esc_html_e( 'Client ID', 'stifli-flex-mcp' ); ?></th>
								<th><?php esc_html_e( 'Active Tokens', 'stifli-flex-mcp' ); ?></th>
								<th><?php esc_html_e( 'Registered', 'stifli-flex-mcp' ); ?></th>
								<th><?php esc_html_e( 'Actions', 'stifli-flex-mcp' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $clients as $client ) :
								$cid         = esc_attr( $client->client_id );
								$count       = isset( $token_counts[ $client->client_id ] ) ? $token_counts[ $client->client_id ] : 0;
								$tokens_list = isset( $token_data[ $client->client_id ] ) ? $token_data[ $client->client_id ] : array();
							?>
								<tr>
									<td><strong><?php echo esc_html( $client->client_name ); ?></strong></td>
									<td><code class="sflmcp-code-xs"><?php echo esc_html( $client->client_id ); ?></code></td>
									<td>
										<?php if ( $count > 0 ) : ?>
											<a href="#" class="sflmcp-oauth-toggle-tokens" data-client-id="<?php echo esc_attr( $cid ); ?>">
												<span class="sflmcp-oauth-token-count has-tokens" data-client-count="<?php echo esc_attr( $cid ); ?>"><?php echo intval( $count ); ?></span>
											</a>
										<?php else : ?>
											<span data-client-count="<?php echo esc_attr( $cid ); ?>">0</span>
										<?php endif; ?>
									</td>
									<td>
										<?php
										$registered = strtotime( $client->created_at );
										echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $registered + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ) );
										?>
									</td>
									<td>
										<button type="button" class="button button-small button-link-delete sflmcp-oauth-delete-client" data-client-id="<?php echo esc_attr( $cid ); ?>">
											<?php esc_html_e( 'Delete', 'stifli-flex-mcp' ); ?>
										</button>
									</td>
								</tr>
								<?php if ( ! empty( $tokens_list ) ) : ?>
								<tr class="sflmcp-oauth-tokens-row">
									<td colspan="5">
										<div id="sflmcp-tokens-<?php echo esc_attr( $cid ); ?>" class="sflmcp-oauth-tokens-detail">
											<table class="sflmcp-oauth-tokens-list">
												<thead>
													<tr>
														<th><?php esc_html_e( 'User', 'stifli-flex-mcp' ); ?></th>
														<th><?php esc_html_e( 'Scope', 'stifli-flex-mcp' ); ?></th>
														<th><?php esc_html_e( 'Issued', 'stifli-flex-mcp' ); ?></th>
														<th><?php esc_html_e( 'Expires', 'stifli-flex-mcp' ); ?></th>
														<th></th>
													</tr>
												</thead>
												<tbody>
													<?php foreach ( $tokens_list as $tok ) :
														$issued  = strtotime( $tok->created_at );
														$expires = strtotime( $tok->access_expires_at );
														$offset  = get_option( 'gmt_offset' ) * HOUR_IN_SECONDS;
													?>
													<tr>
														<td><?php echo esc_html( $tok->user_name ?: '#' . $tok->user_id ); ?></td>
														<td><?php echo esc_html( $tok->scope ); ?></td>
														<td><?php echo esc_html( date_i18n( 'M j, H:i', $issued + $offset ) ); ?></td>
														<td><?php echo esc_html( date_i18n( 'M j, H:i', $expires + $offset ) ); ?></td>
														<td>
															<button type="button" class="button button-small button-link-delete sflmcp-oauth-revoke-token"
																data-token-id="<?php echo intval( $tok->id ); ?>"
																data-client-id="<?php echo esc_attr( $cid ); ?>">
																<?php esc_html_e( 'Revoke', 'stifli-flex-mcp' ); ?>
															</button>
														</td>
													</tr>
													<?php endforeach; ?>
												</tbody>
											</table>
										</div>
									</td>
								</tr>
								<?php endif; ?>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>

			<!-- Troubleshooting -->
			<div class="sflmcp-settings-section">
				<h3><?php esc_html_e( 'Troubleshooting', 'stifli-flex-mcp' ); ?></h3>
				<table class="form-table">
					<tr>
						<th><?php esc_html_e( 'Connection fails', 'stifli-flex-mcp' ); ?></th>
						<td><?php esc_html_e( 'Make sure your site uses HTTPS. Check that no security plugin is blocking the REST API.', 'stifli-flex-mcp' ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Authorization keeps asking', 'stifli-flex-mcp' ); ?></th>
						<td><?php esc_html_e( 'You need to be logged in to WordPress as an administrator when the authorization page opens. Tokens last 24 hours and refresh automatically for up to 90 days.', 'stifli-flex-mcp' ); ?></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Client not appearing', 'stifli-flex-mcp' ); ?></th>
						<td><?php esc_html_e( 'The client registers automatically when it first connects. If nothing shows up, try disconnecting and reconnecting from your AI assistant.', 'stifli-flex-mcp' ); ?></td>
					</tr>
				</table>
			</div>

			<!-- Alternative: Application Passwords -->
			<div class="sflmcp-settings-section">
				<h3><?php esc_html_e( 'Alternative: Application Passwords', 'stifli-flex-mcp' ); ?></h3>
				<p class="description"><?php esc_html_e( 'For advanced setups or clients that do not support OAuth, you can use WordPress Application Passwords with HTTP Basic Auth.', 'stifli-flex-mcp' ); ?></p>

				<div class="sflmcp-mb-4">
					<button type="button" id="sflmcp-generate-app-password-btn" class="button button-secondary"><?php esc_html_e( 'Generate Application Password', 'stifli-flex-mcp' ); ?></button>
					<span id="sflmcp-generate-app-password-status" class="description sflmcp-hidden"><?php esc_html_e( 'Generating...', 'stifli-flex-mcp' ); ?></span>
				</div>

				<p class="description">
					<?php echo wp_kses(
						sprintf(
							/* translators: %s: link to profile page */
							__( 'You can also manage or revoke passwords from %s.', 'stifli-flex-mcp' ),
							'<a href="' . esc_url( get_edit_profile_url( get_current_user_id() ) . '#application-passwords-section' ) . '" target="_blank">'
							. esc_html__( 'your profile', 'stifli-flex-mcp' ) . '</a>'
						),
						array( 'a' => array( 'href' => array(), 'target' => array() ) )
					); ?>
				</p>

				<div id="sflmcp-app-password-feedback" class="sflmcp-hidden"></div>
				<div id="sflmcp-generated-app-password-wrap" class="sflmcp-hidden">
					<p class="description"><strong><?php esc_html_e( 'Username:', 'stifli-flex-mcp' ); ?></strong> <code id="sflmcp-generated-app-password-user"></code></p>
					<p class="description"><strong><?php esc_html_e( 'Application Name:', 'stifli-flex-mcp' ); ?></strong> <code id="sflmcp-generated-app-password-name"></code></p>
					<div class="sflmcp-settings-url-box">
						<code id="sflmcp_generated_app_password" class="sflmcp-settings-endpoint-code"></code>
						<button type="button" class="button button-primary sflmcp-copy-btn" data-copy-target="#sflmcp_generated_app_password" data-copy-notice="<?php echo esc_attr__( 'Application Password copied!', 'stifli-flex-mcp' ); ?>"><?php esc_html_e( 'Copy', 'stifli-flex-mcp' ); ?></button>
					</div>
				</div>
				<?php
				$messages_endpoint = rest_url( $this->namespace . '/messages' );
				$current_user = wp_get_current_user();
				$example_user = ( $current_user && ! empty( $current_user->user_login ) ) ? $current_user->user_login : 'your_wp_username';
				$curl_example = implode(
					"\n",
					array(
						sprintf( 'curl -u "%s:<APP_PASSWORD_WITHOUT_SPACES>" \\', $example_user ),
						'  -H "Content-Type: application/json" \\',
						'  -d \'{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}\' \\',
						sprintf( '  "%s"', $messages_endpoint ),
					)
				);
				?>
				<p class="description"><strong><?php esc_html_e( 'Note:', 'stifli-flex-mcp' ); ?></strong> <?php esc_html_e( 'This method uses HTTP Basic Auth (not Bearer token). If WordPress shows spaces in the generated Application Password, you can remove all spaces before using it.', 'stifli-flex-mcp' ); ?></p>
				<p class="description">
					<?php echo wp_kses(
						sprintf(
							/* translators: %s: dynamic endpoint URL */
							__( 'Example (dynamic endpoint for this site: %s):', 'stifli-flex-mcp' ),
							'<code>' . esc_html( $messages_endpoint ) . '</code>'
						),
						array( 'code' => array() )
					); ?>
				</p>
				<pre class="sflmcp-oauth-pre"><?php echo esc_html( $curl_example ); ?></pre>

						<div class="sflmcp-oauth-bundle-footer">
							<h3><?php esc_html_e( 'Optional: Claude Desktop Bundle (.mcpb)', 'stifli-flex-mcp' ); ?></h3>
							<p class="description"><?php esc_html_e( 'Download a prebuilt MCP bundle for this site. Keep this helper at the bottom to avoid clutter in the main setup flow.', 'stifli-flex-mcp' ); ?></p>
							<p>
								<a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=sflmcp_download_mcpb_bundle' ), 'sflmcp_download_mcpb_bundle' ) ); ?>">
									<?php esc_html_e( 'Download .mcpb Bundle', 'stifli-flex-mcp' ); ?>
								</a>
							</p>
						</div>
			</div>

		</div>

		<?php
	}
	
	private function renderToolsTab() {
		$model = $this->getModel();
		$integration_managed_tools = $this->getIntegrationManagedTools($model);
		global $wpdb;
		$table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_tools', false);
		$profiles_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profiles', false);
		$table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($table);
		$profiles_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profiles_table);
		
		// Check if there's an active profile
		$active_profile_query = sprintf('SELECT * FROM %s WHERE is_active = %%d', $profiles_table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$active_profile = $wpdb->get_row($wpdb->prepare($active_profile_query, 1), ARRAY_A);
		
		// Handle re-seeding
		$reseed_nonce = isset($_POST['sflmcp_reseed_nonce']) ? sanitize_text_field( wp_unslash( $_POST['sflmcp_reseed_nonce'] ) ) : '';
		if (!empty($reseed_nonce) && wp_verify_nonce($reseed_nonce, 'sflmcp_reseed_tools')) {
			$truncate_query = sprintf('TRUNCATE TABLE %s', $table_sql);
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.PreparedSQL.NotPrepared -- admin action intentionally resets plugin-managed table.
			$wpdb->query($truncate_query);
			stifli_flex_mcp_seed_initial_tools();
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Tools reset and reseeded successfully.', 'stifli-flex-mcp') . '</p></div>';
		}
		
		// Get all tools grouped by category (ONLY core WordPress tools; exclude WooCommerce and Plugins integration categories).
		$tools_query = sprintf('SELECT * FROM %s WHERE category NOT LIKE %%s AND category NOT LIKE %%s ORDER BY category, tool_name', $table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$tools = $wpdb->get_results($wpdb->prepare($tools_query, 'WooCommerce%', 'Plugins - %'), ARRAY_A);

		if (!empty($integration_managed_tools)) {
			$tools = array_values(array_filter($tools, function($tool) use ($integration_managed_tools) {
				$name = isset($tool['tool_name']) ? (string) $tool['tool_name'] : '';
				return '' === $name || !isset($integration_managed_tools[$name]);
			}));
		}

		$enabled_token_total = 0;
		foreach ($tools as $tool_row) {
			if (intval($tool_row['enabled']) === 1) {
				$enabled_token_total += intval($tool_row['token_estimate']);
			}
		}
		
		$grouped_tools = array();
		foreach ($tools as $tool) {
			$category = $tool['category'];
			if (!isset($grouped_tools[$category])) {
				$grouped_tools[$category] = array();
			}
			$grouped_tools[$category][] = $tool;
		}
		
		?>
		
		<p><?php echo esc_html__('Here you can manage which tools are available on the MCP server. Click on the status button to toggle. Changes are saved automatically.', 'stifli-flex-mcp'); ?></p>
		<p><strong><?php echo esc_html__('Total estimated tokens for enabled WordPress tools:', 'stifli-flex-mcp'); ?></strong> <span class="sflmcp-total-tokens"><?php echo esc_html(number_format_i18n($enabled_token_total)); ?></span></p>
		<p class="description"><?php echo esc_html__('Token estimates are approximate (computed from tool name, description, and schema). Use them to compare profiles rather than as an exact billing value.', 'stifli-flex-mcp'); ?></p>
		
		<?php if ($active_profile): ?>
			<div class="notice notice-info">
				<p>
					<strong>⚠️ <?php echo esc_html__('Active profile:', 'stifli-flex-mcp'); ?></strong>
					<?php echo esc_html($active_profile['profile_name']); ?>
					<br>
					<?php echo esc_html__('Changes to tools will be automatically saved to this profile.', 'stifli-flex-mcp'); ?>
					<a href="?page=sflmcp-server&tab=profiles" class="button button-small sflmcp-profile-link">
						<?php echo esc_html__('View Profiles', 'stifli-flex-mcp'); ?>
					</a>
				</p>
			</div>
		<?php endif; ?>
		
		<?php if (empty($grouped_tools)): ?>
			<div class="notice notice-warning">
				<p><?php echo esc_html__('No tools found in the database. Use the button below to seed them.', 'stifli-flex-mcp'); ?></p>
			</div>
			<form method="post" action="">
				<?php wp_nonce_field('sflmcp_reseed_tools', 'sflmcp_reseed_nonce'); ?>
				<p>
					<button type="submit" class="button button-primary"><?php echo esc_html__('Seed Initial Tools', 'stifli-flex-mcp'); ?></button>
				</p>
			</form>
		<?php else: ?>
			<form method="post" action="" class="sflmcp-reseed-form">
				<?php wp_nonce_field('sflmcp_reseed_tools', 'sflmcp_reseed_nonce'); ?>
				<p>
					<button type="submit" class="button button-secondary sflmcp-reseed-btn" data-confirm="<?php echo esc_attr__('This will delete all tools and reseed them. Are you sure?', 'stifli-flex-mcp'); ?>"><?php echo esc_html__('Reset and Reseed Tools', 'stifli-flex-mcp'); ?></button>
					<span class="description"><?php echo esc_html__('Useful if you\'ve updated the plugin and new tools are available.', 'stifli-flex-mcp'); ?></span>
				</p>
			</form>
			
			<?php foreach ($grouped_tools as $category => $category_tools): ?>
				<?php
				$category_token_total = 0;
				$category_read = 0;
				$category_write = 0;
				$category_enabled = 0;
				$category_enabled_tokens = 0;
				$category_enabled_read = 0;
				$category_enabled_write = 0;
				foreach ($category_tools as $tool_meta) {
					$category_token_total += intval($tool_meta['token_estimate']);
					$tool_mode = $this->getToolModeLabel($model, $tool_meta['tool_name']);
					if ('WRITE' === $tool_mode) {
						$category_write++;
					} else {
						$category_read++;
					}
					if (intval($tool_meta['enabled']) === 1) {
						$category_enabled++;
						$category_enabled_tokens += intval($tool_meta['token_estimate']);
						if ('WRITE' === $tool_mode) {
							$category_enabled_write++;
						} else {
							$category_enabled_read++;
						}
					}
				}
				$count_class = ($category_enabled === count($category_tools) && count($category_tools) > 0) ? 'sflmcp-count-full' : ($category_enabled > 0 ? 'sflmcp-count-partial' : '');
				$summary_html = esc_html($category_enabled . '/' . count($category_tools) . ' enabled');
				if ($category_enabled_read > 0) {
					$summary_html .= ' &middot; <span class="sflmcp-mode-label">' . esc_html($category_enabled_read . ' read') . '</span>';
				}
				if ($category_enabled_write > 0) {
					$summary_html .= ' &middot; <span class="sflmcp-mode-label">' . esc_html($category_enabled_write . ' write') . '</span>';
				}
				if ($category_enabled > 0) {
					$summary_html .= ' &middot; ' . esc_html(number_format_i18n($category_enabled_tokens)) . ' tokens';
				}
				?>
				<details class="sflmcp-tools-category" data-category="<?php echo esc_attr($category); ?>">
					<summary>
						<div class="sflmcp-summary-left">
							<input type="checkbox" class="sflmcp-category-checkbox" data-category="<?php echo esc_attr($category); ?>" <?php checked($category_enabled === count($category_tools)); ?> />
							<span class="sflmcp-chevron" aria-hidden="true">&#9656;</span>
							<span class="sflmcp-tools-category-title"><?php echo esc_html($category); ?></span>
						</div>
						<div class="sflmcp-summary-right">
							<span class="sflmcp-enabled-count <?php echo esc_attr($count_class); ?>"><?php echo $summary_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Pre-escaped with esc_html() above. ?></span>
						</div>
					</summary>
					<div class="sflmcp-tools-category-body">
						<table class="wp-list-table widefat fixed striped">
							<tbody>
								<?php foreach ($category_tools as $tool):
									$is_enabled = intval($tool['enabled']) === 1;
									$tool_mode = $this->getToolModeLabel($model, $tool['tool_name']);
									$mode_class = 'WRITE' === $tool_mode ? 'sflmcp-mode-write' : 'sflmcp-mode-read';
								?>
								<tr>
									<td class="sflmcp-tools-col-checkbox">
										<div class="sflmcp-tools-col-checkbox-content">
											<input type="checkbox" class="sflmcp-tool-checkbox" data-id="<?php echo intval($tool['id']); ?>" data-tokens="<?php echo intval($tool['token_estimate']); ?>" data-mode="<?php echo esc_attr($tool_mode); ?>" <?php checked($is_enabled); ?> />
											<code><?php echo esc_html($tool['tool_name']); ?></code>
										</div>
									</td>
									<td class="sflmcp-tools-col-desc"><?php echo esc_html($tool['tool_description']); ?></td>
									<td class="sflmcp-tools-col-mode"><span class="sflmcp-tool-mode-badge <?php echo esc_attr($mode_class); ?>"><?php echo esc_html($tool_mode); ?></span></td>
									<td class="sflmcp-tools-col-tokens"><?php echo esc_html(number_format_i18n(intval($tool['token_estimate']))); ?> tokens</td>
								</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				</details>
			<?php endforeach; ?>
		<?php endif; ?>
		<?php
	}
	
	private function renderWCToolsTab() {
		$model = $this->getModel();
		global $wpdb;
		$table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_tools', false);
		$profiles_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profiles', false);
		$table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($table);
		$profiles_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profiles_table);
		
		// Check if there's an active profile
		$active_profile_query = sprintf('SELECT * FROM %s WHERE is_active = %%d', $profiles_table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$active_profile = $wpdb->get_row($wpdb->prepare($active_profile_query, 1), ARRAY_A);
		
		// Get all WooCommerce tools grouped by category
		$wc_tools_query = sprintf("SELECT * FROM %s WHERE category LIKE %%s ORDER BY category, tool_name", $table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$tools = $wpdb->get_results($wpdb->prepare($wc_tools_query, 'WooCommerce%'), ARRAY_A);
		$wc_token_sum_query = sprintf("SELECT COALESCE(SUM(token_estimate),0) FROM %s WHERE category LIKE %%s AND enabled = %%d", $table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$enabled_token_total = (int) $wpdb->get_var($wpdb->prepare($wc_token_sum_query, 'WooCommerce%', 1));
		
		$grouped_tools = array();
		foreach ($tools as $tool) {
			$category = $tool['category'];
			if (!isset($grouped_tools[$category])) {
				$grouped_tools[$category] = array();
			}
			$grouped_tools[$category][] = $tool;
		}
		
		?>
		
		<p><?php echo esc_html__('Here you can manage which WooCommerce tools are available on the MCP server. Click on the status button to toggle. Changes are saved automatically.', 'stifli-flex-mcp'); ?></p>
		<p><strong><?php echo esc_html__('Total estimated tokens for enabled WooCommerce tools:', 'stifli-flex-mcp'); ?></strong> <span class="sflmcp-total-tokens"><?php echo esc_html(number_format_i18n($enabled_token_total)); ?></span></p>
		<p class="description"><?php echo esc_html__('Token estimates are approximate (computed from tool name, description, and schema). Use them to compare profiles rather than as an exact billing value.', 'stifli-flex-mcp'); ?></p>
		
		<?php if ($active_profile): ?>
			<div class="notice notice-info">
				<p>
					<strong>⚠️ <?php echo esc_html__('Active profile:', 'stifli-flex-mcp'); ?></strong>
					<?php echo esc_html($active_profile['profile_name']); ?>
					<br>
					<?php echo esc_html__('Changes to tools will be automatically saved to this profile.', 'stifli-flex-mcp'); ?>
					<a href="?page=sflmcp-server&tab=profiles" class="button button-small sflmcp-profile-link">
						<?php echo esc_html__('View Profiles', 'stifli-flex-mcp'); ?>
					</a>
				</p>
			</div>
		<?php endif; ?>
		
		<?php 
		// Check if WooCommerce is installed and active
		$wc_installed = class_exists('WooCommerce');
		?>
		
		<?php if (!$wc_installed): ?>
			<div class="notice notice-warning">
				<p>
					<strong>⚠️ <?php echo esc_html__('WooCommerce is not installed or activated', 'stifli-flex-mcp'); ?></strong><br>
					<?php echo esc_html__('WooCommerce tools are available to configure, but will not work until you install and activate the WooCommerce plugin.', 'stifli-flex-mcp'); ?>
					<?php echo esc_html__('You can enable/disable them now and they will be ready when WooCommerce is active.', 'stifli-flex-mcp'); ?>
				</p>
			</div>
		<?php endif; ?>
		
		<?php if (empty($grouped_tools)): ?>
			<div class="notice notice-info">
				<p><?php echo esc_html__('No WooCommerce tools found in the database. Use the "Reset and Reseed" button in the WordPress tab to load them.', 'stifli-flex-mcp'); ?></p>
			</div>
		<?php else: ?>
			<?php foreach ($grouped_tools as $category => $category_tools): ?>
				<?php
				$category_token_total = 0;
				$category_read = 0;
				$category_write = 0;
				$category_enabled = 0;
				$category_enabled_tokens = 0;
				$category_enabled_read = 0;
				$category_enabled_write = 0;
				foreach ($category_tools as $tool_meta) {
					$category_token_total += intval($tool_meta['token_estimate']);
					$tool_mode = $this->getToolModeLabel($model, $tool_meta['tool_name']);
					if ('WRITE' === $tool_mode) {
						$category_write++;
					} else {
						$category_read++;
					}
					if (intval($tool_meta['enabled']) === 1) {
						$category_enabled++;
						$category_enabled_tokens += intval($tool_meta['token_estimate']);
						if ('WRITE' === $tool_mode) {
							$category_enabled_write++;
						} else {
							$category_enabled_read++;
						}
					}
				}
				$count_class = ($category_enabled === count($category_tools) && count($category_tools) > 0) ? 'sflmcp-count-full' : ($category_enabled > 0 ? 'sflmcp-count-partial' : '');
				$summary_html = esc_html($category_enabled . '/' . count($category_tools) . ' enabled');
				if ($category_enabled_read > 0) {
					$summary_html .= ' &middot; <span class="sflmcp-mode-label">' . esc_html($category_enabled_read . ' read') . '</span>';
				}
				if ($category_enabled_write > 0) {
					$summary_html .= ' &middot; <span class="sflmcp-mode-label">' . esc_html($category_enabled_write . ' write') . '</span>';
				}
				if ($category_enabled > 0) {
					$summary_html .= ' &middot; ' . esc_html(number_format_i18n($category_enabled_tokens)) . ' tokens';
				}
				?>
				<details class="sflmcp-tools-category" data-category="<?php echo esc_attr($category); ?>">
					<summary>
						<div class="sflmcp-summary-left">
							<input type="checkbox" class="sflmcp-category-checkbox" data-category="<?php echo esc_attr($category); ?>" <?php checked($category_enabled === count($category_tools)); ?> />
							<span class="sflmcp-chevron" aria-hidden="true">&#9656;</span>
							<span class="sflmcp-tools-category-title"><?php echo esc_html($category); ?></span>
						</div>
						<div class="sflmcp-summary-right">
							<span class="sflmcp-enabled-count <?php echo esc_attr($count_class); ?>"><?php echo $summary_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Pre-escaped with esc_html() above. ?></span>
						</div>
					</summary>
					<div class="sflmcp-tools-category-body">
						<table class="wp-list-table widefat fixed striped">
							<tbody>
								<?php foreach ($category_tools as $tool):
									$is_enabled = intval($tool['enabled']) === 1;
									$tool_mode = $this->getToolModeLabel($model, $tool['tool_name']);
									$mode_class = 'WRITE' === $tool_mode ? 'sflmcp-mode-write' : 'sflmcp-mode-read';
								?>
								<tr>
									<td class="sflmcp-tools-col-checkbox">
										<div class="sflmcp-tools-col-checkbox-content">
											<input type="checkbox" class="sflmcp-tool-checkbox" data-id="<?php echo intval($tool['id']); ?>" data-tokens="<?php echo intval($tool['token_estimate']); ?>" data-mode="<?php echo esc_attr($tool_mode); ?>" <?php checked($is_enabled); ?> />
											<code><?php echo esc_html($tool['tool_name']); ?></code>
										</div>
									</td>
									<td class="sflmcp-tools-col-desc"><?php echo esc_html($tool['tool_description']); ?></td>
									<td class="sflmcp-tools-col-mode"><span class="sflmcp-tool-mode-badge <?php echo esc_attr($mode_class); ?>"><?php echo esc_html($tool_mode); ?></span></td>
									<td class="sflmcp-tools-col-tokens"><?php echo esc_html(number_format_i18n(intval($tool['token_estimate']))); ?> tokens</td>
								</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				</details>
			<?php endforeach; ?>
		<?php endif; ?>
		<?php
	}

	private function getIntegrationManagedTools($model) {
		$managed = array();
		if (!class_exists('StifliFlexMcp_Plugin_Integrations_Registry') || !is_object($model) || !method_exists($model, 'getTools')) {
			return $managed;
		}

		$all_tools = $model->getTools();
		if (!is_array($all_tools)) {
			return $managed;
		}

		foreach (array_keys($all_tools) as $tool_name) {
			if (!empty(StifliFlexMcp_Plugin_Integrations_Registry::get_integrations_for_tool($tool_name))) {
				$managed[$tool_name] = true;
			}
		}

		return $managed;
	}

	private function getToolModeLabel($model, $tool_name) {
		if (!is_object($model) || !method_exists($model, 'getIntentForTool')) {
			return 'READ';
		}
		$meta = $model->getIntentForTool((string) $tool_name);
		if (is_array($meta) && isset($meta['intent']) && 'write' === $meta['intent']) {
			return 'WRITE';
		}
		return 'READ';
	}
	
	private function renderProfilesTab() {
		global $wpdb;
		$profiles_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profiles', false);
		$profile_tools_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_profile_tools', false);
		$tools_table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_tools', false);
		$profiles_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profiles_table);
		$profile_tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($profile_tools_table);
		$tools_table_sql = StifliFlexMcpUtils::wrapTableNameForQuery($tools_table);
		
		// Get all profiles with tool count and estimated tokens
		$profiles_query = sprintf(
			"SELECT p.*, COUNT(pt.id) AS tools_count, COALESCE(SUM(t.token_estimate),0) AS tokens_sum\n"
			."FROM %s p\n"
			."LEFT JOIN %s pt ON p.id = pt.profile_id\n"
			."LEFT JOIN %s t ON pt.tool_name = t.tool_name\n"
			."WHERE 1 = %%d\n"
			."GROUP BY p.id\n"
			."ORDER BY p.is_system DESC, p.profile_name ASC",
			$profiles_table_sql,
			$profile_tools_table_sql,
			$tools_table_sql
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$profiles = $wpdb->get_results($wpdb->prepare($profiles_query, 1), ARRAY_A);

		$total_tools_query = sprintf('SELECT COUNT(*) FROM %s WHERE 1 = %%d', $tools_table_sql);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
		$total_tools = $wpdb->get_var($wpdb->prepare($total_tools_query, 1));
		
		?>
		<p><?php echo esc_html__('Profiles allow you to quickly switch which tools are available for different use cases.', 'stifli-flex-mcp'); ?></p>
		<p class="description"><?php echo esc_html__('Token totals shown below are approximations based on the enabled tools. They help you gauge relative cost when switching profiles.', 'stifli-flex-mcp'); ?></p>
		
		<div class="sflmcp-profiles-actions">
			<button type="button" class="button" id="sflmcp_import_profile">
				<?php echo esc_html__('⬆ Import JSON', 'stifli-flex-mcp'); ?>
			</button>
			<button type="button" class="button" id="sflmcp_restore_system_profiles">
				<?php echo esc_html__('🔄 Restore System Profiles', 'stifli-flex-mcp'); ?>
			</button>
		</div>
		<?php
		$active_profile_info = null;
		foreach ($profiles as $profile_row) {
			if (intval($profile_row['is_active']) === 1) {
				$active_profile_info = $profile_row;
				break;
			}
		}
		if ($active_profile_info) :
		?>
		<div class="notice notice-info">
			<p>
				<strong><?php echo esc_html__('Currently active profile:', 'stifli-flex-mcp'); ?></strong>
				<?php echo esc_html($active_profile_info['profile_name']); ?>
				<span class="sflmcp-profiles-token-info"><?php echo esc_html__('Estimated token footprint (sum of enabled tools within the profile):', 'stifli-flex-mcp'); ?> <?php echo esc_html(number_format_i18n(intval($active_profile_info['tokens_sum']))); ?></span>
			</p>
		</div>
		<?php endif; ?>
		
		<?php if (empty($profiles)): ?>
			<div class="notice notice-warning">
				<p><?php echo esc_html__('No profiles found. Use the button above to restore system profiles.', 'stifli-flex-mcp'); ?></p>
			</div>
		<?php else: ?>
			<!-- System Profiles -->
			<?php
			$system_profiles = array_filter($profiles, function($p) { return intval($p['is_system']) === 1; });
			if (!empty($system_profiles)):
			?>
			<h3><?php echo esc_html__('System Profiles (non-deletable)', 'stifli-flex-mcp'); ?></h3>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th class="sflmcp-profiles-col-radio"></th>
						<th class="sflmcp-profiles-col-name"><?php echo esc_html__('Name', 'stifli-flex-mcp'); ?></th>
						<th class="sflmcp-profiles-col-desc"><?php echo esc_html__('Description', 'stifli-flex-mcp'); ?></th>
						<th class="sflmcp-profiles-col-tools"><?php echo esc_html__('Tools', 'stifli-flex-mcp'); ?></th>
						<th class="sflmcp-profiles-col-tokens"><?php echo esc_html__('Tokens (~)', 'stifli-flex-mcp'); ?></th>
						<th class="sflmcp-profiles-col-actions"><?php echo esc_html__('Actions', 'stifli-flex-mcp'); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($system_profiles as $profile): ?>
						<?php
						// Get tools for this profile
						$system_tools_query = sprintf(
							'SELECT t.tool_name FROM %s pt LEFT JOIN %s t ON pt.tool_name = t.tool_name WHERE pt.profile_id = %%d ORDER BY t.tool_name',
							$profile_tools_table_sql,
							$tools_table_sql
						);
						// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
						$profile_tools_rows = $wpdb->get_results($wpdb->prepare($system_tools_query, $profile['id']), ARRAY_A);
						$profile_tools_list = array();
						if (!empty($profile_tools_rows)) {
							foreach ($profile_tools_rows as $tool_row) {
								$profile_tools_list[] = $tool_row['tool_name'];
							}
						}
						$tools_list_html = !empty($profile_tools_list) ? implode(', ', $profile_tools_list) : esc_html__('None', 'stifli-flex-mcp');
						?>
						<tr>
							<td>
								<?php if (intval($profile['is_active']) === 1): ?>
									<span class="sflmcp-active-dot">●</span>
								<?php endif; ?>
							</td>
							<td><strong><?php echo esc_html($profile['profile_name']); ?></strong></td>
							<td>
								<?php echo esc_html($profile['profile_description']); ?>
								<br>
								<a href="#" class="SFLMCP-view-tools" data-tools="<?php echo esc_attr($tools_list_html); ?>" class="sflmcp-view-tools-link">
									📋 <?php echo esc_html__('View tools', 'stifli-flex-mcp'); ?>
								</a>
							</td>
							<td><?php echo esc_html(intval($profile['tools_count']) . '/' . intval($total_tools)); ?></td>
							<td><?php echo esc_html(number_format_i18n(intval($profile['tokens_sum']))); ?></td>
							<td>
								<button type="button" class="button SFLMCP-apply-profile" data-profile-id="<?php echo intval($profile['id']); ?>" data-profile-name="<?php echo esc_attr($profile['profile_name']); ?>">
									<?php echo esc_html__('Apply', 'stifli-flex-mcp'); ?>
								</button>
								<button type="button" class="button SFLMCP-duplicate-profile" data-profile-id="<?php echo intval($profile['id']); ?>">
									<?php echo esc_html__('Duplicate', 'stifli-flex-mcp'); ?>
								</button>
								<button type="button" class="button SFLMCP-export-profile" data-profile-id="<?php echo intval($profile['id']); ?>" data-profile-name="<?php echo esc_attr($profile['profile_name']); ?>">
									<?php echo esc_html__('Export', 'stifli-flex-mcp'); ?>
								</button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>
			
			<!-- Custom Profiles -->
			<?php
			$custom_profiles = array_filter($profiles, function($p) { return intval($p['is_system']) === 0; });
			if (!empty($custom_profiles)):
			?>
			<h3 class="sflmcp-profiles-custom-heading"><?php echo esc_html__('Custom Profiles', 'stifli-flex-mcp'); ?></h3>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th class="sflmcp-profiles-col-radio"></th>
						<th class="sflmcp-profiles-col-name"><?php echo esc_html__('Name', 'stifli-flex-mcp'); ?></th>
						<th class="sflmcp-profiles-col-desc"><?php echo esc_html__('Description', 'stifli-flex-mcp'); ?></th>
						<th class="sflmcp-profiles-col-tools"><?php echo esc_html__('Tools', 'stifli-flex-mcp'); ?></th>
						<th class="sflmcp-profiles-col-tokens"><?php echo esc_html__('Tokens (~)', 'stifli-flex-mcp'); ?></th>
						<th class="sflmcp-profiles-col-actions"><?php echo esc_html__('Actions', 'stifli-flex-mcp'); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($custom_profiles as $profile): ?>
						<?php
						// Get tools for this profile
						$custom_tools_query = sprintf(
							'SELECT t.tool_name, COALESCE(t.token_estimate,0) as token_estimate FROM %s pt LEFT JOIN %s t ON pt.tool_name = t.tool_name WHERE pt.profile_id = %%d ORDER BY t.tool_name',
							$profile_tools_table_sql,
							$tools_table_sql
						);
						// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- query uses sprintf with safe table wrapper.
						$profile_tools_rows = $wpdb->get_results($wpdb->prepare($custom_tools_query, $profile['id']), ARRAY_A);
						$profile_tools_list = array();
						if (!empty($profile_tools_rows)) {
							foreach ($profile_tools_rows as $tool_row) {
								$token_str = number_format_i18n(intval($tool_row['token_estimate']));
								$profile_tools_list[] = sprintf('%s (≈%s)', $tool_row['tool_name'], $token_str);
							}
						}
						$tools_list_html = !empty($profile_tools_list) ? implode(', ', $profile_tools_list) : esc_html__('None', 'stifli-flex-mcp');
						?>
						<tr>
							<td>
								<?php if (intval($profile['is_active']) === 1): ?>
									<span class="sflmcp-active-dot">●</span>
								<?php endif; ?>
							</td>
							<td><strong><?php echo esc_html($profile['profile_name']); ?></strong></td>
							<td>
								<?php echo esc_html($profile['profile_description']); ?>
								<br>
								<a href="#" class="SFLMCP-view-tools" data-tools="<?php echo esc_attr($tools_list_html); ?>" class="sflmcp-view-tools-link">
									📋 <?php echo esc_html__('View tools', 'stifli-flex-mcp'); ?>
								</a>
							</td>
							<td><?php echo esc_html(intval($profile['tools_count']) . '/' . intval($total_tools)); ?></td>
							<td><?php echo esc_html(number_format_i18n(intval($profile['tokens_sum']))); ?></td>
							<td>
								<button type="button" class="button SFLMCP-apply-profile" data-profile-id="<?php echo intval($profile['id']); ?>" data-profile-name="<?php echo esc_attr($profile['profile_name']); ?>">
									<?php echo esc_html__('Apply', 'stifli-flex-mcp'); ?>
								</button>
								<button type="button" class="button SFLMCP-edit-profile" data-profile-id="<?php echo intval($profile['id']); ?>">
									<?php echo esc_html__('Edit', 'stifli-flex-mcp'); ?>
								</button>
								<button type="button" class="button SFLMCP-duplicate-profile" data-profile-id="<?php echo intval($profile['id']); ?>">
									<?php echo esc_html__('Duplicate', 'stifli-flex-mcp'); ?>
								</button>
								<button type="button" class="button SFLMCP-export-profile" data-profile-id="<?php echo intval($profile['id']); ?>" data-profile-name="<?php echo esc_attr($profile['profile_name']); ?>">
									<?php echo esc_html__('Export', 'stifli-flex-mcp'); ?>
								</button>
								<button type="button" class="button button-link-delete SFLMCP-delete-profile" data-profile-id="<?php echo intval($profile['id']); ?>" data-profile-name="<?php echo esc_attr($profile['profile_name']); ?>">
									<?php echo esc_html__('Delete', 'stifli-flex-mcp'); ?>
								</button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>
		<?php endif; ?>
		
		<!-- Hidden file input for import -->
		<input type="file" id="sflmcp_import_file" accept=".json" class="sflmcp-hidden-file-input" />
		
		
		<?php
	}

	/**
	 * Render Custom Tools Tab
	 */
	public function renderCustomToolsTab($embedded = false) {
		?>
		<div class="notice notice-warning inline">
			<p><strong><?php echo esc_html__('Custom Tools have been retired.', 'stifli-flex-mcp'); ?></strong></p>
			<p><?php echo esc_html__('Legacy Custom Tools no longer run or appear in MCP tool discovery. Use WordPress Abilities to expose custom plugin capabilities with explicit permission callbacks.', 'stifli-flex-mcp'); ?></p>
		</div>
		<?php
		return;
		?>
		<?php if (!$embedded) : ?>
			<h2><?php echo esc_html__('🔌 Custom Tools (Webhooks & Actions)', 'stifli-flex-mcp'); ?></h2>
			<p>
				<?php echo esc_html__('Create custom tools that connect to external services, call any WordPress/plugin action hook, or integrate with APIs. The AI will invoke these tools just like native functions.', 'stifli-flex-mcp'); ?>
				<a href="?page=sflmcp-server&tab=help" class="button button-link">
					📚 <?php echo esc_html__('View Complete Guide', 'stifli-flex-mcp'); ?>
				</a>
			</p>
		<?php endif; ?>
		
		<div class="sflmcp-custom-tools-container">
			<!-- Tools List -->
			<div class="sflmcp-tools-list-panel">
				<div class="sflmcp-header-actions">
					<h3><?php echo esc_html__('Your Custom Tools', 'stifli-flex-mcp'); ?></h3>
					<button type="button" class="button button-primary" id="sflmcp_add_custom_tool">
						<?php echo esc_html__('➕ Add New Tool', 'stifli-flex-mcp'); ?>
					</button>
				</div>
				
				<table class="wp-list-table widefat fixed striped" id="sflmcp_custom_tools_table">
					<thead>
						<tr>
							<th width="20%"><?php echo esc_html__('Name', 'stifli-flex-mcp'); ?></th>
							<th width="35%"><?php echo esc_html__('Description', 'stifli-flex-mcp'); ?></th>
							<th width="10%"><?php echo esc_html__('Method', 'stifli-flex-mcp'); ?></th>
							<th width="10%"><?php echo esc_html__('Status', 'stifli-flex-mcp'); ?></th>
							<th width="25%"><?php echo esc_html__('Actions', 'stifli-flex-mcp'); ?></th>
						</tr>
					</thead>
					<tbody>
						<!-- Rows loaded via AJAX -->
						<tr class="sflmcp-loading-row">
							<td colspan="5"><?php echo esc_html__('Loading tools...', 'stifli-flex-mcp'); ?></td>
						</tr>
					</tbody>
				</table>
			</div>
			
			<!-- Editor Modal (Hidden) -->
			<div id="sflmcp_tool_editor_modal" class="sflmcp-modal">
				<div class="sflmcp-modal-content">
					<div class="sflmcp-modal-header">
						<h2 id="sflmcp_editor_title"><?php echo esc_html__('Edit Tool', 'stifli-flex-mcp'); ?></h2>
						<span class="sflmcp-modal-close">&times;</span>
					</div>
					<div class="sflmcp-modal-body">
						<form id="sflmcp_tool_form">
							<input type="hidden" id="tool_id" name="id" value="">
							
							<div class="sflmcp-form-row">
								<label><?php echo esc_html__('Internal Name (Unique)', 'stifli-flex-mcp'); ?></label>
								<input type="text" id="tool_name" name="tool_name" required placeholder="custom_create_ticket">
								<p class="description"><?php echo esc_html__('Must start with "custom_". Only lowercase letters, numbers, and underscores.', 'stifli-flex-mcp'); ?></p>
							</div>
							
							<div class="sflmcp-form-row">
								<label><?php echo esc_html__('Description (Instruction for AI)', 'stifli-flex-mcp'); ?></label>
								<textarea id="tool_description" name="tool_description" rows="2" required placeholder="Creates a support ticket in Jira with title and priority."></textarea>
							</div>
							
							<div class="sflmcp-form-group-inline">
								<div class="sflmcp-form-row">
									<label><?php echo esc_html__('Type', 'stifli-flex-mcp'); ?></label>
									<select id="tool_method" name="method">
										<option value="GET">GET (HTTP)</option>
										<option value="POST">POST (HTTP)</option>
										<option value="PUT">PUT (HTTP)</option>
										<option value="DELETE">DELETE (HTTP)</option>
										<option value="ACTION">ACTION (WordPress do_action)</option>
									</select>
									<p class="description"><?php echo esc_html__('HTTP calls external APIs. ACTION executes internal WordPress hooks.', 'stifli-flex-mcp'); ?></p>
								</div>
								<div class="sflmcp-form-row sflmcp-form-row-grow">
									<label id="endpoint_label"><?php echo esc_html__('Webhook URL / Endpoint', 'stifli-flex-mcp'); ?></label>
									<input type="text" id="tool_endpoint" name="endpoint" required placeholder="https://hook.eu1.make.com/...">
									<p class="description" id="endpoint_help"><?php echo esc_html__('For HTTP: full URL. For ACTION: any WordPress action hook name (e.g. flush_rewrite_rules, woocommerce_cancel_unpaid_orders)', 'stifli-flex-mcp'); ?></p>
								</div>
							</div>
							
							<!-- Interactive Schema Builder -->
							<div class="sflmcp-form-row">
								<label><?php echo esc_html__('Parameters (What does the AI ask for?)', 'stifli-flex-mcp'); ?></label>
								<div id="sflmcp_args_builder">
									<table class="widefat" id="sflmcp_args_table">
										<thead>
											<tr>
												<th><?php echo esc_html__('Param Name', 'stifli-flex-mcp'); ?></th>
												<th><?php echo esc_html__('Type', 'stifli-flex-mcp'); ?></th>
												<th><?php echo esc_html__('Description', 'stifli-flex-mcp'); ?></th>
												<th><?php echo esc_html__('Required', 'stifli-flex-mcp'); ?></th>
												<th width="50"></th>
											</tr>
										</thead>
										<tbody><!-- JS populates this --></tbody>
										<tfoot>
											<tr>
												<td colspan="5">
													<button type="button" class="button button-small" id="sflmcp_add_arg_row"><?php echo esc_html__('+ Add Parameter', 'stifli-flex-mcp'); ?></button>
												</td>
											</tr>
										</tfoot>
									</table>
								</div>
							</div>
							
							<div class="sflmcp-advanced-toggle">
								<a href="#" id="sflmcp_toggle_advanced"><?php echo esc_html__('Advanced Settings (Headers)', 'stifli-flex-mcp'); ?></a>
							</div>
							
							<div id="sflmcp_advanced_settings">
								<div class="sflmcp-form-row">
									<label><?php echo esc_html__('HTTP Headers (JSON)', 'stifli-flex-mcp'); ?></label>
									<textarea id="tool_headers" name="headers" rows="3" placeholder='{"Authorization": "Bearer token"}'></textarea>
								</div>
							</div>

							<div class="sflmcp-form-row">
								<label>
									<input type="checkbox" id="tool_enabled" name="enabled" value="1" checked>
									<?php echo esc_html__('Enable this tool', 'stifli-flex-mcp'); ?>
								</label>
							</div>
						</form>
					</div>
					<div class="sflmcp-modal-footer">
						<button type="button" class="button button-secondary" id="sflmcp_test_tool"><?php echo esc_html__('Test Connection', 'stifli-flex-mcp'); ?></button>
						<div class="sflmcp-spacer"></div>
						<button type="button" class="button button-primary" id="sflmcp_save_tool"><?php echo esc_html__('Save Tool', 'stifli-flex-mcp'); ?></button>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	// AJAX Handlers for Custom Tools

	public function ajax_get_custom_tools() {
		wp_send_json_error(array('message' => __('Legacy Custom Tools have been retired. Use WordPress Abilities instead.', 'stifli-flex-mcp')), 410);
		return;

		check_ajax_referer('sflmcp_custom_tools', 'nonce');
		if (!current_user_can('manage_options')) wp_send_json_error();
		
		global $wpdb;
		$table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_custom_tools');
		// phpcs:ignore
		$tools = $wpdb->get_results("SELECT * FROM $table ORDER BY created_at DESC");
		
		wp_send_json_success($tools);
	}

	public function ajax_save_custom_tool() {
		wp_send_json_error(array('message' => __('Legacy Custom Tools have been retired. Use WordPress Abilities instead.', 'stifli-flex-mcp')), 410);
		return;

		check_ajax_referer('sflmcp_custom_tools', 'nonce');
		if (!current_user_can('manage_options')) wp_send_json_error();
		
		global $wpdb;
		$table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_custom_tools');
		
		$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
		$name = isset($_POST['tool_name']) ? sanitize_text_field( wp_unslash( $_POST['tool_name'] ) ) : '';
		$desc = isset($_POST['tool_description']) ? sanitize_text_field( wp_unslash( $_POST['tool_description'] ) ) : '';
		$method = isset($_POST['method']) ? sanitize_text_field( wp_unslash( $_POST['method'] ) ) : 'GET';
		$endpoint = isset($_POST['endpoint']) ? esc_url_raw( wp_unslash( $_POST['endpoint'] ) ) : '';
		$enabled = isset($_POST['enabled']) ? 1 : 0;
		
		// Handle headers JSON
		$headers = isset($_POST['headers']) ? sanitize_textarea_field( wp_unslash( $_POST['headers'] ) ) : '';
		if (!empty($headers) && null === json_decode($headers)) {
			wp_send_json_error(array('message' => 'Invalid JSON in headers'));
		}

		// Handle Arguments Builder -> JSON Schema
		$args_json = isset($_POST['arguments']) ? sanitize_textarea_field( wp_unslash( $_POST['arguments'] ) ) : '{}';
		// Validate that it's valid JSON
		if (null === json_decode($args_json)) {
			wp_send_json_error(array('message' => 'Invalid JSON in arguments'));
		}
		
		$data = array(
			'tool_name' => $name,
			'tool_description' => $desc,
			'method' => $method,
			'endpoint' => $endpoint,
			'headers' => $headers,
			'arguments' => $args_json,
			'enabled' => $enabled
		);
		
		if ($id > 0) {
			$wpdb->update($table, $data, array('id' => $id));
		} else {
			// Ensure unique name
			if ($wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE tool_name = %s", $name))) {
				wp_send_json_error(array('message' => 'Tool name already exists'));
			}
			$wpdb->insert($table, $data);
		}
		
		wp_send_json_success();
	}

	public function ajax_delete_custom_tool() {
		wp_send_json_error(array('message' => __('Legacy Custom Tools have been retired. Use WordPress Abilities instead.', 'stifli-flex-mcp')), 410);
		return;

		check_ajax_referer('sflmcp_custom_tools', 'nonce');
		if (!current_user_can('manage_options')) wp_send_json_error();
		
		global $wpdb;
		$table = StifliFlexMcpUtils::getPrefixedTable('sflmcp_custom_tools');
		$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
		
		if (!$id) {
			wp_send_json_error(array('message' => __('Invalid tool ID', 'stifli-flex-mcp')));
			return;
		}
		
		$wpdb->delete($table, array('id' => $id));
		wp_send_json_success();
	}

	public function ajax_toggle_custom_tool() {
		wp_send_json_error(array('message' => __('Legacy Custom Tools have been retired. Use WordPress Abilities instead.', 'stifli-flex-mcp')), 410);
		return;

		check_ajax_referer('sflmcp_custom_tools', 'nonce');
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied', 'stifli-flex-mcp')));
			return;
		}
		
		global $wpdb;
		$table = $wpdb->prefix . 'sflmcp_custom_tools';
		$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
		
		if (!$id) {
			wp_send_json_error(array('message' => __('Invalid tool ID', 'stifli-flex-mcp')));
			return;
		}
		
		// Get current status
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Plugin-managed table with parameterized query.
		$current = $wpdb->get_var($wpdb->prepare("SELECT enabled FROM $table WHERE id = %d", $id));
		if ($current === null) {
			wp_send_json_error(array('message' => __('Tool not found', 'stifli-flex-mcp')));
			return;
		}
		
		$new_status = ($current == 1) ? 0 : 1;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->update($table, array('enabled' => $new_status), array('id' => $id));
		
		wp_send_json_success(array('enabled' => $new_status));
	}

	public function ajax_test_custom_tool() {
		wp_send_json_error(array('message' => __('Legacy Custom Tools have been retired. Use WordPress Abilities instead.', 'stifli-flex-mcp')), 410);
		return;

		check_ajax_referer('sflmcp_custom_tools', 'nonce');
		if (!current_user_can('manage_options')) wp_send_json_error();
		
		$endpoint = isset($_POST['endpoint']) ? esc_url_raw( wp_unslash( $_POST['endpoint'] ) ) : '';
		$method = isset($_POST['method']) ? sanitize_text_field( wp_unslash( $_POST['method'] ) ) : 'GET';
		$headers_raw = isset($_POST['headers']) ? sanitize_textarea_field( wp_unslash( $_POST['headers'] ) ) : '';
		$test_args = array(
			'test' => true,
			'timestamp' => time(),
			'source' => 'Flex MCP Test'
		);
		
		$args = array(
			'method' => $method,
			'timeout' => 15,
			'user-agent' => 'StifLi-Flex-MCP/Tester'
		);
		
		if (!empty($headers_raw)) {
			$h = json_decode($headers_raw, true);
			if (is_array($h)) {
				$args['headers'] = $h;
			}
		}
		
		if ($method === 'GET') {
			$endpoint = add_query_arg($test_args, $endpoint);
		} else {
			$args['body'] = wp_json_encode($test_args);
			if (!isset($args['headers']['Content-Type'])) {
				$args['headers']['Content-Type'] = 'application/json';
			}
		}
		
		$response = wp_remote_request($endpoint, $args);
		
		if (is_wp_error($response)) {
			wp_send_json_error(array('message' => $response->get_error_message()));
		} else {
			$code = wp_remote_retrieve_response_code($response);
			$body = wp_remote_retrieve_body($response);
			wp_send_json_success(array('code' => $code, 'body' => substr($body, 0, 500))); // Truncate for preview
		}
	}

	/**
	 * AJAX handler to toggle a single WordPress/WooCommerce tool
	 */
	public function ajax_toggle_tool() {
		check_ajax_referer('sflmcp_tools', 'nonce');
		
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied', 'stifli-flex-mcp')));
			return;
		}
		
		global $wpdb;
		$table = $wpdb->prefix . 'sflmcp_tools';
		$tool_id = isset($_POST['tool_id']) ? intval($_POST['tool_id']) : 0;
		
		if (!$tool_id) {
			wp_send_json_error(array('message' => __('Invalid tool ID', 'stifli-flex-mcp')));
			return;
		}
		
		// Get current status
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$tool = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $tool_id), ARRAY_A);
		
		if (!$tool) {
			wp_send_json_error(array('message' => __('Tool not found', 'stifli-flex-mcp')));
			return;
		}
		
		$new_status = ($tool['enabled'] == 1) ? 0 : 1;
		
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->update(
			$table,
			array('enabled' => $new_status, 'updated_at' => current_time('mysql', true)),
			array('id' => $tool_id),
			array('%d', '%s'),
			array('%d')
		);
		
		// Sync to active profile if exists
		$this->syncToolToActiveProfile($tool['tool_name'], $new_status);
		
		// Calculate new token totals
		$is_wc = strpos($tool['category'], 'WooCommerce') === 0;
		
		if ($is_wc) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$total_tokens = $wpdb->get_var($wpdb->prepare(
				"SELECT COALESCE(SUM(token_estimate),0) FROM $table WHERE category LIKE %s AND enabled = %d",
				'WooCommerce%', 1
			));
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$total_tokens = $wpdb->get_var($wpdb->prepare(
				"SELECT COALESCE(SUM(token_estimate),0) FROM $table WHERE category NOT LIKE %s AND category NOT LIKE %s AND enabled = %d",
				'WooCommerce%', 'Plugins - %', 1
			));
		}
		
		wp_send_json_success(array(
			'enabled' => $new_status,
			'total_tokens' => number_format_i18n(intval($total_tokens))
		));
	}

	/**
	 * AJAX handler to bulk toggle tools in a category
	 */
	public function ajax_bulk_toggle_tools() {
		check_ajax_referer('sflmcp_tools', 'nonce');
		
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied', 'stifli-flex-mcp')));
			return;
		}
		
		global $wpdb;
		$table = $wpdb->prefix . 'sflmcp_tools';
		$bulk_action = isset($_POST['bulk_action']) ? sanitize_text_field( wp_unslash( $_POST['bulk_action'] ) ) : '';
		$category = isset($_POST['category']) ? sanitize_text_field( wp_unslash( $_POST['category'] ) ) : '';
		
		if (!in_array($bulk_action, array('enable', 'disable'))) {
			wp_send_json_error(array('message' => __('Invalid action', 'stifli-flex-mcp')));
			return;
		}
		
		$new_status = ($bulk_action === 'enable') ? 1 : 0;
		
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query($wpdb->prepare(
			"UPDATE $table SET enabled = %d, updated_at = %s WHERE category = %s",
			$new_status, current_time('mysql', true), $category
		));
		
		// Get affected tools and sync to active profile
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$affected_tools = $wpdb->get_col($wpdb->prepare(
			"SELECT tool_name FROM $table WHERE category = %s",
			$category
		));
		
		foreach ($affected_tools as $tool_name) {
			$this->syncToolToActiveProfile($tool_name, $new_status);
		}
		
		wp_send_json_success();
	}

	/**
	 * Sync a tool's enabled status to the active profile
	 */
	private function syncToolToActiveProfile($tool_name, $enabled) {
		global $wpdb;
		$profiles_table = $wpdb->prefix . 'sflmcp_profiles';
		$profile_tools_table = $wpdb->prefix . 'sflmcp_profile_tools';
		
		// Get active profile
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$active_profile = $wpdb->get_row($wpdb->prepare(
			"SELECT id FROM $profiles_table WHERE is_active = %d",
			1
		), ARRAY_A);
		
		if (!$active_profile) {
			return;
		}
		
		$profile_id = $active_profile['id'];
		
		if ($enabled) {
			// Check if already exists
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$exists = $wpdb->get_var($wpdb->prepare(
				"SELECT id FROM $profile_tools_table WHERE profile_id = %d AND tool_name = %s",
				$profile_id, $tool_name
			));
			
			if (!$exists) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$wpdb->insert(
					$profile_tools_table,
					array('profile_id' => $profile_id, 'tool_name' => $tool_name),
					array('%d', '%s')
				);
			}
		} else {
			// Remove from profile
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->delete(
				$profile_tools_table,
				array('profile_id' => $profile_id, 'tool_name' => $tool_name),
				array('%d', '%s')
			);
		}
	}

	/**
	 * AJAX handler: toggle single tool via checkbox
	 */
	public function ajax_toggle_tool_by_checkbox() {
		check_ajax_referer('sflmcp_tools', 'nonce');
		
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied', 'stifli-flex-mcp')));
			return;
		}
		
		global $wpdb;
		$table = $wpdb->prefix . 'sflmcp_tools';
		$tool_id = isset($_POST['tool_id']) ? intval($_POST['tool_id']) : 0;
		$enabled = isset($_POST['enabled']) ? intval($_POST['enabled']) : 0;
		
		if (!$tool_id) {
			wp_send_json_error(array('message' => __('Invalid tool ID', 'stifli-flex-mcp')));
			return;
		}
		
		// Get tool info
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$tool = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $tool_id), ARRAY_A);
		
		if (!$tool) {
			wp_send_json_error(array('message' => __('Tool not found', 'stifli-flex-mcp')));
			return;
		}
		
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->update(
			$table,
			array('enabled' => $enabled, 'updated_at' => current_time('mysql', true)),
			array('id' => $tool_id),
			array('%d', '%s'),
			array('%d')
		);
		
		// Sync to active profile
		$this->syncToolToActiveProfile($tool['tool_name'], $enabled);
		
		// Calculate new token totals
		$is_wc = strpos($tool['category'], 'WooCommerce') === 0;
		
		if ($is_wc) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$total_tokens = $wpdb->get_var($wpdb->prepare(
				"SELECT COALESCE(SUM(token_estimate),0) FROM $table WHERE category LIKE %s AND enabled = %d",
				'WooCommerce%', 1
			));
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$total_tokens = $wpdb->get_var($wpdb->prepare(
				"SELECT COALESCE(SUM(token_estimate),0) FROM $table WHERE category NOT LIKE %s AND category NOT LIKE %s AND enabled = %d",
				'WooCommerce%', 'Plugins - %', 1
			));
		}
		
		wp_send_json_success(array(
			'enabled' => $enabled,
			'total_tokens' => number_format_i18n(intval($total_tokens))
		));
	}

	/**
	 * AJAX handler: bulk toggle multiple tools by ID (from category checkbox)
	 */
	public function ajax_bulk_toggle_tools_by_id() {
		check_ajax_referer('sflmcp_tools', 'nonce');
		
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied', 'stifli-flex-mcp')));
			return;
		}
		
		global $wpdb;
		$table = $wpdb->prefix . 'sflmcp_tools';
		$tool_ids = isset($_POST['tool_ids']) && is_array($_POST['tool_ids']) ? array_map('intval', wp_unslash($_POST['tool_ids'])) : array();
		
		if (empty($tool_ids)) {
			wp_send_json_error(array('message' => __('No tools specified', 'stifli-flex-mcp')));
			return;
		}
		
		// Get current enabled status of first tool to toggle
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$first_tool = $wpdb->get_row($wpdb->prepare(
			"SELECT enabled FROM $table WHERE id = %d",
			$tool_ids[0]
		), ARRAY_A);
		
		if (!$first_tool) {
			wp_send_json_error(array('message' => __('Tool not found', 'stifli-flex-mcp')));
			return;
		}
		
		// Toggle status
		$new_status = ($first_tool['enabled'] == 1) ? 0 : 1;
		
		// Update all tools
		foreach ($tool_ids as $tool_id) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->update(
				$table,
				array('enabled' => $new_status, 'updated_at' => current_time('mysql', true)),
				array('id' => $tool_id),
				array('%d', '%s'),
				array('%d')
			);
			
			// Get tool name for syncing
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$tool = $wpdb->get_row($wpdb->prepare("SELECT tool_name FROM $table WHERE id = %d", $tool_id), ARRAY_A);
			if ($tool) {
				$this->syncToolToActiveProfile($tool['tool_name'], $new_status);
			}
		}
		
		// Get WC vs WordPress status from first tool
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$first_tool_full = $wpdb->get_row($wpdb->prepare("SELECT category FROM $table WHERE id = %d", $tool_ids[0]), ARRAY_A);
		$is_wc = strpos($first_tool_full['category'], 'WooCommerce') === 0;
		
		// Calculate new token totals
		if ($is_wc) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$total_tokens = $wpdb->get_var($wpdb->prepare(
				"SELECT COALESCE(SUM(token_estimate),0) FROM $table WHERE category LIKE %s AND enabled = %d",
				'WooCommerce%', 1
			));
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$total_tokens = $wpdb->get_var($wpdb->prepare(
				"SELECT COALESCE(SUM(token_estimate),0) FROM $table WHERE category NOT LIKE %s AND category NOT LIKE %s AND enabled = %d",
				'WooCommerce%', 'Plugins - %', 1
			));
		}
		
		wp_send_json_success(array(
			'enabled' => $new_status,
			'total_tokens' => number_format_i18n(intval($total_tokens))
		));
	}

	/**
	 * Render Abilities Tab - WordPress 6.9+ Abilities API Integration
	 */
	private function renderAbilitiesTab() {
		?>
		<h2><?php echo esc_html__('🔮 WordPress Abilities (6.9+)', 'stifli-flex-mcp'); ?></h2>
		<p class="description">
			<?php echo esc_html__('Discover and import abilities from other WordPress plugins. Imported abilities are exposed as MCP tools for AI agents.', 'stifli-flex-mcp'); ?>
		</p>

		<div class="sflmcp-abilities-container">
			<!-- Left Panel: Discover Abilities -->
			<div class="sflmcp-abilities-discover">
				<h3>
					<?php echo esc_html__('🔍 Discover Available Abilities', 'stifli-flex-mcp'); ?>
				</h3>
				<p class="description">
					<?php echo esc_html__('Scan your WordPress installation for registered abilities from other plugins.', 'stifli-flex-mcp'); ?>
				</p>
				<button type="button" id="sflmcp-discover-abilities" class="button button-primary">
					<?php echo esc_html__('Discover Abilities', 'stifli-flex-mcp'); ?>
				</button>
				
				<div id="sflmcp-discovered-abilities">
					<!-- Discovered abilities will be loaded here via AJAX -->
				</div>
			</div>

			<!-- Right Panel: Imported Abilities -->
			<div class="sflmcp-abilities-imported">
				<h3>
					<?php echo esc_html__('✅ Imported Abilities', 'stifli-flex-mcp'); ?>
				</h3>
				<p class="description">
					<?php echo esc_html__('These abilities are exposed as MCP tools and available to AI agents.', 'stifli-flex-mcp'); ?>
				</p>
				
				<div id="sflmcp-imported-abilities">
					<?php $this->renderImportedAbilitiesList(); ?>
				</div>
			</div>
		</div>

		<div class="sflmcp-abilities-info">
			<strong><?php echo esc_html__('How it works:', 'stifli-flex-mcp'); ?></strong>
			<ol>
				<li><?php echo esc_html__('Install plugins that register WordPress Abilities (e.g., All Sources Images)', 'stifli-flex-mcp'); ?></li>
				<li><?php echo esc_html__('Click "Discover Abilities" to find available abilities', 'stifli-flex-mcp'); ?></li>
				<li><?php echo esc_html__('Import the abilities you want to expose to AI agents', 'stifli-flex-mcp'); ?></li>
				<li><?php echo esc_html__('AI agents can now use these abilities via MCP', 'stifli-flex-mcp'); ?></li>
			</ol>
		</div>
		<?php
	}

	/**
	 * Render the list of imported abilities
	 */
	private function renderImportedAbilitiesList() {
		global $wpdb;
		$table = $wpdb->prefix . 'sflmcp_abilities';
		
		// Check if table exists
		$like = $wpdb->esc_like($table);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- schema check.
		if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $like)) !== $table) {
			echo '<p>' . esc_html__('Abilities table not initialized. Please deactivate and reactivate the plugin.', 'stifli-flex-mcp') . '</p>';
			return;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- fresh data needed.
		$abilities = $wpdb->get_results("SELECT * FROM {$table} ORDER BY ability_category, ability_label");
		
		if (empty($abilities)) {
			echo '<p class="sflmcp-empty-msg">' . esc_html__('No abilities imported yet. Use the Discover button to find and import abilities.', 'stifli-flex-mcp') . '</p>';
			return;
		}

		echo '<div class="tablenav top sflmcp-abilities-bulk-toolbar">';
		echo '<div class="alignleft actions bulkactions">';
		echo '<label class="screen-reader-text" for="sflmcp-imported-bulk-action">' . esc_html__('Select bulk action', 'stifli-flex-mcp') . '</label>';
		echo '<select id="sflmcp-imported-bulk-action">';
		echo '<option value="">' . esc_html__('Bulk actions', 'stifli-flex-mcp') . '</option>';
		echo '<option value="enable">' . esc_html__('Enable selected', 'stifli-flex-mcp') . '</option>';
		echo '<option value="disable">' . esc_html__('Disable selected', 'stifli-flex-mcp') . '</option>';
		echo '<option value="delete">' . esc_html__('Remove selected', 'stifli-flex-mcp') . '</option>';
		echo '</select>';
		echo '<button type="button" class="button action" id="sflmcp-apply-imported-bulk-action">' . esc_html__('Apply', 'stifli-flex-mcp') . '</button>';
		echo '</div>';
		echo '<div class="tablenav-pages one-page">';
		echo '<span class="displaying-num"><span id="sflmcp-imported-selected-count">0</span> ' . esc_html__('selected', 'stifli-flex-mcp') . '</span>';
		echo '</div>';
		echo '</div>';

		echo '<table class="widefat striped sflmcp-imported-abilities-table">';
		echo '<thead><tr>';
		echo '<td class="check-column"><input type="checkbox" class="sflmcp-select-all-imported" aria-label="' . esc_attr__('Select all imported abilities', 'stifli-flex-mcp') . '"></td>';
		echo '<th scope="col"><button type="button" class="button-link sflmcp-sort-button" data-sort-key="label" data-sort-type="text">' . esc_html__('Ability', 'stifli-flex-mcp') . '<span class="dashicons dashicons-sort"></span></button></th>';
		echo '<th scope="col"><button type="button" class="button-link sflmcp-sort-button" data-sort-key="category" data-sort-type="text">' . esc_html__('Category', 'stifli-flex-mcp') . '<span class="dashicons dashicons-sort"></span></button></th>';
		echo '<th scope="col" class="sflmcp-logs-col-enabled"><button type="button" class="button-link sflmcp-sort-button" data-sort-key="enabled" data-sort-type="number">' . esc_html__('Enabled', 'stifli-flex-mcp') . '<span class="dashicons dashicons-sort"></span></button></th>';
		echo '<th scope="col" class="sflmcp-logs-col-enabled">' . esc_html__('Actions', 'stifli-flex-mcp') . '</th>';
		echo '</tr></thead><tbody>';

		foreach ($abilities as $ability) {
			$enabled_class = $ability->enabled ? 'dashicons-yes-alt' : 'dashicons-marker';
			$enabled_color = $ability->enabled ? '#46b450' : '#dc3232';
			$tool_name = 'ability_' . str_replace(array('/', '-'), '_', $ability->ability_name);
			/* translators: %s: ability label */
			$select_ability_aria = sprintf( __( 'Select %s', 'stifli-flex-mcp' ), $ability->ability_label );
			
			echo '<tr data-ability-id="' . esc_attr($ability->id) . '" data-ability-name="' . esc_attr($ability->ability_name) . '" data-sort-label="' . esc_attr(strtolower($ability->ability_label)) . '" data-sort-category="' . esc_attr(strtolower($ability->ability_category)) . '" data-sort-enabled="' . esc_attr((int) $ability->enabled) . '">';
			echo '<th scope="row" class="check-column">';
			echo '<input type="checkbox" class="sflmcp-imported-select-row" value="' . esc_attr($ability->id) . '" aria-label="' . esc_attr( $select_ability_aria ) . '">';
			echo '</th>';
			echo '<td>';
			echo '<strong>' . esc_html($ability->ability_label) . '</strong>';
			echo '<br><code class="sflmcp-ability-tool-name">' . esc_html($tool_name) . '</code>';
			if (!empty($ability->ability_description)) {
				echo '<br><small class="sflmcp-ability-desc">' . esc_html(wp_trim_words($ability->ability_description, 15)) . '</small>';
			}
			echo '</td>';
			echo '<td>' . esc_html($ability->ability_category) . '</td>';
			echo '<td class="sflmcp-td-center">';
			echo '<button type="button" class="button-link sflmcp-toggle-ability" data-id="' . esc_attr($ability->id) . '" data-enabled="' . esc_attr($ability->enabled) . '" title="' . esc_attr__('Toggle enabled', 'stifli-flex-mcp') . '">';
			echo '<span class="dashicons ' . esc_attr($enabled_class) . '" class="sflmcp-ability-status-icon"></span>';
			echo '</button>';
			echo '</td>';
			echo '<td class="sflmcp-td-center">';
			echo '<button type="button" class="button-link sflmcp-delete-ability" data-id="' . esc_attr($ability->id) . '" title="' . esc_attr__('Remove ability', 'stifli-flex-mcp') . '">';
			echo '<span class="dashicons dashicons-trash" class="sflmcp-ability-delete-icon"></span>';
			echo '</button>';
			echo '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}

	/**
	 * Normalize an ability category label.
	 *
	 * @param mixed $ability_or_category Ability instance or raw category value.
	 * @return string
	 */
	private function getAbilityCategoryLabel( $ability_or_category ) {
		$category = $ability_or_category;

		if ( is_object( $ability_or_category ) && method_exists( $ability_or_category, 'get_category' ) ) {
			$category = $ability_or_category->get_category();
		}

		if ( is_object( $category ) && method_exists( $category, 'get_label' ) ) {
			$category = $category->get_label();
		}

		if ( is_scalar( $category ) ) {
			$category = sanitize_text_field( (string) $category );
		} else {
			$category = '';
		}

		return '' !== $category ? $category : __( 'Uncategorized', 'stifli-flex-mcp' );
	}

	/**
	 * Import a single registered WordPress ability into the plugin table.
	 *
	 * @param string $ability_name Ability slug.
	 * @return int|WP_Error
	 */
	private function importAbilityRecord( $ability_name ) {
		if ( ! stifli_flex_mcp_abilities_available() || ! function_exists( 'stifli_flex_mcp_get_ability_safe' ) ) {
			return new WP_Error( 'abilities_unavailable', __( 'WordPress Abilities API not available', 'stifli-flex-mcp' ) );
		}

		$ability = stifli_flex_mcp_get_ability_safe( $ability_name );
		if ( ! $ability ) {
			return new WP_Error( 'ability_not_found', __( 'Ability not found', 'stifli-flex-mcp' ) );
		}

		global $wpdb;
		$table = $wpdb->prefix . 'sflmcp_abilities';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE ability_name = %s", $ability_name ) );
		if ( $exists ) {
			return new WP_Error( 'ability_exists', __( 'Ability already imported', 'stifli-flex-mcp' ) );
		}

		$input_schema  = StifliFlexMcpUtils::normalizeToolInputSchema( $ability->get_input_schema() );
		$output_schema = $ability->get_output_schema();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$result = $wpdb->insert(
			$table,
			array(
				'ability_name'        => $ability_name,
				'ability_label'       => $ability->get_label(),
				'ability_description' => $ability->get_description(),
				'ability_category'    => $this->getAbilityCategoryLabel( $ability ),
				'input_schema'        => is_array( $input_schema ) ? wp_json_encode( $input_schema ) : null,
				'output_schema'       => is_array( $output_schema ) ? wp_json_encode( $output_schema ) : null,
				'enabled'             => 1,
				'created_at'          => current_time( 'mysql', true ),
				'updated_at'          => current_time( 'mysql', true ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		);

		if ( false === $result ) {
			return new WP_Error( 'ability_insert_failed', __( 'Failed to import ability', 'stifli-flex-mcp' ) );
		}

		return (int) $wpdb->insert_id;
	}

	/**
	 * AJAX handler: Discover available WordPress Abilities
	 */
	public function ajax_discover_abilities() {
		check_ajax_referer('sflmcp_abilities', 'nonce');

		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied', 'stifli-flex-mcp')));
		}

		if (!stifli_flex_mcp_abilities_available()) {
			wp_send_json_error(array('message' => __('WordPress Abilities API not available. Requires WordPress 6.9+', 'stifli-flex-mcp')));
		}

		$all_abilities = function_exists( 'stifli_flex_mcp_get_abilities_safe' )
			? stifli_flex_mcp_get_abilities_safe()
			: array();
		if (empty($all_abilities)) {
			wp_send_json_success(array(
				'abilities' => array(),
				'message' => __('No abilities found. Install plugins that register WordPress Abilities.', 'stifli-flex-mcp'),
			));
			return;
		}

		// Get already imported abilities
		global $wpdb;
		$table = $wpdb->prefix . 'sflmcp_abilities';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$imported = $wpdb->get_col("SELECT ability_name FROM {$table}");
		$imported_map = array_flip($imported);

		$abilities_list = array();
		foreach ($all_abilities as $ability) {
			$name = $ability->get_name();
			
			// Skip our own abilities if we ever register any
			if (strpos($name, 'sflmcp/') === 0) {
				continue;
			}

			// Get category - may be a string or null
			$abilities_list[] = array(
				'name' => $name,
				'label' => $ability->get_label(),
				'description' => $ability->get_description(),
				'category' => $this->getAbilityCategoryLabel( $ability ),
				'input_schema' => $ability->get_input_schema(),
				'output_schema' => method_exists($ability, 'get_output_schema') ? $ability->get_output_schema() : null,
				'imported' => isset($imported_map[$name]),
			);
		}

		wp_send_json_success(array(
			'abilities' => $abilities_list,
			'count' => count($abilities_list),
		));
	}

	/**
	 * AJAX handler: Import an ability
	 */
	public function ajax_import_ability() {
		check_ajax_referer('sflmcp_abilities', 'nonce');

		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied', 'stifli-flex-mcp')));
		}

		$ability_name = isset($_POST['ability_name']) ? sanitize_text_field(wp_unslash($_POST['ability_name'])) : '';
		if (empty($ability_name)) {
			wp_send_json_error(array('message' => __('Ability name is required', 'stifli-flex-mcp')));
		}

		if (!stifli_flex_mcp_abilities_available()) {
			wp_send_json_error(array('message' => __('WordPress Abilities API not available', 'stifli-flex-mcp')));
		}

		$result = $this->importAbilityRecord( $ability_name );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error(array('message' => $result->get_error_message()));
		}

		wp_send_json_success(array(
			'message' => __('Ability imported successfully', 'stifli-flex-mcp'),
			'id' => $result,
		));
	}

	/**
	 * AJAX handler: Bulk manage imported or discovered abilities.
	 */
	public function ajax_bulk_manage_abilities() {
		check_ajax_referer( 'sflmcp_abilities', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'stifli-flex-mcp' ) ) );
		}

		$bulk_action = isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( $_POST['bulk_action'] ) ) : '';
		if ( empty( $bulk_action ) ) {
			wp_send_json_error( array( 'message' => __( 'Bulk action is required', 'stifli-flex-mcp' ) ) );
		}

		$ability_ids = array();
		if ( isset( $_POST['ability_ids'] ) ) {
			$ability_ids = array_values( array_unique( array_filter( array_map( 'intval', (array) wp_unslash( $_POST['ability_ids'] ) ) ) ) );
		}

		$ability_names = array();
		if ( isset( $_POST['ability_names'] ) ) {
			$ability_names = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['ability_names'] ) ) ) ) );
		}

		global $wpdb;
		$table = $wpdb->prefix . 'sflmcp_abilities';

		switch ( $bulk_action ) {
			case 'enable':
			case 'disable':
				if ( empty( $ability_ids ) ) {
					wp_send_json_error( array( 'message' => __( 'Select at least one imported ability.', 'stifli-flex-mcp' ) ) );
				}

				$new_state = 'enable' === $bulk_action ? 1 : 0;
				$updated   = 0;
				$timestamp = current_time( 'mysql', true );

				foreach ( $ability_ids as $ability_id ) {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
					$row_result = $wpdb->update(
						$table,
						array(
							'enabled'    => $new_state,
							'updated_at' => $timestamp,
						),
						array( 'id' => $ability_id ),
						array( '%d', '%s' ),
						array( '%d' )
					);

					if ( false === $row_result ) {
						wp_send_json_error( array( 'message' => __( 'Failed to update abilities', 'stifli-flex-mcp' ) ) );
					}

					$updated += (int) $row_result;
				}

				wp_send_json_success( array(
					'updated' => (int) $updated,
					'message' => 'enable' === $bulk_action
						? __( 'Selected abilities enabled', 'stifli-flex-mcp' )
						: __( 'Selected abilities disabled', 'stifli-flex-mcp' ),
				) );
				break;

			case 'delete':
				if ( empty( $ability_ids ) ) {
					wp_send_json_error( array( 'message' => __( 'Select at least one imported ability.', 'stifli-flex-mcp' ) ) );
				}

				$deleted = 0;
				foreach ( $ability_ids as $ability_id ) {
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
					$row_result = $wpdb->delete( $table, array( 'id' => $ability_id ), array( '%d' ) );

					if ( false === $row_result ) {
						wp_send_json_error( array( 'message' => __( 'Failed to delete abilities', 'stifli-flex-mcp' ) ) );
					}

					$deleted += (int) $row_result;
				}

				wp_send_json_success( array(
					'deleted' => (int) $deleted,
					'message' => __( 'Selected abilities removed', 'stifli-flex-mcp' ),
				) );
				break;

			case 'import':
				if ( empty( $ability_names ) ) {
					wp_send_json_error( array( 'message' => __( 'Select at least one discovered ability.', 'stifli-flex-mcp' ) ) );
				}

				$imported_count = 0;
				$skipped_count  = 0;
				$processed_names = array();
				$errors         = array();

				foreach ( $ability_names as $ability_name ) {
					$result = $this->importAbilityRecord( $ability_name );
					if ( is_wp_error( $result ) ) {
						if ( 'ability_exists' === $result->get_error_code() ) {
							++$skipped_count;
							$processed_names[] = $ability_name;
							continue;
						}

						$errors[] = $result->get_error_message();
						continue;
					}

					++$imported_count;
					$processed_names[] = $ability_name;
				}

				if ( 0 === $imported_count && ! empty( $errors ) ) {
					wp_send_json_error( array( 'message' => $errors[0] ) );
				}

				/* translators: %d: number of imported abilities. */
				$imported_message = sprintf( __( '%d abilities imported', 'stifli-flex-mcp' ), $imported_count );
				$message = $imported_count > 0
					? $imported_message
					: __( 'No new abilities were imported', 'stifli-flex-mcp' );

				wp_send_json_success( array(
					'imported'        => $imported_count,
					'skipped'         => $skipped_count,
					'processed_names' => $processed_names,
					'errors'          => $errors,
					'message'         => $message,
				) );
				break;

			default:
				wp_send_json_error( array( 'message' => __( 'Invalid bulk action', 'stifli-flex-mcp' ) ) );
		}
	}

	/**
	 * AJAX handler: Toggle ability enabled state
	 */
	public function ajax_toggle_ability() {
		check_ajax_referer('sflmcp_abilities', 'nonce');

		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied', 'stifli-flex-mcp')));
		}

		$ability_id = isset($_POST['ability_id']) ? intval($_POST['ability_id']) : 0;
		if ($ability_id <= 0) {
			wp_send_json_error(array('message' => __('Invalid ability ID', 'stifli-flex-mcp')));
		}

		global $wpdb;
		$table = $wpdb->prefix . 'sflmcp_abilities';

		// Get current state
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$current = $wpdb->get_var($wpdb->prepare("SELECT enabled FROM {$table} WHERE id = %d", $ability_id));
		if ($current === null) {
			wp_send_json_error(array('message' => __('Ability not found', 'stifli-flex-mcp')));
		}

		$new_state = $current ? 0 : 1;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->update(
			$table,
			array('enabled' => $new_state, 'updated_at' => current_time('mysql', true)),
			array('id' => $ability_id),
			array('%d', '%s'),
			array('%d')
		);

		wp_send_json_success(array(
			'enabled' => $new_state,
			'message' => $new_state ? __('Ability enabled', 'stifli-flex-mcp') : __('Ability disabled', 'stifli-flex-mcp'),
		));
	}

	/**
	 * AJAX handler: Delete an imported ability
	 */
	public function ajax_delete_ability() {
		check_ajax_referer('sflmcp_abilities', 'nonce');

		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied', 'stifli-flex-mcp')));
		}

		$ability_id = isset($_POST['ability_id']) ? intval($_POST['ability_id']) : 0;
		if ($ability_id <= 0) {
			wp_send_json_error(array('message' => __('Invalid ability ID', 'stifli-flex-mcp')));
		}

		global $wpdb;
		$table = $wpdb->prefix . 'sflmcp_abilities';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$result = $wpdb->delete($table, array('id' => $ability_id), array('%d'));

		if ($result === false) {
			wp_send_json_error(array('message' => __('Failed to delete ability', 'stifli-flex-mcp')));
		}

		wp_send_json_success(array('message' => __('Ability removed', 'stifli-flex-mcp')));
	}

	/**
	 * AJAX handler: Get imported abilities list (for refresh)
	 */
	public function ajax_get_imported_abilities() {
		check_ajax_referer('sflmcp_abilities', 'nonce');

		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => __('Permission denied', 'stifli-flex-mcp')));
		}

		ob_start();
		$this->renderImportedAbilitiesList();
		$html = ob_get_clean();

		wp_send_json_success(array('html' => $html));
	}

	/**
	 * Enqueue assets for the Multimedia submenu page.
	 */
	private function enqueueMultimediaAssets() {
		$asset_version = defined( 'SFLMCP_VERSION' ) ? SFLMCP_VERSION : '3.5.4';
		wp_enqueue_style(
			'sflmcp-admin-multimedia',
			plugin_dir_url(__FILE__) . 'assets/admin-multimedia.css',
			array(),
			$asset_version
		);
		wp_enqueue_script(
			'sflmcp-admin-multimedia',
			plugin_dir_url(__FILE__) . 'assets/admin-multimedia.js',
			array('jquery'),
			$asset_version,
			true
		);
		wp_localize_script('sflmcp-admin-multimedia', 'sflmcpMultimedia', array(
			'ajaxUrl' => admin_url('admin-ajax.php'),
			'nonce'   => wp_create_nonce('sflmcp_multimedia'),
			'i18n'    => array(
				'saving'   => __('Saving...', 'stifli-flex-mcp'),
				'saved'    => __('Saved', 'stifli-flex-mcp'),
				'error'    => __('Error saving settings', 'stifli-flex-mcp'),
				'loaded'   => __('Settings loaded', 'stifli-flex-mcp'),
				'enabled'  => __('Enabled', 'stifli-flex-mcp'),
				'disabled' => __('Disabled', 'stifli-flex-mcp'),
			),
		));
	}

	/**
	 * Render the Multimedia admin page (standalone submenu).
	 */
	public function multimediaPage() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'stifli-flex-mcp' ) );
		}
		$active_tab = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : 'images'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Multimedia Settings', 'stifli-flex-mcp' ); ?></h1>
			<h2 class="nav-tab-wrapper">
				<a href="?page=sflmcp-multimedia&tab=images" class="nav-tab <?php echo $active_tab === 'images' ? 'nav-tab-active' : ''; ?>">
					🖼️ <?php esc_html_e( 'Images', 'stifli-flex-mcp' ); ?>
				</a>
				<a href="?page=sflmcp-multimedia&tab=search-image" class="nav-tab <?php echo $active_tab === 'search-image' ? 'nav-tab-active' : ''; ?>">
					<span class="dashicons dashicons-search"></span> <?php esc_html_e( 'Search Image', 'stifli-flex-mcp' ); ?>
				</a>
				<a href="?page=sflmcp-multimedia&tab=videos" class="nav-tab <?php echo $active_tab === 'videos' ? 'nav-tab-active' : ''; ?>">
					🎬 <?php esc_html_e( 'Videos', 'stifli-flex-mcp' ); ?>
				</a>
			</h2>
			<?php
			if ( $active_tab === 'videos' ) {
				$this->renderVideoSettingsTab();
			} elseif ( $active_tab === 'search-image' ) {
				$this->renderSearchImageSettingsTab();
			} else {
				$this->renderMultimediaTab();
			}
			?>
		</div>
		<?php
	}

	/**
	 * Get multimedia settings with defaults.
	 *
	 * @return array Settings array merged with defaults.
	 */
	private function getMultimediaSettings() {
		$defaults = array(
			'image_provider'       => 'openai',
			// OpenAI image settings
			'openai_api_key'       => '',
			'openai_model'         => 'gpt-image-1',
			'openai_quality'       => 'medium',
			'openai_size'          => 'square',
			'openai_style'         => 'natural',
			'openai_background'    => 'auto',
			'openai_output_format' => 'png',
			// Gemini image settings
			'gemini_api_key'       => '',
			'gemini_model'         => 'gemini-2.5-flash-image',
			'gemini_aspect_ratio'  => '1:1',
			// Post-processing
			'pp_enabled'           => '1',
			'pp_max_width'         => 1024,
			'pp_max_height'        => 1024,
			'pp_quality'           => 80,
			'pp_format'            => 'original',
			// Video settings
			'video_provider'       => 'gemini',
			'video_gemini_model'   => 'veo-3.0-generate-preview',
			'video_openai_model'   => 'sora-2',
			'video_duration'       => '5',
			'video_aspect_ratio'   => '16:9',
			'video_resolution'     => '720p',
			'video_poll_interval'  => 10,
			'video_max_wait'       => 300,
			// Search Image settings
			'search_image_preferred_bank' => 'random',
			'search_image_selection'      => 'most_relevant',
			'search_image_orientation'    => 'any',
			'search_image_safe_search'    => '1',
			'search_image_language'       => 'en',
			'search_image_locale'         => 'en-US',
			'search_image_timeout'        => 20,
			'search_image_unsplash_enabled' => '0',
			'search_image_unsplash_api_key' => '',
			'search_image_pexels_enabled'   => '0',
			'search_image_pexels_api_key'   => '',
			'search_image_pixabay_enabled'  => '0',
			'search_image_pixabay_api_key'  => '',
		);
		$saved = get_option( 'sflmcp_multimedia_settings', array() );
		return wp_parse_args( $saved, $defaults );
	}

	/**
	 * Create a partial display mask for an encrypted API key.
	 *
	 * Decrypts the stored key, then returns a masked version showing the first
	 * few characters and last 4, with bullets in between matching the real length.
	 * Example: "sk-proj-••••••••••••••••abcd"
	 *
	 * @param string $encrypted_value The encrypted (or empty) key from settings.
	 * @return string Partial mask for display, or empty string if no key stored.
	 */
	private function maskApiKeyForDisplay( $encrypted_value ) {
		if ( empty( $encrypted_value ) ) {
			return '';
		}

		// Decrypt to get real key
		$plain = '';
		if ( class_exists( 'StifliFlexMcp_Client_Admin' ) ) {
			$plain = StifliFlexMcp_Client_Admin::decrypt_value( $encrypted_value );
		} else {
			$plain = $encrypted_value;
		}

		if ( empty( $plain ) ) {
			return '';
		}

		$len = strlen( $plain );

		// Very short keys: just show bullets
		if ( $len <= 8 ) {
			return str_repeat( '•', $len );
		}

		// Show first 4 chars + bullets + last 4 chars
		$prefix    = substr( $plain, 0, 4 );
		$suffix    = substr( $plain, -4 );
		$mid_count = max( 4, $len - 8 );
		return $prefix . str_repeat( '•', $mid_count ) . $suffix;
	}

	/**
	 * Render Multimedia Settings Tab
	 */
	private function renderMultimediaTab() {
		$s       = $this->getMultimediaSettings();
		$has_gd  = extension_loaded( 'gd' );
		$gd_info = $has_gd ? gd_info() : array();

		// Build partial display strings for API keys (e.g. "sk-••••••••xxxx")
		$openai_display = $this->maskApiKeyForDisplay( $s['openai_api_key'] );
		$gemini_display = $this->maskApiKeyForDisplay( $s['gemini_api_key'] );

		?>
		<div class="sflmcp-multimedia-wrap">

			<!-- ─── Tool Enable/Disable ─────────────────────── -->
			<div class="sflmcp-tool-toggle-banner" data-tool="wp_generate_image">
				<label class="sflmcp-toggle-switch">
					<input type="checkbox" id="sflmcp_mm_tool_image_toggle" class="sflmcp-mm-tool-toggle" data-tool="wp_generate_image">
					<span class="sflmcp-toggle-slider"></span>
				</label>
				<span class="sflmcp-toggle-label">
					<strong>wp_generate_image</strong> — <?php esc_html_e( 'Enable this tool for MCP clients and AI agents', 'stifli-flex-mcp' ); ?>
				</span>
				<span class="sflmcp-toggle-status"></span>
			</div>
			<p class="description sflmcp-pricing-notice">
				<span class="dashicons dashicons-info" class="sflmcp-pricing-icon"></span>
				<?php esc_html_e( 'Approximate price per image (may change): OpenAI GPT Image 2: ~$0.005-$0.211, GPT Image 1.5: ~$0.009-$0.200, GPT Image 1: ~$0.011-$0.250, GPT Image 1 Mini: ~$0.005-$0.052. Gemini 2.5 Flash Image: ~$0.039 (1K), Gemini 3.1 Flash Image Preview: ~$0.045 (0.5K), $0.067 (1K), $0.101 (2K), $0.151 (4K), Gemini 3 Pro Image Preview: ~$0.134 (1K/2K), $0.24 (4K). Imagen 4: Fast $0.02, Standard $0.04, Ultra $0.06.', 'stifli-flex-mcp' ); ?>
			</p>

			<h2><?php esc_html_e( 'Image Generation Settings', 'stifli-flex-mcp' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Configure defaults for AI image generation (wp_generate_image tool). These settings are used when generating images via MCP tools or the Chat Agent. Tool arguments can override size and quality per-request.', 'stifli-flex-mcp' ); ?>
			</p>

			<div id="sflmcp-mm-notice" class="sflmcp-mm-notice"></div>

			<form id="sflmcp-multimedia-form">

				<!-- ─── Image Provider ───────────────────────────── -->
				<div class="card">
					<h3>🖼️ <?php esc_html_e( 'Image Generation Provider', 'stifli-flex-mcp' ); ?></h3>
					<p class="description"><?php esc_html_e( 'Select which AI provider to use for image generation. Each provider has its own API key and configuration.', 'stifli-flex-mcp' ); ?></p>

					<input type="hidden" id="sflmcp_mm_image_provider" name="image_provider" value="<?php echo esc_attr( $s['image_provider'] ); ?>">

					<div class="sflmcp-provider-tabs">
						<div class="sflmcp-provider-tab <?php echo $s['image_provider'] === 'openai' ? 'active' : ''; ?>" data-provider="openai">
							<span class="dashicons dashicons-format-image"></span> OpenAI
						</div>
						<div class="sflmcp-provider-tab <?php echo $s['image_provider'] === 'gemini' ? 'active' : ''; ?>" data-provider="gemini">
							<span class="dashicons dashicons-admin-customizer"></span> Gemini
						</div>
					</div>
				</div>

				<!-- ─── OpenAI Settings ──────────────────────────── -->
				<div id="sflmcp-panel-openai" class="sflmcp-provider-panel card<?php echo $s['image_provider'] !== 'openai' ? ' sflmcp-hidden' : ''; ?>">
					<h3><span class="dashicons dashicons-format-image"></span> <?php esc_html_e( 'OpenAI Image Settings', 'stifli-flex-mcp' ); ?></h3>

					<table class="form-table">
						<tr>
							<th><?php esc_html_e( 'API Key', 'stifli-flex-mcp' ); ?></th>
							<td>
								<div class="sflmcp-api-key-field">
									<input type="password" id="sflmcp_mm_openai_key" class="sflmcp-shared-apikey" data-key="openai_api_key" value="<?php echo esc_attr( $openai_display ); ?>" placeholder="sk-..." autocomplete="off">
									<button type="button" class="button sflmcp-api-key-toggle" title="<?php esc_attr_e( 'Toggle visibility', 'stifli-flex-mcp' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
								</div>
								<p class="sflmcp-field-desc">
									<?php esc_html_e( 'Shared OpenAI key for image and video generation. Independent from Chat Agent settings.', 'stifli-flex-mcp' ); ?>
								</p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Model', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_openai_model">
									<option value="gpt-image-1" <?php selected( $s['openai_model'], 'gpt-image-1' ); ?>>gpt-image-1 (<?php esc_html_e( 'Default, balanced quality/cost', 'stifli-flex-mcp' ); ?>)</option>
									<option value="gpt-image-1.5" <?php selected( $s['openai_model'], 'gpt-image-1.5' ); ?>>gpt-image-1.5 (<?php esc_html_e( 'Improved quality/cost', 'stifli-flex-mcp' ); ?>)</option>
									<option value="gpt-image-2" <?php selected( $s['openai_model'], 'gpt-image-2' ); ?>>gpt-image-2 (<?php esc_html_e( 'Latest, state-of-the-art', 'stifli-flex-mcp' ); ?>)</option>
									<option value="gpt-image-1-mini" <?php selected( $s['openai_model'], 'gpt-image-1-mini' ); ?>>gpt-image-1-mini (<?php esc_html_e( 'Lower cost', 'stifli-flex-mcp' ); ?>)</option>
									<option value="dall-e-3" <?php selected( $s['openai_model'], 'dall-e-3' ); ?>>DALL·E 3 (<?php esc_html_e( 'Legacy fallback', 'stifli-flex-mcp' ); ?>)</option>
									<option value="dall-e-2" <?php selected( $s['openai_model'], 'dall-e-2' ); ?>>DALL·E 2 (<?php esc_html_e( 'Legacy', 'stifli-flex-mcp' ); ?>)</option>
								</select>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Default Quality', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_openai_quality">
									<option value="low" <?php selected( $s['openai_quality'], 'low' ); ?>><?php esc_html_e( 'Low (fastest, cheapest)', 'stifli-flex-mcp' ); ?></option>
									<option value="medium" <?php selected( $s['openai_quality'], 'medium' ); ?>><?php esc_html_e( 'Medium (balanced)', 'stifli-flex-mcp' ); ?></option>
									<option value="high" <?php selected( $s['openai_quality'], 'high' ); ?>><?php esc_html_e( 'High (best quality, slowest)', 'stifli-flex-mcp' ); ?></option>
								</select>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Default Size', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_openai_size">
									<option value="square" <?php selected( $s['openai_size'], 'square' ); ?>><?php esc_html_e( 'Square (1024×1024)', 'stifli-flex-mcp' ); ?></option>
									<option value="landscape" <?php selected( $s['openai_size'], 'landscape' ); ?>><?php esc_html_e( 'Landscape (1536×1024)', 'stifli-flex-mcp' ); ?></option>
									<option value="portrait" <?php selected( $s['openai_size'], 'portrait' ); ?>><?php esc_html_e( 'Portrait (1024×1536)', 'stifli-flex-mcp' ); ?></option>
								</select>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'The tool can override this per-request via the "size" argument.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Style', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_openai_style">
									<option value="natural" <?php selected( $s['openai_style'], 'natural' ); ?>><?php esc_html_e( 'Natural (photorealistic)', 'stifli-flex-mcp' ); ?></option>
									<option value="vivid" <?php selected( $s['openai_style'], 'vivid' ); ?>><?php esc_html_e( 'Vivid (hyper-real, dramatic)', 'stifli-flex-mcp' ); ?></option>
								</select>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Only applies to DALL·E 3.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Background', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_openai_background">
									<option value="auto" <?php selected( $s['openai_background'], 'auto' ); ?>><?php esc_html_e( 'Auto', 'stifli-flex-mcp' ); ?></option>
									<option value="transparent" <?php selected( $s['openai_background'], 'transparent' ); ?>><?php esc_html_e( 'Transparent', 'stifli-flex-mcp' ); ?></option>
									<option value="opaque" <?php selected( $s['openai_background'], 'opaque' ); ?>><?php esc_html_e( 'Opaque', 'stifli-flex-mcp' ); ?></option>
								</select>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Applies to GPT Image models. Note: gpt-image-2 does not support transparent background.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Output Format', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_openai_format">
									<option value="png" <?php selected( $s['openai_output_format'], 'png' ); ?>>PNG (<?php esc_html_e( 'lossless, supports transparency', 'stifli-flex-mcp' ); ?>)</option>
									<option value="jpeg" <?php selected( $s['openai_output_format'], 'jpeg' ); ?>>JPEG (<?php esc_html_e( 'smaller file, no transparency', 'stifli-flex-mcp' ); ?>)</option>
									<option value="webp" <?php selected( $s['openai_output_format'], 'webp' ); ?>>WebP (<?php esc_html_e( 'modern, best compression', 'stifli-flex-mcp' ); ?>)</option>
								</select>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Applies to GPT Image models. DALL·E models always return PNG.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<!-- ─── Gemini Settings ──────────────────────────── -->
				<div id="sflmcp-panel-gemini" class="sflmcp-provider-panel card<?php echo $s['image_provider'] !== 'gemini' ? ' sflmcp-hidden' : ''; ?>">
					<h3><span class="dashicons dashicons-admin-customizer"></span> <?php esc_html_e( 'Gemini Image Settings', 'stifli-flex-mcp' ); ?></h3>

					<table class="form-table">
						<tr>
							<th><?php esc_html_e( 'API Key', 'stifli-flex-mcp' ); ?></th>
							<td>
								<div class="sflmcp-api-key-field">
									<input type="password" id="sflmcp_mm_gemini_key" class="sflmcp-shared-apikey" data-key="gemini_api_key" value="<?php echo esc_attr( $gemini_display ); ?>" placeholder="AIza..." autocomplete="off">
									<button type="button" class="button sflmcp-api-key-toggle" title="<?php esc_attr_e( 'Toggle visibility', 'stifli-flex-mcp' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
								</div>
								<p class="sflmcp-field-desc">
									<?php esc_html_e( 'Shared Gemini key for image and video generation. Independent from Chat Agent settings.', 'stifli-flex-mcp' ); ?>
								</p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Model', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_gemini_model">
									<option value="gemini-2.5-flash-image" <?php selected( $s['gemini_model'], 'gemini-2.5-flash-image' ); ?>>gemini-2.5-flash-image (<?php esc_html_e( 'Default, best value for speed/cost', 'stifli-flex-mcp' ); ?>)</option>
									<option value="gemini-3.1-flash-image-preview" <?php selected( $s['gemini_model'], 'gemini-3.1-flash-image-preview' ); ?>>gemini-3.1-flash-image-preview (<?php esc_html_e( 'Latest image model (preview)', 'stifli-flex-mcp' ); ?>)</option>
									<option value="gemini-3-pro-image-preview" <?php selected( $s['gemini_model'], 'gemini-3-pro-image-preview' ); ?>>gemini-3-pro-image-preview (<?php esc_html_e( 'Highest quality (preview)', 'stifli-flex-mcp' ); ?>)</option>
									<option value="imagen-4.0-generate-001" <?php selected( $s['gemini_model'], 'imagen-4.0-generate-001' ); ?>>Imagen 4 Standard (<?php esc_html_e( 'High fidelity', 'stifli-flex-mcp' ); ?>)</option>
									<option value="imagen-4.0-fast-generate-001" <?php selected( $s['gemini_model'], 'imagen-4.0-fast-generate-001' ); ?>>Imagen 4 Fast (<?php esc_html_e( 'Fastest', 'stifli-flex-mcp' ); ?>)</option>
									<option value="imagen-4.0-ultra-generate-001" <?php selected( $s['gemini_model'], 'imagen-4.0-ultra-generate-001' ); ?>>Imagen 4 Ultra (<?php esc_html_e( 'Best quality', 'stifli-flex-mcp' ); ?>)</option>
								</select>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Default Aspect Ratio', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_gemini_aspect">
									<option value="1:1" <?php selected( $s['gemini_aspect_ratio'], '1:1' ); ?>>1:1 (<?php esc_html_e( 'Square', 'stifli-flex-mcp' ); ?>)</option>
									<option value="16:9" <?php selected( $s['gemini_aspect_ratio'], '16:9' ); ?>>16:9 (<?php esc_html_e( 'Landscape', 'stifli-flex-mcp' ); ?>)</option>
									<option value="9:16" <?php selected( $s['gemini_aspect_ratio'], '9:16' ); ?>>9:16 (<?php esc_html_e( 'Portrait', 'stifli-flex-mcp' ); ?>)</option>
									<option value="4:3" <?php selected( $s['gemini_aspect_ratio'], '4:3' ); ?>>4:3 (<?php esc_html_e( 'Classic', 'stifli-flex-mcp' ); ?>)</option>
									<option value="3:4" <?php selected( $s['gemini_aspect_ratio'], '3:4' ); ?>>3:4 (<?php esc_html_e( 'Portrait Classic', 'stifli-flex-mcp' ); ?>)</option>
									<option value="3:2" <?php selected( $s['gemini_aspect_ratio'], '3:2' ); ?>>3:2</option>
									<option value="2:3" <?php selected( $s['gemini_aspect_ratio'], '2:3' ); ?>>2:3</option>
								</select>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'The tool can override this per-request via the "size" argument.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<!-- ─── Post-Processing ──────────────────────────── -->
				<div class="card sflmcp-postprocess-section <?php echo $s['pp_enabled'] !== '1' ? 'disabled' : ''; ?>">
					<h3>⚙️ <?php esc_html_e( 'Image Post-Processing', 'stifli-flex-mcp' ); ?></h3>
					<p class="description"><?php esc_html_e( 'Automatically compress/resize AI-generated images before saving to the Media Library. Uses GD or the WordPress image editor.', 'stifli-flex-mcp' ); ?></p>

					<?php if ( $has_gd ) : ?>
						<div class="sflmcp-gd-ok">
							✅ <?php
							/* translators: %s: GD library version string */
							echo esc_html( sprintf( __( 'GD Library available (version: %s). JPEG, PNG, and WebP processing supported.', 'stifli-flex-mcp' ), isset( $gd_info['GD Version'] ) ? $gd_info['GD Version'] : 'unknown' ) ); ?>
						</div>
					<?php else : ?>
						<div class="sflmcp-gd-warning">
							⚠️ <?php esc_html_e( 'GD Library not detected. Post-processing will use the WordPress image editor (Imagick or fallback).', 'stifli-flex-mcp' ); ?>
						</div>
					<?php endif; ?>

					<table class="form-table">
						<tr>
							<th><?php esc_html_e( 'Enable Post-Processing', 'stifli-flex-mcp' ); ?></th>
							<td>
								<label>
									<input type="checkbox" id="sflmcp_mm_pp_enabled" <?php checked( $s['pp_enabled'], '1' ); ?>>
									<?php esc_html_e( 'Compress and/or resize images after generation', 'stifli-flex-mcp' ); ?>
								</label>
							</td>
						</tr>
					</table>

					<div class="sflmcp-postprocess-fields <?php echo $s['pp_enabled'] !== '1' ? 'hidden' : ''; ?>">
						<table class="form-table">
							<tr>
								<th><?php esc_html_e( 'Max Width (px)', 'stifli-flex-mcp' ); ?></th>
								<td>
									<input type="number" id="sflmcp_mm_pp_max_width" value="<?php echo esc_attr( $s['pp_max_width'] ); ?>" min="256" max="4096" step="1">
									<p class="sflmcp-field-desc"><?php esc_html_e( 'Images wider than this will be proportionally resized. Set 0 for no limit.', 'stifli-flex-mcp' ); ?></p>
								</td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Max Height (px)', 'stifli-flex-mcp' ); ?></th>
								<td>
									<input type="number" id="sflmcp_mm_pp_max_height" value="<?php echo esc_attr( $s['pp_max_height'] ); ?>" min="256" max="4096" step="1">
									<p class="sflmcp-field-desc"><?php esc_html_e( 'Images taller than this will be proportionally resized. Set 0 for no limit.', 'stifli-flex-mcp' ); ?></p>
								</td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Compression Quality', 'stifli-flex-mcp' ); ?></th>
								<td>
									<div class="sflmcp-range-field">
										<input type="range" id="sflmcp_mm_pp_quality" min="30" max="100" value="<?php echo esc_attr( $s['pp_quality'] ); ?>">
										<span id="sflmcp_mm_pp_quality_val" class="sflmcp-range-value"><?php echo esc_html( $s['pp_quality'] ); ?>%</span>
									</div>
									<p class="sflmcp-field-desc"><?php esc_html_e( 'JPEG/WebP quality. Lower = smaller file, less detail. 75-85 is recommended.', 'stifli-flex-mcp' ); ?></p>
								</td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Convert Format', 'stifli-flex-mcp' ); ?></th>
								<td>
									<select id="sflmcp_mm_pp_format">
										<option value="original" <?php selected( $s['pp_format'], 'original' ); ?>><?php esc_html_e( 'Keep Original Format', 'stifli-flex-mcp' ); ?></option>
										<option value="jpeg" <?php selected( $s['pp_format'], 'jpeg' ); ?>><?php esc_html_e( 'Convert to JPEG (smallest, no transparency)', 'stifli-flex-mcp' ); ?></option>
										<option value="webp" <?php selected( $s['pp_format'], 'webp' ); ?>><?php esc_html_e( 'Convert to WebP (modern, good compression)', 'stifli-flex-mcp' ); ?></option>
										<option value="png" <?php selected( $s['pp_format'], 'png' ); ?>><?php esc_html_e( 'Convert to PNG (lossless, preserves transparency)', 'stifli-flex-mcp' ); ?></option>
									</select>
								</td>
							</tr>
						</table>
					</div>
				</div>

				<div id="sflmcp-mm-autosave-status" class="sflmcp-autosave-status"></div>
			</form>
		</div>
		<?php
	}

	/**
	 * Render Video Settings Tab
	 */
	private function renderVideoSettingsTab() {
		$s = $this->getMultimediaSettings();

		// Build partial display strings for API keys (same shared keys as image tab)
		$openai_display = $this->maskApiKeyForDisplay( $s['openai_api_key'] );
		$gemini_display = $this->maskApiKeyForDisplay( $s['gemini_api_key'] );
		?>
		<div class="sflmcp-multimedia-wrap">

			<!-- ─── Tool Enable/Disable ─────────────────────── -->
			<div class="sflmcp-tool-toggle-banner" data-tool="wp_generate_video">
				<label class="sflmcp-toggle-switch">
					<input type="checkbox" id="sflmcp_mm_tool_video_toggle" class="sflmcp-mm-tool-toggle" data-tool="wp_generate_video">
					<span class="sflmcp-toggle-slider"></span>
				</label>
				<span class="sflmcp-toggle-label">
					<strong>wp_generate_video</strong> — <?php esc_html_e( 'Enable this tool for MCP clients and AI agents', 'stifli-flex-mcp' ); ?>
				</span>
				<span class="sflmcp-toggle-status"></span>
			</div>
			<p class="description sflmcp-pricing-notice">
				<span class="dashicons dashicons-info" class="sflmcp-pricing-icon"></span>
				<?php esc_html_e( 'Approximate cost per video: OpenAI Sora is billed per second — sora-2: $0.10/s, sora-2-pro: $0.30–$0.50/s (e.g. a 5s video costs $0.50–$2.50). Google Veo 2: $0.35/video, Veo 3: $0.15–$0.40/video, Veo 3.1: $0.15–$0.60/video (varies by resolution). Video generation is significantly more expensive than images. Prices may change — please consult each provider\'s pricing page for up-to-date rates.', 'stifli-flex-mcp' ); ?>
			</p>

			<h2><?php esc_html_e( 'Video Generation Settings', 'stifli-flex-mcp' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Configure defaults for AI video generation (wp_generate_video tool). Video generation is asynchronous — the tool submits the request, polls for completion, then saves the result as a WordPress media attachment.', 'stifli-flex-mcp' ); ?>
			</p>

			<div id="sflmcp-mm-notice" class="sflmcp-mm-notice"></div>

			<form id="sflmcp-multimedia-form-video" class="sflmcp-multimedia-form">

				<!-- ─── Video Provider ────────────────────────────── -->
				<div class="card">
					<h3>🎬 <?php esc_html_e( 'Video Generation Provider', 'stifli-flex-mcp' ); ?></h3>
					<p class="description"><?php esc_html_e( 'Select which AI provider to use for video generation. Each has its own API key, models, and pricing.', 'stifli-flex-mcp' ); ?></p>

					<input type="hidden" id="sflmcp_mm_video_provider" name="video_provider" value="<?php echo esc_attr( $s['video_provider'] ); ?>">

					<div class="sflmcp-provider-tabs">
						<div class="sflmcp-provider-tab <?php echo $s['video_provider'] === 'gemini' ? 'active' : ''; ?>" data-provider="gemini">
							<span class="dashicons dashicons-admin-customizer"></span> Google Veo
						</div>
						<div class="sflmcp-provider-tab <?php echo $s['video_provider'] === 'openai' ? 'active' : ''; ?>" data-provider="openai">
							<span class="dashicons dashicons-video-alt3"></span> OpenAI Sora
						</div>
					</div>
				</div>

				<!-- ─── Gemini / Veo Settings ──────────────────────── -->
				<div id="sflmcp-panel-gemini" class="sflmcp-provider-panel card<?php echo $s['video_provider'] !== 'gemini' ? ' sflmcp-hidden' : ''; ?>">
					<h3><span class="dashicons dashicons-admin-customizer"></span> <?php esc_html_e( 'Google Veo Settings', 'stifli-flex-mcp' ); ?></h3>

					<table class="form-table">
						<tr>
							<th><?php esc_html_e( 'API Key', 'stifli-flex-mcp' ); ?></th>
							<td>
								<div class="sflmcp-api-key-field">
									<input type="password" id="sflmcp_mm_video_gemini_key" class="sflmcp-shared-apikey" data-key="gemini_api_key" value="<?php echo esc_attr( $gemini_display ); ?>" placeholder="AIza..." autocomplete="off">
									<button type="button" class="button sflmcp-api-key-toggle" title="<?php esc_attr_e( 'Toggle visibility', 'stifli-flex-mcp' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
								</div>
								<p class="sflmcp-field-desc">
									<?php esc_html_e( 'Same Gemini key used for image generation. Changes here update the shared key.', 'stifli-flex-mcp' ); ?>
								</p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Model', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_video_gemini_model">
									<option value="veo-3.0-generate-preview" <?php selected( $s['video_gemini_model'], 'veo-3.0-generate-preview' ); ?>>Veo 3 Preview (<?php esc_html_e( 'Latest, best quality with audio', 'stifli-flex-mcp' ); ?>)</option>
									<option value="veo-2.0-generate-001" <?php selected( $s['video_gemini_model'], 'veo-2.0-generate-001' ); ?>>Veo 2 (<?php esc_html_e( 'Stable, 480p-720p', 'stifli-flex-mcp' ); ?>)</option>
								</select>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Veo 3 generates videos up to 8s with audio. Veo 2 generates silent video.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<!-- ─── OpenAI / Sora Settings ──────────────────── -->
				<div id="sflmcp-panel-openai" class="sflmcp-provider-panel card<?php echo $s['video_provider'] !== 'openai' ? ' sflmcp-hidden' : ''; ?>">
					<h3><span class="dashicons dashicons-video-alt3"></span> <?php esc_html_e( 'OpenAI Sora Settings', 'stifli-flex-mcp' ); ?></h3>

					<table class="form-table">
						<tr>
							<th><?php esc_html_e( 'API Key', 'stifli-flex-mcp' ); ?></th>
							<td>
								<div class="sflmcp-api-key-field">
									<input type="password" id="sflmcp_mm_video_openai_key" class="sflmcp-shared-apikey" data-key="openai_api_key" value="<?php echo esc_attr( $openai_display ); ?>" placeholder="sk-..." autocomplete="off">
									<button type="button" class="button sflmcp-api-key-toggle" title="<?php esc_attr_e( 'Toggle visibility', 'stifli-flex-mcp' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
								</div>
								<p class="sflmcp-field-desc">
									<?php esc_html_e( 'Same OpenAI key used for image generation. Changes here update the shared key.', 'stifli-flex-mcp' ); ?>
								</p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Model', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_video_openai_model">
									<option value="sora-2" <?php selected( $s['video_openai_model'], 'sora-2' ); ?>>Sora 2 (<?php esc_html_e( 'Fast, flexible, good quality', 'stifli-flex-mcp' ); ?>)</option>
									<option value="sora-2-pro" <?php selected( $s['video_openai_model'], 'sora-2-pro' ); ?>>Sora 2 Pro (<?php esc_html_e( 'Higher quality, slower', 'stifli-flex-mcp' ); ?>)</option>
								</select>
							</td>
						</tr>
					</table>
				</div>

				<!-- ─── Common Video Settings ────────────────────── -->
				<div class="card">
					<h3>⚙️ <?php esc_html_e( 'Default Video Parameters', 'stifli-flex-mcp' ); ?></h3>
					<p class="description"><?php esc_html_e( 'These defaults are used when the tool is called without explicit arguments. The tool can override per-request.', 'stifli-flex-mcp' ); ?></p>

					<table class="form-table">
						<tr>
							<th><?php esc_html_e( 'Duration', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_video_duration">
									<option value="4" <?php selected( $s['video_duration'], '4' ); ?>>4s (<?php esc_html_e( 'Sora only', 'stifli-flex-mcp' ); ?>)</option>
									<option value="5" <?php selected( $s['video_duration'], '5' ); ?>>5s (<?php esc_html_e( 'Veo only', 'stifli-flex-mcp' ); ?>)</option>
									<option value="6" <?php selected( $s['video_duration'], '6' ); ?>>6s (<?php esc_html_e( 'Veo only', 'stifli-flex-mcp' ); ?>)</option>
									<option value="8" <?php selected( $s['video_duration'], '8' ); ?>>8s</option>
									<option value="12" <?php selected( $s['video_duration'], '12' ); ?>>12s (<?php esc_html_e( 'Sora only', 'stifli-flex-mcp' ); ?>)</option>
								</select>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Default video length. Veo supports 5-8s, Sora supports 4, 8, or 12s. Nearest valid value is used per provider.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Aspect Ratio', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_video_aspect">
									<option value="16:9" <?php selected( $s['video_aspect_ratio'], '16:9' ); ?>>16:9 (<?php esc_html_e( 'Landscape / YouTube', 'stifli-flex-mcp' ); ?>)</option>
									<option value="9:16" <?php selected( $s['video_aspect_ratio'], '9:16' ); ?>>9:16 (<?php esc_html_e( 'Portrait / Reels', 'stifli-flex-mcp' ); ?>)</option>
									<option value="1:1" <?php selected( $s['video_aspect_ratio'], '1:1' ); ?>>1:1 (<?php esc_html_e( 'Square', 'stifli-flex-mcp' ); ?>)</option>
								</select>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Resolution', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_video_resolution">
									<option value="480p" <?php selected( $s['video_resolution'], '480p' ); ?>>480p (<?php esc_html_e( 'Faster, smaller files', 'stifli-flex-mcp' ); ?>)</option>
									<option value="720p" <?php selected( $s['video_resolution'], '720p' ); ?>>720p (<?php esc_html_e( 'Balanced', 'stifli-flex-mcp' ); ?>)</option>
									<option value="1080p" <?php selected( $s['video_resolution'], '1080p' ); ?>>1080p (<?php esc_html_e( 'Full HD', 'stifli-flex-mcp' ); ?>)</option>
								</select>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Not all providers support all resolutions. Veo supports up to 720p. Sora uses 1280x720 / 720x1280.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<!-- ─── Async Parameters ─────────────────────────── -->
				<div class="card">
					<h3>⏱ <?php esc_html_e( 'Generation Timeout', 'stifli-flex-mcp' ); ?></h3>
					<p class="description"><?php esc_html_e( 'Video generation is asynchronous. The tool polls the provider API until completion or timeout.', 'stifli-flex-mcp' ); ?></p>

					<table class="form-table">
						<tr>
							<th><?php esc_html_e( 'Poll Interval (seconds)', 'stifli-flex-mcp' ); ?></th>
							<td>
								<input type="number" id="sflmcp_mm_video_poll" value="<?php echo esc_attr( $s['video_poll_interval'] ); ?>" min="5" max="60" step="1">
								<p class="sflmcp-field-desc"><?php esc_html_e( 'How often to check if the video is ready. Lower = faster detection but more API calls.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Max Wait (seconds)', 'stifli-flex-mcp' ); ?></th>
							<td>
								<input type="number" id="sflmcp_mm_video_max_wait" value="<?php echo esc_attr( $s['video_max_wait'] ); ?>" min="60" max="600" step="10">
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Maximum time to wait for video generation. Typical: 1-5 minutes. If exceeded, the tool returns an error.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<div id="sflmcp-mm-autosave-status" class="sflmcp-autosave-status"></div>
			</form>
		</div>
		<?php
	}

	/**
	 * Render Search Image Settings Tab.
	 */
	private function renderSearchImageSettingsTab() {
		$s = $this->getMultimediaSettings();

		$unsplash_display = $this->maskApiKeyForDisplay( $s['search_image_unsplash_api_key'] );
		$pexels_display   = $this->maskApiKeyForDisplay( $s['search_image_pexels_api_key'] );
		$pixabay_display  = $this->maskApiKeyForDisplay( $s['search_image_pixabay_api_key'] );
		?>
		<div class="sflmcp-multimedia-wrap">

			<div class="sflmcp-tool-toggle-banner" data-tool="wp_search_image">
				<label class="sflmcp-toggle-switch">
					<input type="checkbox" id="sflmcp_mm_tool_search_image_toggle" class="sflmcp-mm-tool-toggle" data-tool="wp_search_image">
					<span class="sflmcp-toggle-slider"></span>
				</label>
				<span class="sflmcp-toggle-label">
					<strong>wp_search_image</strong> — <?php esc_html_e( 'Enable this tool for MCP clients and AI agents', 'stifli-flex-mcp' ); ?>
				</span>
				<span class="sflmcp-toggle-status"></span>
			</div>

			<h2><?php esc_html_e( 'Search Image Settings', 'stifli-flex-mcp' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Configure free image-bank search for the wp_search_image tool. The tool returns a selected image URL plus attribution, captions, dimensions, thumbnails and provider metadata.', 'stifli-flex-mcp' ); ?>
			</p>

			<div id="sflmcp-mm-notice" class="sflmcp-mm-notice"></div>

			<form id="sflmcp-multimedia-form-search-image" class="sflmcp-multimedia-form">
				<div class="card">
					<h3><span class="dashicons dashicons-admin-site-alt3"></span> <?php esc_html_e( 'Image Banks', 'stifli-flex-mcp' ); ?></h3>
					<p class="description"><?php esc_html_e( 'Enable the providers you want to use and add each provider API key. Only enabled providers with a key are used by the tool.', 'stifli-flex-mcp' ); ?></p>

					<table class="form-table sflmcp-search-image-providers">
						<tr>
							<th>Unsplash</th>
							<td>
								<label class="sflmcp-provider-enable">
									<input type="checkbox" id="sflmcp_mm_search_unsplash_enabled" <?php checked( $s['search_image_unsplash_enabled'], '1' ); ?>>
									<?php esc_html_e( 'Enable Unsplash', 'stifli-flex-mcp' ); ?>
								</label>
								<div class="sflmcp-api-key-field">
									<input type="password" id="sflmcp_mm_search_unsplash_key" class="sflmcp-shared-apikey" data-key="search_image_unsplash_api_key" value="<?php echo esc_attr( $unsplash_display ); ?>" placeholder="Unsplash access key" autocomplete="off">
									<button type="button" class="button sflmcp-api-key-toggle" title="<?php esc_attr_e( 'Toggle visibility', 'stifli-flex-mcp' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
								</div>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Uses Unsplash Search Photos. Attribution and download tracking fields are included in the tool response.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
						<tr>
							<th>Pexels</th>
							<td>
								<label class="sflmcp-provider-enable">
									<input type="checkbox" id="sflmcp_mm_search_pexels_enabled" <?php checked( $s['search_image_pexels_enabled'], '1' ); ?>>
									<?php esc_html_e( 'Enable Pexels', 'stifli-flex-mcp' ); ?>
								</label>
								<div class="sflmcp-api-key-field">
									<input type="password" id="sflmcp_mm_search_pexels_key" class="sflmcp-shared-apikey" data-key="search_image_pexels_api_key" value="<?php echo esc_attr( $pexels_display ); ?>" placeholder="Pexels API key" autocomplete="off">
									<button type="button" class="button sflmcp-api-key-toggle" title="<?php esc_attr_e( 'Toggle visibility', 'stifli-flex-mcp' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
								</div>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Uses Pexels Photo Search with photographer attribution, source page and image dimensions.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
						<tr>
							<th>Pixabay</th>
							<td>
								<label class="sflmcp-provider-enable">
									<input type="checkbox" id="sflmcp_mm_search_pixabay_enabled" <?php checked( $s['search_image_pixabay_enabled'], '1' ); ?>>
									<?php esc_html_e( 'Enable Pixabay', 'stifli-flex-mcp' ); ?>
								</label>
								<div class="sflmcp-api-key-field">
									<input type="password" id="sflmcp_mm_search_pixabay_key" class="sflmcp-shared-apikey" data-key="search_image_pixabay_api_key" value="<?php echo esc_attr( $pixabay_display ); ?>" placeholder="Pixabay API key" autocomplete="off">
									<button type="button" class="button sflmcp-api-key-toggle" title="<?php esc_attr_e( 'Toggle visibility', 'stifli-flex-mcp' ); ?>"><span class="dashicons dashicons-visibility"></span></button>
								</div>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Uses Pixabay image search with tags, preview URLs, dimensions and user attribution.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<div class="card">
					<h3><span class="dashicons dashicons-filter"></span> <?php esc_html_e( 'Selection Defaults', 'stifli-flex-mcp' ); ?></h3>
					<table class="form-table">
						<tr>
							<th><?php esc_html_e( 'Preferred Image Bank', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_search_preferred_bank">
									<option value="random" <?php selected( $s['search_image_preferred_bank'], 'random' ); ?>><?php esc_html_e( 'Random configured provider', 'stifli-flex-mcp' ); ?></option>
									<option value="unsplash" <?php selected( $s['search_image_preferred_bank'], 'unsplash' ); ?>>Unsplash</option>
									<option value="pexels" <?php selected( $s['search_image_preferred_bank'], 'pexels' ); ?>>Pexels</option>
									<option value="pixabay" <?php selected( $s['search_image_preferred_bank'], 'pixabay' ); ?>>Pixabay</option>
								</select>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Tool calls can override this with the provider argument.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Image Selection', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_search_selection">
									<option value="most_relevant" <?php selected( $s['search_image_selection'], 'most_relevant' ); ?>><?php esc_html_e( 'Most relevant (first result)', 'stifli-flex-mcp' ); ?></option>
									<option value="random_top10" <?php selected( $s['search_image_selection'], 'random_top10' ); ?>><?php esc_html_e( 'Random from top 10', 'stifli-flex-mcp' ); ?></option>
									<option value="random_top20" <?php selected( $s['search_image_selection'], 'random_top20' ); ?>><?php esc_html_e( 'Random from top 20', 'stifli-flex-mcp' ); ?></option>
								</select>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Orientation', 'stifli-flex-mcp' ); ?></th>
							<td>
								<select id="sflmcp_mm_search_orientation">
									<option value="any" <?php selected( $s['search_image_orientation'], 'any' ); ?>><?php esc_html_e( 'Any', 'stifli-flex-mcp' ); ?></option>
									<option value="landscape" <?php selected( $s['search_image_orientation'], 'landscape' ); ?>><?php esc_html_e( 'Landscape', 'stifli-flex-mcp' ); ?></option>
									<option value="portrait" <?php selected( $s['search_image_orientation'], 'portrait' ); ?>><?php esc_html_e( 'Portrait', 'stifli-flex-mcp' ); ?></option>
									<option value="square" <?php selected( $s['search_image_orientation'], 'square' ); ?>><?php esc_html_e( 'Square', 'stifli-flex-mcp' ); ?></option>
								</select>
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Pixabay supports landscape and portrait; Unsplash maps square to squarish.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<div class="card">
					<h3><span class="dashicons dashicons-admin-generic"></span> <?php esc_html_e( 'Provider Parameters', 'stifli-flex-mcp' ); ?></h3>
					<table class="form-table">
						<tr>
							<th><?php esc_html_e( 'Safe Search', 'stifli-flex-mcp' ); ?></th>
							<td>
								<label>
									<input type="checkbox" id="sflmcp_mm_search_safe" <?php checked( $s['search_image_safe_search'], '1' ); ?>>
									<?php esc_html_e( 'Request stricter content filtering when the provider supports it', 'stifli-flex-mcp' ); ?>
								</label>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Pixabay Language', 'stifli-flex-mcp' ); ?></th>
							<td>
								<input type="text" id="sflmcp_mm_search_language" value="<?php echo esc_attr( $s['search_image_language'] ); ?>" maxlength="5" placeholder="en">
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Two-letter language code used by Pixabay, for example en or es.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Pexels Locale', 'stifli-flex-mcp' ); ?></th>
							<td>
								<input type="text" id="sflmcp_mm_search_locale" value="<?php echo esc_attr( $s['search_image_locale'] ); ?>" maxlength="10" placeholder="en-US">
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Locale used by Pexels, for example en-US or es-ES.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
						<tr>
							<th><?php esc_html_e( 'Request Timeout', 'stifli-flex-mcp' ); ?></th>
							<td>
								<input type="number" id="sflmcp_mm_search_timeout" value="<?php echo esc_attr( $s['search_image_timeout'] ); ?>" min="5" max="60" step="1">
								<p class="sflmcp-field-desc"><?php esc_html_e( 'Maximum seconds to wait for the selected image-bank API.', 'stifli-flex-mcp' ); ?></p>
							</td>
						</tr>
					</table>
				</div>

				<div id="sflmcp-mm-autosave-status" class="sflmcp-autosave-status"></div>
			</form>
		</div>
		<?php
	}

	/**
	 * AJAX handler: Save multimedia settings.
	 */
	public function ajax_save_multimedia_settings() {
		check_ajax_referer( 'sflmcp_multimedia', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'stifli-flex-mcp' ) ) );
		}

		// Allowed values for enum fields
		$allowed_enums = array(
			'image_provider'       => array( 'openai', 'gemini' ),
			'openai_model'         => array( 'gpt-image-2', 'gpt-image-1.5', 'gpt-image-1', 'gpt-image-1-mini', 'dall-e-3', 'dall-e-2' ),
			'openai_quality'       => array( 'low', 'medium', 'high' ),
			'openai_size'          => array( 'square', 'landscape', 'portrait' ),
			'openai_style'         => array( 'natural', 'vivid' ),
			'openai_background'    => array( 'auto', 'transparent', 'opaque' ),
			'openai_output_format' => array( 'png', 'jpeg', 'webp' ),
			'gemini_model'         => array( 'gemini-3.1-flash-image-preview', 'gemini-3-pro-image-preview', 'gemini-2.5-flash-image', 'imagen-4.0-generate-001', 'imagen-4.0-fast-generate-001', 'imagen-4.0-ultra-generate-001' ),
			'gemini_aspect_ratio'  => array( '1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3' ),
			'pp_format'            => array( 'original', 'jpeg', 'webp', 'png' ),
			'video_provider'       => array( 'gemini', 'openai' ),
			'video_gemini_model'   => array( 'veo-3.0-generate-preview', 'veo-2.0-generate-001' ),
			'video_openai_model'   => array( 'sora-2', 'sora-2-pro' ),
			'video_duration'       => array( '4', '5', '6', '8', '12' ),
			'video_aspect_ratio'   => array( '16:9', '9:16', '1:1' ),
			'video_resolution'     => array( '480p', '720p', '1080p' ),
			'search_image_preferred_bank' => array( 'random', 'unsplash', 'pexels', 'pixabay' ),
			'search_image_selection'      => array( 'most_relevant', 'random_top10', 'random_top20' ),
			'search_image_orientation'    => array( 'any', 'landscape', 'portrait', 'square' ),
		);

		// Numeric fields: key => array( min, max )
		$numeric_fields = array(
			'pp_max_width'         => array( 0, 4096 ),
			'pp_max_height'        => array( 0, 4096 ),
			'pp_quality'           => array( 30, 100 ),
			'video_poll_interval'  => array( 5, 60 ),
			'video_max_wait'       => array( 60, 600 ),
			'search_image_timeout' => array( 5, 60 ),
		);

		// Start from existing settings (partial merge — only update fields present in POST)
		$settings = get_option( 'sflmcp_multimedia_settings', array() );

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified above via check_ajax_referer

		// Update enum fields only if present in POST
		foreach ( $allowed_enums as $key => $values ) {
			if ( isset( $_POST[ $key ] ) ) {
				$val = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
				if ( in_array( $val, $values, true ) ) {
					$settings[ $key ] = $val;
				}
			}
		}

		// Update checkbox field
		if ( isset( $_POST['pp_enabled'] ) ) {
			$settings['pp_enabled'] = sanitize_text_field( wp_unslash( $_POST['pp_enabled'] ) ) === '1' ? '1' : '0';
		}

		$checkbox_fields = array(
			'search_image_safe_search',
			'search_image_unsplash_enabled',
			'search_image_pexels_enabled',
			'search_image_pixabay_enabled',
		);
		foreach ( $checkbox_fields as $key ) {
			if ( isset( $_POST[ $key ] ) ) {
				$settings[ $key ] = sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) === '1' ? '1' : '0';
			}
		}

		// Update numeric fields only if present in POST
		foreach ( $numeric_fields as $key => $range ) {
			if ( isset( $_POST[ $key ] ) ) {
				$settings[ $key ] = max( $range[0], min( $range[1], intval( $_POST[ $key ] ) ) );
			}
		}

		$text_fields = array(
			'search_image_language' => 5,
			'search_image_locale'   => 10,
		);
		foreach ( $text_fields as $key => $max_length ) {
			if ( isset( $_POST[ $key ] ) ) {
				$settings[ $key ] = substr( sanitize_text_field( wp_unslash( $_POST[ $key ] ) ), 0, $max_length );
			}
		}

		// Handle API keys — only update if user entered a real value (not the masked placeholder)
		$api_key_fields = array( 'openai_api_key', 'gemini_api_key', 'search_image_unsplash_api_key', 'search_image_pexels_api_key', 'search_image_pixabay_api_key' );
		foreach ( $api_key_fields as $key ) {
			if ( isset( $_POST[ $key ] ) ) {
				$raw = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
				// Skip if empty or contains bullet chars (masked value, not a real new key)
				if ( ! empty( $raw ) && strpos( $raw, '•' ) === false ) {
					if ( class_exists( 'StifliFlexMcp_Client_Admin' ) ) {
						$ref = new ReflectionMethod( 'StifliFlexMcp_Client_Admin', 'encrypt_value' );
						$ref->setAccessible( true );
						$settings[ $key ] = $ref->invoke( null, $raw );
					} else {
						$settings[ $key ] = $raw;
					}
				}
				// If empty or masked, keep existing value — do not touch $settings[$key]
			}
		}

		// phpcs:enable WordPress.Security.NonceVerification.Missing

		update_option( 'sflmcp_multimedia_settings', $settings );

		wp_send_json_success( array( 'message' => __( 'Settings saved', 'stifli-flex-mcp' ) ) );
	}

	/**
	 * AJAX handler: Load multimedia settings.
	 */
	public function ajax_load_multimedia_settings() {
		check_ajax_referer( 'sflmcp_multimedia', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'stifli-flex-mcp' ) ) );
		}

		$s = $this->getMultimediaSettings();

		// Mask API keys — partial reveal (first 4 + bullets + last 4 chars)
		$api_keys = array( 'openai_api_key', 'gemini_api_key', 'search_image_unsplash_api_key', 'search_image_pexels_api_key', 'search_image_pixabay_api_key' );
		foreach ( $api_keys as $key ) {
			$s[ $key ] = $this->maskApiKeyForDisplay( $s[ $key ] );
		}

		// Include tool enabled/disabled status from wp_sflmcp_tools.
		global $wpdb;
		$tools_table = $wpdb->prefix . 'sflmcp_tools';
		$tool_names  = array( 'wp_generate_image', 'wp_generate_video', 'wp_search_image' );
		foreach ( $tool_names as $tname ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$enabled = $wpdb->get_var( $wpdb->prepare(
				"SELECT enabled FROM {$tools_table} WHERE tool_name = %s LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$tname
			) );
			$s[ 'tool_enabled_' . $tname ] = ( '1' === $enabled || 1 === (int) $enabled ) ? '1' : '0';
		}

		wp_send_json_success( $s );
	}

	/**
	 * AJAX handler: Reveal a full decrypted API key (admin only).
	 */
	public function ajax_mm_reveal_key() {
		check_ajax_referer( 'sflmcp_multimedia', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'stifli-flex-mcp' ) ) );
		}

		$key_name = sanitize_text_field( wp_unslash( $_POST['key_name'] ?? '' ) );
		$allowed  = array( 'openai_api_key', 'gemini_api_key', 'search_image_unsplash_api_key', 'search_image_pexels_api_key', 'search_image_pixabay_api_key' );
		if ( ! in_array( $key_name, $allowed, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid key name', 'stifli-flex-mcp' ) ) );
		}

		$settings  = $this->getMultimediaSettings();
		$encrypted = isset( $settings[ $key_name ] ) ? $settings[ $key_name ] : '';

		if ( empty( $encrypted ) ) {
			wp_send_json_success( array( 'key' => '' ) );
		}

		$plain = '';
		if ( class_exists( 'StifliFlexMcp_Client_Admin' ) ) {
			$plain = StifliFlexMcp_Client_Admin::decrypt_value( $encrypted );
		} else {
			$plain = $encrypted;
		}

		wp_send_json_success( array( 'key' => $plain ) );
	}

	/**
	 * AJAX handler: Toggle a multimedia tool on/off by tool_name.
	 */
	public function ajax_mm_toggle_tool() {
		check_ajax_referer( 'sflmcp_multimedia', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'stifli-flex-mcp' ) ) );
		}

		$tool_name = sanitize_text_field( wp_unslash( $_POST['tool_name'] ?? '' ) );
		$enabled   = isset( $_POST['enabled'] ) ? intval( $_POST['enabled'] ) : -1;

		$allowed = array( 'wp_generate_image', 'wp_generate_video', 'wp_search_image' );
		if ( ! in_array( $tool_name, $allowed, true ) || ! in_array( $enabled, array( 0, 1 ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid parameters', 'stifli-flex-mcp' ) ) );
		}

		global $wpdb;
		$tools_table = $wpdb->prefix . 'sflmcp_tools';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->update(
			$tools_table,
			array( 'enabled' => $enabled, 'updated_at' => current_time( 'mysql', true ) ),
			array( 'tool_name' => $tool_name ),
			array( '%d', '%s' ),
			array( '%s' )
		);

		// Sync to active profile.
		$this->syncToolToActiveProfile( $tool_name, $enabled );

		wp_send_json_success( array( 'tool_name' => $tool_name, 'enabled' => $enabled ) );
	}

	// ================================================================
	// OAuth Clients Tab
	// ================================================================

	/**
	 * Render the OAuth Clients admin tab.
	 */
	private function renderOAuthClientsTab() {
		if ( ! class_exists( 'StifliFlexMcp_OAuth_Storage' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'OAuth module is not loaded.', 'stifli-flex-mcp' ) . '</p></div>';
			return;
		}

		$storage       = StifliFlexMcp_OAuth_Storage::get_instance();
		$clients       = $storage->get_all_clients();
		$auto_approve  = get_option( 'sflmcp_oauth_auto_approve', '1' );

		// Preload token counts per client.
		global $wpdb;
		$tokens_table = $wpdb->prefix . 'sflmcp_oauth_tokens';
		$now          = gmdate( 'Y-m-d H:i:s' );

		$token_counts = array();
		$token_data   = array();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$counts_raw = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT client_id, COUNT(*) as cnt FROM {$tokens_table} WHERE revoked = 0 AND access_expires_at > %s GROUP BY client_id",
				$now
			)
		);
		foreach ( $counts_raw as $row ) {
			$token_counts[ $row->client_id ] = (int) $row->cnt;
		}

		// Get active tokens grouped by client for expandable detail.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$tokens_raw = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT t.id, t.client_id, t.user_id, t.scope, t.access_expires_at, t.created_at, u.display_name as user_name
				FROM {$tokens_table} t
				LEFT JOIN {$wpdb->users} u ON t.user_id = u.ID
				WHERE t.revoked = 0 AND t.access_expires_at > %s
				ORDER BY t.created_at DESC",
				$now
			)
		);
		foreach ( $tokens_raw as $tok ) {
			$token_data[ $tok->client_id ][] = $tok;
		}
		?>
		<div class="sflmcp-oauth-wrap">
			<div class="sflmcp-oauth-header">
				<h2><?php esc_html_e( 'OAuth 2.1 Clients', 'stifli-flex-mcp' ); ?></h2>
			</div>

			<!-- Auto-approve setting -->
			<div class="sflmcp-oauth-settings">
				<label>
					<input type="checkbox" id="sflmcp_oauth_auto_approve" value="1" <?php checked( $auto_approve, '1' ); ?>>
					<strong><?php esc_html_e( 'Allow dynamic client registration', 'stifli-flex-mcp' ); ?></strong>
				</label>
				<p class="description">
					<?php esc_html_e( 'When enabled, any MCP client (Claude Desktop, ChatGPT, etc.) can register automatically via Dynamic Client Registration. When disabled, clients must be manually registered by an administrator.', 'stifli-flex-mcp' ); ?>
				</p>
				<p><label><input type="checkbox" id="sflmcp_oauth_require_approval" value="1" <?php checked( get_option( 'sflmcp_oauth_require_approval', '0' ), '1' ); ?>> <?php esc_html_e( 'Require administrator approval for new clients', 'stifli-flex-mcp' ); ?></label></p>
				<button type="button" class="button sflmcp-oauth-check-header"><span class="dashicons dashicons-shield" aria-hidden="true"></span> <?php esc_html_e( 'Check Authorization header', 'stifli-flex-mcp' ); ?></button>
			</div>

			<!-- OAuth Endpoints Reference -->
			<div class="sflmcp-oauth-endpoints">
				<h3><?php esc_html_e( 'OAuth Endpoints', 'stifli-flex-mcp' ); ?></h3>
				<table>
					<tr>
						<td><?php esc_html_e( 'REST Discovery', 'stifli-flex-mcp' ); ?></td>
						<td><code><?php echo esc_html( rest_url( 'stifli-flex-mcp/v1/.well-known/oauth-authorization-server' ) ); ?></code></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Resource Metadata', 'stifli-flex-mcp' ); ?></td>
						<td><code><?php echo esc_html( home_url( '/.well-known/oauth-protected-resource' ) ); ?></code></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Server Metadata', 'stifli-flex-mcp' ); ?></td>
						<td><code><?php echo esc_html( home_url( '/.well-known/oauth-authorization-server' ) ); ?></code></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'OpenID Configuration (fallback)', 'stifli-flex-mcp' ); ?></td>
						<td><code><?php echo esc_html( home_url( '/.well-known/openid-configuration' ) ); ?></code></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Client Registration', 'stifli-flex-mcp' ); ?></td>
						<td><code><?php echo esc_html( rest_url( 'stifli-flex-mcp/v1/oauth/register' ) ); ?></code></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Authorization', 'stifli-flex-mcp' ); ?></td>
						<td><code><?php echo esc_html( home_url( '?sflmcp_oauth=authorize' ) ); ?></code></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Token', 'stifli-flex-mcp' ); ?></td>
						<td><code><?php echo esc_html( rest_url( 'stifli-flex-mcp/v1/oauth/token' ) ); ?></code></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Revocation', 'stifli-flex-mcp' ); ?></td>
						<td><code><?php echo esc_html( rest_url( 'stifli-flex-mcp/v1/oauth/revoke' ) ); ?></code></td>
					</tr>
				</table>
			</div>

			<!-- Clients Table -->
			<?php if ( empty( $clients ) ) : ?>
				<div class="sflmcp-oauth-empty">
					<div class="dashicons dashicons-shield"></div>
					<p><strong><?php esc_html_e( 'No OAuth clients registered yet', 'stifli-flex-mcp' ); ?></strong></p>
					<p><?php esc_html_e( 'Clients will appear here when an MCP application (Claude Desktop, ChatGPT, etc.) registers via Dynamic Client Registration.', 'stifli-flex-mcp' ); ?></p>
				</div>
			<?php else : ?>
				<table class="wp-list-table widefat fixed striped sflmcp-oauth-table">
					<thead>
						<tr>
							<th class="column-name"><?php esc_html_e( 'Client Name', 'stifli-flex-mcp' ); ?></th>
							<th class="column-client-id"><?php esc_html_e( 'Client ID', 'stifli-flex-mcp' ); ?></th>
							<th class="column-auth-method"><?php esc_html_e( 'Type', 'stifli-flex-mcp' ); ?></th>
							<th class="column-tokens"><?php esc_html_e( 'Tokens', 'stifli-flex-mcp' ); ?></th>
							<th class="column-date"><?php esc_html_e( 'Registered', 'stifli-flex-mcp' ); ?></th>
							<th class="column-actions"><?php esc_html_e( 'Actions', 'stifli-flex-mcp' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $clients as $client ) :
							$cid         = esc_attr( $client->client_id );
							$count       = isset( $token_counts[ $client->client_id ] ) ? $token_counts[ $client->client_id ] : 0;
							$is_public   = ( 'none' === $client->token_endpoint_auth_method );
							$tokens_list = isset( $token_data[ $client->client_id ] ) ? $token_data[ $client->client_id ] : array();
						?>
							<tr>
								<td>
									<strong><?php echo esc_html( $client->client_name ); ?></strong>
									<?php if ( $storage->client_is_pending( $client->client_id ) ) : ?>
										<p class="sflmcp-oauth-pending"><?php esc_html_e( 'Pending approval', 'stifli-flex-mcp' ); ?></p>
									<?php endif; ?>
									<?php if ( $client->client_uri ) : ?>
										<br><small><a href="<?php echo esc_url( $client->client_uri ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $client->client_uri ); ?></a></small>
									<?php endif; ?>
								</td>
								<td>
									<span class="sflmcp-oauth-client-id"><?php echo esc_html( $client->client_id ); ?></span>
								</td>
								<td>
									<?php if ( $is_public ) : ?>
										<span class="sflmcp-oauth-badge sflmcp-oauth-badge--public"><?php esc_html_e( 'Public', 'stifli-flex-mcp' ); ?></span>
									<?php else : ?>
										<span class="sflmcp-oauth-badge sflmcp-oauth-badge--confidential"><?php esc_html_e( 'Confidential', 'stifli-flex-mcp' ); ?></span>
									<?php endif; ?>
								</td>
								<td>
									<?php if ( $count > 0 ) : ?>
										<a href="#" class="sflmcp-oauth-toggle-tokens" data-client-id="<?php echo esc_attr( $cid ); ?>">
											<span class="sflmcp-oauth-token-count has-tokens" data-client-count="<?php echo esc_attr( $cid ); ?>"><?php echo intval( $count ); ?></span>
										</a>
									<?php else : ?>
										<span class="sflmcp-oauth-token-count" data-client-count="<?php echo esc_attr( $cid ); ?>">0</span>
									<?php endif; ?>
								</td>
								<td>
									<?php
									$registered = strtotime( $client->created_at );
									echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $registered + ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS ) ) );
									?>
								</td>
								<td>
									<button type="button" class="button button-link-delete sflmcp-oauth-delete-client" data-client-id="<?php echo esc_attr( $cid ); ?>">
										<?php esc_html_e( 'Delete', 'stifli-flex-mcp' ); ?>
									</button>
									<?php if ( $storage->client_is_pending( $client->client_id ) ) : ?>
										<button type="button" class="button sflmcp-oauth-approve-client" data-client-id="<?php echo esc_attr( $cid ); ?>"><?php esc_html_e( 'Approve', 'stifli-flex-mcp' ); ?></button>
									<?php endif; ?>
								</td>
							</tr>
							<!-- Expandable tokens row -->
							<?php if ( ! empty( $tokens_list ) ) : ?>
							<tr class="sflmcp-oauth-tokens-row">
								<td colspan="6">
									<div id="sflmcp-tokens-<?php echo esc_attr( $cid ); ?>" class="sflmcp-oauth-tokens-detail">
										<h4><?php esc_html_e( 'Active Tokens', 'stifli-flex-mcp' ); ?></h4>
										<table class="sflmcp-oauth-tokens-list">
											<thead>
												<tr>
													<th><?php esc_html_e( 'User', 'stifli-flex-mcp' ); ?></th>
													<th><?php esc_html_e( 'Scope', 'stifli-flex-mcp' ); ?></th>
													<th><?php esc_html_e( 'Issued', 'stifli-flex-mcp' ); ?></th>
													<th><?php esc_html_e( 'Expires', 'stifli-flex-mcp' ); ?></th>
													<th></th>
												</tr>
											</thead>
											<tbody>
												<?php foreach ( $tokens_list as $tok ) :
													$issued  = strtotime( $tok->created_at );
													$expires = strtotime( $tok->access_expires_at );
													$offset  = get_option( 'gmt_offset' ) * HOUR_IN_SECONDS;
												?>
												<tr>
													<td><?php echo esc_html( $tok->user_name ?: '#' . $tok->user_id ); ?></td>
													<td><?php echo esc_html( $tok->scope ); ?></td>
													<td><?php echo esc_html( date_i18n( 'M j, H:i', $issued + $offset ) ); ?></td>
													<td><?php echo esc_html( date_i18n( 'M j, H:i', $expires + $offset ) ); ?></td>
													<td>
														<button type="button" class="button button-small button-link-delete sflmcp-oauth-revoke-token"
															data-token-id="<?php echo intval( $tok->id ); ?>"
															data-client-id="<?php echo esc_attr( $cid ); ?>">
															<?php esc_html_e( 'Revoke', 'stifli-flex-mcp' ); ?>
														</button>
													</td>
												</tr>
												<?php endforeach; ?>
											</tbody>
										</table>
									</div>
								</td>
							</tr>
							<?php endif; ?>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

			<!-- Setup Guides -->
			<div class="sflmcp-oauth-guides sflmcp-oauth-guides-spaced">
				<h2><?php esc_html_e( 'Quick Setup Guides', 'stifli-flex-mcp' ); ?></h2>

				<!-- Claude Desktop -->
				<div class="sflmcp-oauth-guide-card sflmcp-oauth-guide-card-spaced">
					<h3 class="sflmcp-oauth-guide-title">🟣 <?php esc_html_e( 'Claude Desktop', 'stifli-flex-mcp' ); ?></h3>
					<p class="sflmcp-oauth-guide-description">
						<?php esc_html_e( 'Claude Desktop supports MCP OAuth 2.1 natively. It discovers all endpoints automatically from a single URL.', 'stifli-flex-mcp' ); ?>
					</p>
					<ol class="sflmcp-oauth-guide-steps">
						<li><?php esc_html_e( 'Enable "Auto-approve new client registrations" above', 'stifli-flex-mcp' ); ?></li>
						<li><?php echo wp_kses(
							sprintf(
								/* translators: %s: file path */
								__( 'Edit your Claude Desktop config file: %s', 'stifli-flex-mcp' ),
								'<code>' . ( PHP_OS_FAMILY === 'Darwin'
									? '~/Library/Application Support/Claude/claude_desktop_config.json'
									: '%APPDATA%\\Claude\\claude_desktop_config.json' ) . '</code>'
							),
							array( 'code' => array() )
						); ?></li>
						<li><?php esc_html_e( 'Add this MCP server configuration:', 'stifli-flex-mcp' ); ?>
							<pre class="sflmcp-oauth-pre">{
  "mcpServers": {
    "<?php echo esc_html( sanitize_title( get_bloginfo( 'name' ) ) ); ?>": {
      "type": "sse",
      "url": "<?php echo esc_html( rest_url( $this->namespace . '/sse' ) ); ?>"
    }
  }
}</pre>
						</li>
						<li><?php esc_html_e( 'Restart Claude Desktop — it will open your browser to authorize', 'stifli-flex-mcp' ); ?></li>
						<li><?php esc_html_e( 'Log in to WordPress and click "Authorize"', 'stifli-flex-mcp' ); ?></li>
						<li><?php esc_html_e( 'Done! Claude will auto-discover all OAuth endpoints via .well-known metadata', 'stifli-flex-mcp' ); ?></li>
					</ol>
					<p class="sflmcp-oauth-guide-note">
						<?php echo wp_kses(
							sprintf(
								/* translators: %s: the SSE URL */
								__( 'Claude only needs the SSE URL: %s — it discovers authorization, token, and registration endpoints automatically.', 'stifli-flex-mcp' ),
								'<code>' . esc_html( rest_url( $this->namespace . '/sse' ) ) . '</code>'
							),
							array( 'code' => array() )
						); ?>
					</p>
				</div>

				<!-- ChatGPT Custom GPT -->
				<div class="sflmcp-oauth-guide-card sflmcp-oauth-guide-card-spaced">
					<h3 class="sflmcp-oauth-guide-title">🟢 <?php esc_html_e( 'ChatGPT (Custom GPT Actions)', 'stifli-flex-mcp' ); ?></h3>
					<p class="sflmcp-oauth-guide-description">
						<?php esc_html_e( 'For ChatGPT GPT Actions, register a confidential client and configure OAuth in the GPT editor.', 'stifli-flex-mcp' ); ?>
					</p>
					<ol class="sflmcp-oauth-guide-steps">
						<li><?php esc_html_e( 'Register a confidential client (via API or ask an admin) with:', 'stifli-flex-mcp' ); ?>
							<ul class="sflmcp-oauth-guide-bullets">
								<li><code>token_endpoint_auth_method: "client_secret_post"</code></li>
								<li><code>redirect_uris: ["https://chatgpt.com/aip/<em>YOUR_PLUGIN_ID</em>/oauth/callback"]</code></li>
							</ul>
						</li>
						<li><?php esc_html_e( 'In the GPT editor → Actions → Authentication, select "OAuth" and fill:', 'stifli-flex-mcp' ); ?>
							<table class="sflmcp-oauth-config-table">
								<tr><td class="sflmcp-oauth-config-label"><?php esc_html_e( 'Client ID', 'stifli-flex-mcp' ); ?></td><td class="sflmcp-oauth-config-value"><em><?php esc_html_e( '(from step 1)', 'stifli-flex-mcp' ); ?></em></td></tr>
								<tr><td class="sflmcp-oauth-config-label"><?php esc_html_e( 'Client Secret', 'stifli-flex-mcp' ); ?></td><td class="sflmcp-oauth-config-value"><em><?php esc_html_e( '(from step 1)', 'stifli-flex-mcp' ); ?></em></td></tr>
								<tr><td class="sflmcp-oauth-config-label"><?php esc_html_e( 'Authorization URL', 'stifli-flex-mcp' ); ?></td><td class="sflmcp-oauth-config-value"><code><?php echo esc_html( home_url( '?sflmcp_oauth=authorize' ) ); ?></code></td></tr>
								<tr><td class="sflmcp-oauth-config-label"><?php esc_html_e( 'Token URL', 'stifli-flex-mcp' ); ?></td><td class="sflmcp-oauth-config-value"><code><?php echo esc_html( rest_url( $this->namespace . '/oauth/token' ) ); ?></code></td></tr>
								<tr><td class="sflmcp-oauth-config-label"><?php esc_html_e( 'Scope', 'stifli-flex-mcp' ); ?></td><td class="sflmcp-oauth-config-value"><code>mcp</code></td></tr>
							</table>
						</li>
						<li><?php esc_html_e( 'Save and test the GPT — users will be prompted to authorize via your WordPress site', 'stifli-flex-mcp' ); ?></li>
					</ol>
				</div>

				<!-- Application Passwords -->
				<div class="sflmcp-oauth-guide-card sflmcp-oauth-guide-card-last">
					<h3 class="sflmcp-oauth-guide-title">🔑 <?php esc_html_e( 'Application Passwords (alternative)', 'stifli-flex-mcp' ); ?></h3>
					<p class="sflmcp-oauth-guide-description sflmcp-oauth-guide-description-tight">
						<?php echo wp_kses(
							sprintf(
								/* translators: %s: link to profile page */
								__( 'For simple setups, WordPress Application Passwords still work. Go to %s to generate one.', 'stifli-flex-mcp' ),
								'<a href="' . esc_url( get_edit_profile_url( get_current_user_id() ) . '#application-passwords-section' ) . '">'
								. esc_html__( 'your profile', 'stifli-flex-mcp' ) . '</a>'
							),
							array( 'a' => array( 'href' => array() ) )
						); ?>
					</p>
					<p class="sflmcp-oauth-guide-note">
						<?php esc_html_e( 'Use HTTP Basic Auth with your WordPress username and the generated application password. This method does not require OAuth setup.', 'stifli-flex-mcp' ); ?>
					</p>
					<?php
					$messages_endpoint = rest_url( $this->namespace . '/messages' );
					$current_user = wp_get_current_user();
					$example_user = ( $current_user && ! empty( $current_user->user_login ) ) ? $current_user->user_login : 'your_wp_username';
					$curl_example = implode(
						"\n",
						array(
							sprintf( 'curl -u "%s:<APP_PASSWORD_WITHOUT_SPACES>" \\', $example_user ),
							'  -H "Content-Type: application/json" \\',
							'  -d \'{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}\' \\',
							sprintf( '  "%s"', $messages_endpoint ),
						)
					);
					?>
					<p class="sflmcp-oauth-guide-note"><strong><?php esc_html_e( 'Note:', 'stifli-flex-mcp' ); ?></strong> <?php esc_html_e( 'This method uses HTTP Basic Auth (not Bearer token). If WordPress shows spaces in the generated Application Password, you can remove all spaces before using it.', 'stifli-flex-mcp' ); ?></p>
					<p class="sflmcp-oauth-guide-note">
						<?php echo wp_kses(
							sprintf(
								/* translators: %s: dynamic endpoint URL */
								__( 'Example (dynamic endpoint for this site: %s):', 'stifli-flex-mcp' ),
								'<code>' . esc_html( $messages_endpoint ) . '</code>'
							),
							array( 'code' => array() )
						); ?>
					</p>
					<pre class="sflmcp-oauth-pre"><?php echo esc_html( $curl_example ); ?></pre>
				</div>
			</div>

		</div>
		<?php
	}

	// ================================================================
	// OAuth AJAX Handlers
	// ================================================================

	/**
	 * AJAX: Delete an OAuth client and all its tokens.
	 */
	public function ajax_oauth_delete_client() {
		check_ajax_referer( 'sflmcp_oauth', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'stifli-flex-mcp' ) ) );
			return;
		}

		$client_id = isset( $_POST['client_id'] ) ? sanitize_text_field( wp_unslash( $_POST['client_id'] ) ) : '';

		if ( empty( $client_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Missing client_id', 'stifli-flex-mcp' ) ) );
			return;
		}

		$storage = StifliFlexMcp_OAuth_Storage::get_instance();
		$deleted = $storage->delete_client( $client_id );

		if ( $deleted ) {
			wp_send_json_success();
		} else {
			wp_send_json_error( array( 'message' => __( 'Client not found', 'stifli-flex-mcp' ) ) );
		}
	}

	/**
	 * AJAX: Revoke a specific OAuth token by row ID.
	 */
	public function ajax_oauth_revoke_token() {
		check_ajax_referer( 'sflmcp_oauth', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'stifli-flex-mcp' ) ) );
			return;
		}

		$token_id = isset( $_POST['token_id'] ) ? intval( $_POST['token_id'] ) : 0;

		if ( ! $token_id ) {
			wp_send_json_error( array( 'message' => __( 'Missing token_id', 'stifli-flex-mcp' ) ) );
			return;
		}

		global $wpdb;
		$table = $wpdb->prefix . 'sflmcp_oauth_tokens';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$updated = $wpdb->update(
			$table,
			array( 'revoked' => 1 ),
			array( 'id' => $token_id ),
			array( '%d' ),
			array( '%d' )
		);

		if ( false !== $updated ) {
			wp_send_json_success();
		} else {
			wp_send_json_error( array( 'message' => __( 'Token not found', 'stifli-flex-mcp' ) ) );
		}
	}

	/**
	 * AJAX: Save OAuth settings (auto-approve toggle).
	 */
	public function ajax_oauth_save_settings() {
		check_ajax_referer( 'sflmcp_oauth', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'stifli-flex-mcp' ) ) );
			return;
		}

		$auto_approve = isset( $_POST['auto_approve'] ) ? sanitize_text_field( wp_unslash( $_POST['auto_approve'] ) ) : '0';
		update_option( 'sflmcp_oauth_auto_approve', $auto_approve === '1' ? '1' : '0' );
		if ( isset( $_POST['require_approval'] ) ) {
			update_option( 'sflmcp_oauth_require_approval', '1' === $_POST['require_approval'] ? '1' : '0', false );
		}
		$this->invalidateOAuthWellKnownProbeCache();

		wp_send_json_success();
	}

	public function ajax_oauth_approve_client() {
		check_ajax_referer( 'sflmcp_oauth', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'stifli-flex-mcp' ) ), 403 );
			return;
		}
		$client_id = isset( $_POST['client_id'] ) ? sanitize_text_field( wp_unslash( $_POST['client_id'] ) ) : '';
		$storage = StifliFlexMcp_OAuth_Storage::get_instance();
		if ( ! $storage->get_client( $client_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Client not found', 'stifli-flex-mcp' ) ), 404 );
			return;
		}
		update_option( 'sflmcp_oauth_review_' . hash( 'sha256', $storage::client_storage_id( $client_id ) ), 'approved', false );
		wp_send_json_success();
	}

	public function ajax_oauth_check_header() {
		check_ajax_referer( 'sflmcp_oauth', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'stifli-flex-mcp' ) ), 403 );
			return;
		}
		$received = 'Bearer sflmcp-header-probe' === $this->getAuthorizationHeader( null );
		wp_send_json_success( array( 'received' => $received, 'message' => $received
			? __( 'Authorization header received.', 'stifli-flex-mcp' )
			: __( 'Authorization header missing. Check the proxy, WAF and Apache/nginx forwarding configuration.', 'stifli-flex-mcp' ) ) );
	}

	/**
	 * AJAX: Reset OAuth tokens and auth codes while preserving clients.
	 */
	public function ajax_oauth_reset_state() {
		check_ajax_referer( 'sflmcp_oauth', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'stifli-flex-mcp' ) ) );
			return;
		}

		$storage = StifliFlexMcp_OAuth_Storage::get_instance();
		$result = $storage->reset_all_state();

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
			return;
		}

		wp_send_json_success( $result );
	}

	/**
	 * AJAX: Generate an Application Password for current user.
	 */
	public function ajax_generate_app_password() {
		check_ajax_referer( 'SFLMCP-admin', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied', 'stifli-flex-mcp' ) ), 403 );
			return;
		}

		if ( ! class_exists( 'WP_Application_Passwords' ) ) {
			wp_send_json_error( array( 'message' => __( 'Application Passwords are not available on this WordPress installation.', 'stifli-flex-mcp' ) ) );
			return;
		}

		$current_user = wp_get_current_user();
		if ( ! is_a( $current_user, 'WP_User' ) || empty( $current_user->ID ) ) {
			wp_send_json_error( array( 'message' => __( 'Could not resolve the current user.', 'stifli-flex-mcp' ) ) );
			return;
		}

		if ( ! $this->isApplicationPasswordsAvailableForUser( $current_user ) ) {
			wp_send_json_error( array( 'message' => __( 'Application Passwords are not available for this user/site. Ensure HTTPS is enabled and no plugin disables this feature.', 'stifli-flex-mcp' ) ) );
			return;
		}

		$app_name = $this->getNextDefaultApplicationPasswordName( (int) $current_user->ID );
		$created = WP_Application_Passwords::create_new_application_password(
			(int) $current_user->ID,
			array(
				'name'   => $app_name,
				'app_id' => wp_generate_uuid4(),
			)
		);

		if ( is_wp_error( $created ) ) {
			wp_send_json_error( array( 'message' => wp_strip_all_tags( $created->get_error_message() ) ) );
			return;
		}

		$raw_password = isset( $created[0] ) ? (string) $created[0] : '';
		$record       = ( isset( $created[1] ) && is_array( $created[1] ) ) ? $created[1] : array();

		if ( '' === $raw_password ) {
			wp_send_json_error( array( 'message' => __( 'Application Password was created but the plain-text value was not returned.', 'stifli-flex-mcp' ) ) );
			return;
		}

		wp_send_json_success(
			array(
				'message'    => __( 'Application Password created. Copy it now: it is only shown this one time.', 'stifli-flex-mcp' ),
				'user_login' => isset( $current_user->user_login ) ? (string) $current_user->user_login : '',
				'app_name'   => isset( $record['name'] ) ? (string) $record['name'] : $app_name,
				'password'   => $raw_password,
			)
		);
	}

	/**
	 * Render Help Tab - Complete documentation
	 */
	private function renderHelpTab() {
		$site_url = site_url();
		$endpoint = rest_url($this->namespace . '/messages');
		$model = class_exists( 'StifliFlexMcpModel' ) ? new StifliFlexMcpModel() : null;
		$enabled_tool_count = $model ? count( $model->getToolsList() ) : 0;
		$diagnostics = array(
			'plugin_version' => defined( 'SFLMCP_VERSION' ) ? SFLMCP_VERSION : '',
			'wordpress_version' => get_bloginfo( 'version' ),
			'php_version' => PHP_VERSION,
			'site_https' => is_ssl(),
			'permalink_structure' => (string) get_option( 'permalink_structure', '' ),
			'mcp_endpoint' => $endpoint,
			'oauth_metadata' => home_url( '/.well-known/oauth-authorization-server' ),
			'enabled_tool_count' => $enabled_tool_count,
			'wp_debug' => defined( 'WP_DEBUG' ) && WP_DEBUG,
			'sflmcp_debug' => defined( 'SFLMCP_DEBUG' ) && SFLMCP_DEBUG,
		);
		$diagnostic_text = wp_json_encode( $diagnostics, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		?>
		
		<div class="sflmcp-help">
			<h1>📚 <?php esc_html_e('Flex MCP - Complete Guide', 'stifli-flex-mcp'); ?></h1>
			
			<div class="card toc">
				<h3>📑 <?php esc_html_e('Table of Contents', 'stifli-flex-mcp'); ?></h3>
				<ul>
					<li><a href="#overview">🎯 <?php esc_html_e('What is MCP?', 'stifli-flex-mcp'); ?></a></li>
					<li><a href="#builtin-tools">🔧 <?php esc_html_e('Available Tools', 'stifli-flex-mcp'); ?></a></li>
					<li><a href="#custom-extensions">🔌 <?php esc_html_e('Custom Extensions with Abilities', 'stifli-flex-mcp'); ?></a></li>
					<li><a href="#use-cases">💡 <?php esc_html_e('Use Cases & Examples', 'stifli-flex-mcp'); ?></a></li>
					<li><a href="#security">🔐 <?php esc_html_e('Security Considerations', 'stifli-flex-mcp'); ?></a></li>
					<li><a href="#troubleshooting">🔧 <?php esc_html_e('Troubleshooting', 'stifli-flex-mcp'); ?></a></li>
				</ul>
			</div>

			<!-- SECTION: Overview -->
			<h2 id="overview">🎯 <?php esc_html_e('What is MCP (Model Context Protocol)?', 'stifli-flex-mcp'); ?></h2>
			<p><?php esc_html_e('MCP is an open standard that allows AI assistants (like ChatGPT, Claude, LibreChat) to interact with external tools and services. Flex MCP transforms your WordPress site into an MCP server, giving AI the ability to:', 'stifli-flex-mcp'); ?></p>
			<ul>
				<li>✅ <?php esc_html_e('Create, edit, and delete posts, pages, and custom content', 'stifli-flex-mcp'); ?></li>
				<li>✅ <?php esc_html_e('Manage WooCommerce products, orders, and customers', 'stifli-flex-mcp'); ?></li>
				<li>✅ <?php esc_html_e('Upload images (including AI-generated images)', 'stifli-flex-mcp'); ?></li>
				<li>✅ <?php esc_html_e('Use plugin integrations and registered WordPress Abilities', 'stifli-flex-mcp'); ?></li>
				<li>✅ <?php esc_html_e('Connect through OAuth 2.1 from compatible MCP clients', 'stifli-flex-mcp'); ?></li>
			</ul>

			<!-- SECTION: Built-in Tools -->
			<h2 id="builtin-tools">🔧 <?php esc_html_e('Built-in Tools', 'stifli-flex-mcp'); ?></h2>
			<p><?php echo esc_html( sprintf( __( 'This site currently exposes %d enabled tools. Availability changes with profiles, tool settings, and active integrations.', 'stifli-flex-mcp' ), $enabled_tool_count ) ); ?></p>
			<table>
				<tr><th><?php esc_html_e('Category', 'stifli-flex-mcp'); ?></th><th><?php esc_html_e('Examples', 'stifli-flex-mcp'); ?></th></tr>
				<tr><td><strong>Posts & Pages</strong></td><td>wp_get_posts, wp_create_post, wp_update_post, wp_delete_post</td></tr>
				<tr><td><strong>Media</strong></td><td>wp_upload_image, wp_upload_image_from_url, wp_get_media</td></tr>
				<tr><td><strong>Taxonomies</strong></td><td>wp_get_categories, wp_create_tag, wp_get_terms</td></tr>
				<tr><td><strong>Users</strong></td><td>wp_get_users, wp_get_user_meta, wp_update_user_meta</td></tr>
				<tr><td><strong>WooCommerce</strong></td><td>wc_get_products, wc_create_order, wc_update_stock</td></tr>
				<tr><td><strong>System</strong></td><td>wp_get_site_health, wp_get_settings, mcp_ping</td></tr>
			</table>
			<p><?php esc_html_e('Manage these tools in the "WordPress Tools" and "WooCommerce Tools" tabs.', 'stifli-flex-mcp'); ?></p>

			<!-- SECTION: Custom Extensions -->
			<h2 id="custom-extensions">🔌 <?php esc_html_e('Custom Extensions with WordPress Abilities', 'stifli-flex-mcp'); ?></h2>
			<div class="card warning">
				<p><strong><?php esc_html_e('Legacy Custom Tools have been retired.', 'stifli-flex-mcp'); ?></strong></p>
				<p><?php esc_html_e('Use WordPress Abilities to expose custom plugin functionality to MCP clients. Abilities provide explicit schemas and permission callbacks, which is safer than generic HTTP/webhook/action-hook execution.', 'stifli-flex-mcp'); ?></p>
			</div>

			<!-- SECTION: Security -->
			<h2 id="security">🔐 <?php esc_html_e('Security Considerations', 'stifli-flex-mcp'); ?></h2>

			<div class="card warning">
				<h4><?php esc_html_e('Important Security Notes', 'stifli-flex-mcp'); ?></h4>
				<ul>
					<li><?php esc_html_e('MCP clients should use OAuth 2.1; WordPress Application Passwords remain an advanced fallback', 'stifli-flex-mcp'); ?></li>
					<li><?php esc_html_e('The AI operates with the permissions of the authenticated user', 'stifli-flex-mcp'); ?></li>
					<li><?php esc_html_e('Write operations declare confirmation requirements and enforce WordPress capabilities', 'stifli-flex-mcp'); ?></li>
					<li><?php esc_html_e('Disable tools you don\'t need in the Tools tabs', 'stifli-flex-mcp'); ?></li>
					<li><?php esc_html_e('Use Profiles to limit available tools for specific use cases', 'stifli-flex-mcp'); ?></li>
				</ul>
			</div>

			<h3><?php esc_html_e('Headers for Authenticated APIs', 'stifli-flex-mcp'); ?></h3>
			<p><?php esc_html_e('For external APIs requiring authentication, add headers in the Advanced Settings:', 'stifli-flex-mcp'); ?></p>
			<pre><code>Authorization: Bearer your-api-token
Content-Type: application/json
X-Custom-Header: value</code></pre>

			<!-- SECTION: Troubleshooting -->
			<h2 id="troubleshooting">🔧 <?php esc_html_e('Troubleshooting', 'stifli-flex-mcp'); ?></h2>

			<table>
				<tr><th><?php esc_html_e('Problem', 'stifli-flex-mcp'); ?></th><th><?php esc_html_e('Solution', 'stifli-flex-mcp'); ?></th></tr>
				<tr>
					<td><?php esc_html_e('Tool not appearing for AI', 'stifli-flex-mcp'); ?></td>
					<td><?php esc_html_e('Check the active profile, the Tools tab, and the relevant Plugin Integration. Reconnect the client after changing discovery.', 'stifli-flex-mcp'); ?></td>
				</tr>
				<tr>
					<td><?php esc_html_e('OAuth discovery returns HTML or is blocked', 'stifli-flex-mcp'); ?></td>
					<td><?php esc_html_e('Allow /.well-known/oauth-authorization-server and MCP OAuth REST routes in the host firewall, CDN, or Sucuri, then run the OAuth re-check.', 'stifli-flex-mcp'); ?></td>
				</tr>
				<tr>
					<td><?php esc_html_e('ChatGPT rejects a tool schema', 'stifli-flex-mcp'); ?></td>
					<td><?php esc_html_e('Update the plugin, reconnect the client, and confirm that cached discovery data was refreshed.', 'stifli-flex-mcp'); ?></td>
				</tr>
				<tr>
					<td><?php esc_html_e('OAuth fails with Plain permalinks', 'stifli-flex-mcp'); ?></td>
					<td><?php esc_html_e('Select Post name or another pretty permalink structure and save it before reconnecting.', 'stifli-flex-mcp'); ?></td>
				</tr>
			</table>

			<div class="card">
				<h4><?php esc_html_e('Copy-safe diagnostics', 'stifli-flex-mcp'); ?></h4>
				<p><?php esc_html_e('This block omits access tokens, OAuth client secrets, user identities, and request payloads.', 'stifli-flex-mcp'); ?></p>
				<textarea class="large-text code" rows="12" readonly><?php echo esc_textarea( $diagnostic_text ); ?></textarea>
			</div>

			<div class="card">
				<h4>📝 <?php esc_html_e('Enable Logging', 'stifli-flex-mcp'); ?></h4>
				<p><?php esc_html_e('Go to the Logs tab and enable logging to see all MCP requests and responses. This helps debug issues with tools.', 'stifli-flex-mcp'); ?></p>
			</div>

			<hr class="sflmcp-help-separator">
			<p class="sflmcp-help-footer">
				<strong>Flex MCP</strong> -
				<a href="https://github.com/estebanstifli/stifli-flex-mcp" target="_blank">GitHub</a> | 
				<a href="https://wordpress.org/plugins/stifli-flex-mcp/" target="_blank">WordPress.org</a>
			</p>
		</div>
		<?php
	}
	/* phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,PluginCheck.Security.DirectDB.UnescapedDBParameter */
}





